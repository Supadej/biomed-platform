const urlParams = new URLSearchParams(window.location.search);
const leadid = urlParams.get('leadid');
var mainuserid;
window.onload = function() {
    // Get the leadid from the URL parameter
   
    

    if (leadid === null) {
        xalert('Error: No leadid parameter found in the URL',1,null);
        return;
    }

    // Get the token from the readToken() function
    const token = readToken();

    // Create a new XHR object
    const xhr = new XMLHttpRequest();


    // Open the XHR request
    xhr.open('GET', url+`/biomedapi/leads/${leadid}`, true);

    // Set the request headers
    xhr.setRequestHeader('Authorization', `Bearer ${token}`);

    // Set the onload function to handle the response
    xhr.onload = function() {
        if (xhr.status === 200) {
            // Parse the response JSON
            const response = JSON.parse(xhr.responseText);


            if (response.LeadName !== undefined && response.LeadName !== null) {
                document.getElementById('leadName').value = response.LeadName;
            }
            // if (response.MainCustomer !== undefined && response.MainCustomer !== null) {
            //     document.getElementById('mainCustomer').value = response.MainCustomer;
            // }
            // if (response.MainCustomerId !== undefined && response.MainCustomerId !== null) {
            //     document.getElementById('mainCustomerId').value = response.MainCustomerId;
            // }
            // if (response.MainUser !== undefined && response.MainUser !== null) {
            //     document.getElementById('mainUser').value = response.MainUser;
            // }
            // if (response.MainUserId !== undefined && response.MainUserId !== null) {
            //     document.getElementById('mainUserId').value = response.MainUserId;
            // }
            if (response.Creation !== undefined && response.Creation !== null) {
                document.getElementById('creation').value = timeFriendly(response.Creation);
            }
            if (response.Expected !== undefined && response.Expected !== null) {
                document.getElementById('expected').value = timeFriendly(response.Expected);
            }
            if (response.ExpectedRevenue !== undefined && response.ExpectedRevenue !== null) {
                document.getElementById('expectedRevenue').value = response.ExpectedRevenue;
            }
            if (response.AchivedRevenue !== undefined && response.AchivedRevenue !== null) {
                document.getElementById('achievedRevenue').value = response.AchivedRevenue;
            }
            if (response.CustomerNeeds !== undefined && response.CustomerNeeds !== null) {
                document.getElementById('customerNeeds').value = response.CustomerNeeds;
            }
            if (response.KeyDicisionMaker !== undefined && response.KeyDicisionMaker !== null) {
                document.getElementById('keyDecisionMaker').value = response.KeyDicisionMaker;
            }
            if (response.KeySellingPoints !== undefined && response.KeySellingPoints !== null) {
                document.getElementById('keySellingPoints').value = response.KeySellingPoints;
            }
            if (response.CompetitorInfo !== undefined && response.CompetitorInfo !== null) {
                document.getElementById('competitorInfo').value = response.CompetitorInfo;
            }
            if (response.AdditionalInfo !== undefined && response.AdditionalInfo !== null) {
                document.getElementById('additionalInfo').value = response.AdditionalInfo;
            }
            if (response.Budget !== undefined && response.Budget !== null) {
                document.getElementById('budget').value = response.Budget;
            }
            if (response.FundingSource !== undefined && response.FundingSource !== null) {
                document.getElementById('fundingSource').value = response.FundingSource;
            }
            if (response.ProjectID !== undefined && response.ProjectID !== null) {
                document.getElementById('projectID').value = response.ProjectID;
            }
            if (response.IsPO !== undefined && response.IsPO !== null) {
                document.getElementById('isPO').value = response.IsPO;
            }
            if (response.IsCollected !== undefined && response.IsCollected !== null) {
                document.getElementById('isCollected').value = response.IsCollected;
            }
            if (response.PaymentDue !== undefined && response.PaymentDue !== null) {
                document.getElementById('paymentDue').value = timeFriendly(response.PaymentDue);
            }
            if (response.Other !== undefined && response.Other !== null) {
                document.getElementById('other').value = response.Other;
            }
            // Use the extracted data as needed
            // ...
            getPipelines((err, response) => {
                if (err) {
                    console.error('Failed to fetch pipelines:', err);
                    return;
                }

                const pipelineSelection = document.getElementById('pipelineSelection');

                response.forEach(pipeline => {
                    const radioInput = document.createElement('input');
                    radioInput.type = 'radio';
                    radioInput.className = 'btn-check';
                    radioInput.name = 'btnradio';
                    radioInput.id = `pipeline${pipeline.Id}`;
                    radioInput.autocomplete = 'off';

                    const label = document.createElement('label');
                    label.className = 'btn btn-outline-secondary small';
                    label.htmlFor = `pipeline${pipeline.Id}`;
                    label.textContent = pipeline.PipelineName;

                    pipelineSelection.appendChild(radioInput);
                    pipelineSelection.appendChild(label);
                });
            }, false);

            const pipelineId = response.CRMPipelineId;
            const pipelineRadio = document.getElementById(`pipeline${pipelineId}`);
            if (pipelineRadio) {
                pipelineRadio.checked = true;
            }
            

            const modalUsersList = document.getElementById('modalUsersList');
            
            const select = document.getElementById('usersSelecter');

            getUsers((error, users) => {
                if (error) {
                    console.error('Failed to fetch users:', error);
                    return;
                }

                //And main responsible user
                const primaryBadge = document.createElement('span');
                primaryBadge.classList.add('badge', 'bg-info', 'text-dark', 'py-1', 'm-1', 'align-middle', 'text-wrap');
                const Muser = users.find(Muser => Muser.Id === response.MainUserId);
                if (Muser) {
                    primaryBadge.innerHTML = `<strong><i class="fi fi-rr-chess-king align-middle mx-1"></i>Primary: </strong>${Muser.FirstName} ${Muser.LastName} (${Muser.Position})`;
                }
                mainuserid = response.MainUserId;
                modalUsersList.appendChild(primaryBadge);


                users.forEach(user => {
                    if (user.Id !== response.MainUserId) {
                    const option = document.createElement('option');
                    option.value = user.Id;
                    option.textContent = `${user.FirstName} ${user.LastName}`;
                    option.setAttribute('data-subtext', `${user.Position}`);
                    select.appendChild(option);
                    }
                });
                
                
                $(select).on('changed.bs.select', function (e, clickedIndex, isSelected, previousValue) {
                
                    const selectedOptions = Array.from(e.target.selectedOptions);
                    modalUsersList.innerHTML = '';
                    modalUsersList.appendChild(primaryBadge);
                    selectedOptions.forEach(option => {
                        const badge = document.createElement('span');
                        badge.classList.add('badge', 'biomed-bg-accent', 'text-dark', 'py-1', 'm-1', 'align-middle', 'text-wrap');
                        badge.innerHTML = option.getAttribute('data-subtext') ? `${option.textContent} (${option.getAttribute('data-subtext')})` : option.textContent;
                        modalUsersList.appendChild(badge);
                    });
                    document.getElementById("mainUsersList").innerHTML = modalUsersList.innerHTML;
                });
                
                
                document.getElementById("mainUsersList").innerHTML = modalUsersList.innerHTML;
                // Refresh the selectpicker to update the options

                $(select).selectpicker('refresh');
            }, false);
            
            const userIds = response.LeadUsers.map(leadUser => leadUser.UserId);
            const selectValues = userIds.map(String);
            $(select).selectpicker('val', selectValues);

        } else {
            // Handle the error case
            xalert('Error:'+ xhr.status,1,null);
            console.error('Error:', xhr.status);
        }
    };

    // Send the XHR request
    xhr.send();
};


function usersModal() {

    var multiSelectModal = new bootstrap.Modal("#multiSelectModal", {focus: true});
    multiSelectModal.show();
}


function updateLead() {
    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Configure the POST request
    xhr.open('POST', url+'/biomedapi/leads/update', true);

    // Set the request headers
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', 'Bearer ' + readToken());

    // Prepare the data from the HTML form
    var data = {
        Id: leadid,
        LeadName: document.getElementById('leadName').value,
        MainCustomerId: 1,
        MainUserId: mainuserid,
        Creation: timeFormater(document.getElementById('creation').value),
        LastUpdated: timeFormater(Date.now()),
        Expected: timeFormater(document.getElementById('expected').value),
        ExpectedRevenue: document.getElementById('expectedRevenue').value,
        AchivedRevenue: document.getElementById('achievedRevenue').value,
        CustomerNeeds: document.getElementById('customerNeeds').value,
        KeyDecisionMaker: document.getElementById('keyDecisionMaker').value,
        KeySellingPoints: document.getElementById('keySellingPoints').value,
        CompetitorInfo: document.getElementById('competitorInfo').value,
        AdditionalInfo: document.getElementById('additionalInfo').value,
        Budget: document.getElementById('budget').value,
        FundingSource: document.getElementById('fundingSource').value,
        ProjectID: document.getElementById('projectID').value,
        IsPO: document.getElementById('isPO').checked,
        IsCollected: document.getElementById('isCollected').checked,
        PaymentDue: timeFormater(document.getElementById('paymentDue').value),
        Other: document.getElementById('other').value,
        PipelineId: document.querySelector('input[name="btnradio"]:checked').id.replace('pipeline', '')
        
        //UserIds: document.getElementById('userIds').value.split(',').map(Number)
    };
    data.UserIds = Array.from(document.getElementById('usersSelecter').selectedOptions).map(option => parseInt(option.value));
    data.ContactIds = [];

    // Set the onload function to handle the response
    xhr.onload = function() {
        if (xhr.status === 200) {
            // Handle the success case
            xalert('Lead updated successfully',0,null);
            console.log('Lead updated successfully');
        } else {
            // Handle the error case
            xalert('Error:'+ xhr.status+" "+xhr.responseText,1,null);
            console.error('Error:', xhr.status);
        }
    };

    // Send the request with the JSON stringified data
    xhr.send(JSON.stringify(data));

}