// Calendar from https://github.com/vkurko/calendar
var tempEventId;
var calendarModal = new bootstrap.Modal(document.getElementById("eventModal"));
var calendarModelCache = document.getElementById("eventModal");
var ecCurrentEvent = null;
var contactTable = $("#eventTable");
calendarModelCache.addEventListener('hidden.bs.modal', function () {
    // Code to handle close event
    if (ecCurrentEvent !== null){
        ecCurrentEvent.revert();
    }
    currentID = null;
    ecCurrentEvent = null;
    clearModal();
    console.log('Modal closed');
});
var eventCollection = [];
var eventName = document.getElementById('eventName');
var eventPlan = document.getElementById('eventPlan');
var eventReport = document.getElementById('eventReport');
var eventComment = document.getElementById('eventComment');
var eventStartDate = document.getElementById('eventStartDate');
var eventEndDate = document.getElementById('eventEndDate');
var eventAllDay = document.getElementById('allDay');
var currentID = null;
var currentEvent = null;
var ecList = document.getElementById('ecList');
const select = document.getElementById('usersSelecter');

let ec = new EventCalendar(document.getElementById('ec'), {
    view: 'dayGridMonth',
    selectable:true,
    selectLongPressDelay:1000,
    select:function(info){
        console.log(info);
        openModal(null,null,info.startStr,info.endStr,info.allDay);
        ec.unselect();
    },
    dateClick:function(info){
        openModal(null,null,info.dateStr,info.dateStr,info.allDay);
        console.log(info);
    },

    events: [
        // your list of events
    ],

    eventClick: function(info){
        currentID = info.event.id;
        openModal(info.event.title,null,info.event.start,info.event.end,info.event.allDay,info.event.id);
        
        console.log(info);
    },
    eventDrop: function(info){
        currentID = info.event.id;
        openModal(info.event.title,null,info.event.start,info.event.end,info.event.allDay,info.event.id);
        ecCurrentEvent = info;
        //xalert('Drag and Drop is not implemented yet! the change will not save!', 2, 5000);
        console.log(info);
    },
    eventResize:function(info){
        currentID = info.event.id;
        openModal(info.event.title,null,info.event.start,info.event.end,info.event.allDay,info.event.id);
        ecCurrentEvent = info;
        //xalert('Drag and Drop is not implemented yet! the change will not save!', 2, 5000);
        console.log(info);
    }
    
});


function removeAllEvents(){
    console.log(ec.getEvents());
    ec.getEvents().forEach(function(event){
        ec.removeEventById(event.id);
    });
    console.log(ec.getEvents());
}

function filterchange(){
    removeAllEvents();
    var eventCollectionFiltered = [...eventCollection];
    var usersList = document.getElementById('usersList');
    var userIds = Array.from(usersList.querySelectorAll('input[type="checkbox"]:checked')).map(checkbox => checkbox.getAttribute('userId'));

    eventCollectionFiltered = eventCollectionFiltered.filter(event => userIds.includes(event.extendedProps[0].MainUserId.toString()));
    eventCollectionFiltered.forEach(async function(event) {
        var color = await getColor(event.extendedProps[0].MainUserId);
        var parsedEvent = {id:event.id,allDay:event.allDay,editable:true,start:event.start,end:event.end,title:event.title,backgroundColor:color.color.code,textColor:color.textColor,extendedProps:[{MainUserId:event.extendedProps[0].MainUserId,EventCache:event.extendedProps[0].EventCache}]};
        ec.addEvent(parsedEvent);
    });
    tableReload(eventCollectionFiltered.map(event => event.extendedProps[0].EventCache));

}




function selectAll(selection)
{
    if (selection){
        var checkboxes = document.getElementById('usersList').querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(function(checkbox){
            checkbox.checked = true;
        });}else
        {
            var checkboxes = document.getElementById('usersList').querySelectorAll('input[type="checkbox"]');
            checkboxes.forEach(function(checkbox){
                checkbox.checked = false;
            });
        }
        filterchange();

}

window.onload = function() {
    contactTable.bootstrapTable('hideColumn', 'Id');
    contactTable.bootstrapTable('hideColumn', 'StartDate');
    getEvents(function(error, events) {
        if (error) {
            console.error(error);
            xalert('Failed to fetch events:'+error, 1, null);
            return;
        }
        
        events.forEach(function(event) {
            console.log(event.StartDate);
            getColor(event.MainUserID).then(function(color) {
                var parsedEvent = {id:event.Id,allDay:event.IsAllDay,editable:true,start:event.StartDate,end:event.EndDate,title:event.Title,backgroundColor:color.color.code,textColor:color.textColor,extendedProps:[{MainUserId:event.MainUserID,EventCache:event}]};
                ec.addEvent(parsedEvent);
                eventCollection.push(ec.getEventById(event.Id));
            }).catch(function(error) {
                console.error('Failed to get color:', error);
            });
        });
        tableReload([...events]);
        console.log(eventCollection);
        var uniqueUserIds = [...new Set(events.map(event => event.MainUserID))];
        uniqueUserIds.forEach(async function(userId) {
            getUserById(async function(error, user) {
                if (error) {
                    console.error('Failed to fetch user:', error);
                    xalert('Failed to fetch user:'+error, 1, null);
                    return;
                }
                var checkbox = document.createElement('div');
                checkbox.classList.add('form-check');
                
                var color = await getColor(user.Id);
                
                checkbox.innerHTML = `
                    <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked${user.Id}" checked userId="${user.Id}" onchange="filterchange()">
                    <label class="form-check-label" for="flexCheckChecked">
                       <span class="badge py-1 m-1 align-middle text-wrap" style="background-color: ${color.color.code}; color: ${color.textColor};">${user.FirstName} ${user.LastName} (${user.Position})</span>
                    </label>
                `;
                document.getElementById('usersList').appendChild(checkbox);
            },userId);
        });
        console.log(uniqueUserIds);


        var urlParams = new URLSearchParams(window.location.search);
        var id = urlParams.get('id');

        if (id) {
            var event = events.find(function(event) {
                return event.Id === parseInt(id);
            });

            if (event) {
                // Code to handle when event is found
                currentID = event.Id;
                openModal(event.Title,event.Plan,event.StartDate,event.EndDate,event.IsAllDay,event.Id);
                console.log('Event found:', event);
            } else {
                // Code to handle when event is not found
                console.log('Event not found');
                xalert('Event not found', 1, null);
            }
        } else {
            // Code to handle when id is not provided in the URL
            console.log('No id provided in the URL');
        }
        


    });

    
};



function setView(view){

    ec.setOption('view',view);

}
function addEvent(){

    var startDate = timeFormater( eventStartDate.value);
    var endDate = timeFormater(eventEndDate.value);
    var thisUser;
    myUserRequest(function(err, user) {
        if (err) {
            console.error('Failed to fetch user:', err);
            xalert('Failed to fetch user:'+err, 1, null);
            return;
        }
        thisUser = user;
    });

    if (currentID === null || currentID === undefined) {
        // Code to handle when currentID is null or undefined
        sendEventRequest(async function(error, response) {
            if (error) {
                xalert('Failed to send event request:'+error, 1, null);
                console.error('Failed to send event request:', error);
                return;
            }
            var id = parseInt(response);
            var color = await getColor(thisUser.Id);
            var eventCache ={
                Id: id,
                Title: eventName.value,
                Description: "",
                StartDate: startDate,
                EndDate: endDate,
                IsAllDay: eventAllDay.checked,
                Plan: eventPlan.value,
                Report: eventReport.value,
                Comment: eventComment.value,
                ConferenceURL: "",
                MainUserID: thisUser.Id,
            
            };
            var event = {id:id,allDay:eventAllDay.checked,editable:true,start:new Date(startDate),end:new Date(endDate),title:eventName.value,backgroundColor:color.color.code,textColor:color.textColor,extendedProps:[{MainUserId:thisUser.Id,EventCache:eventCache}]};
            ec.addEvent(event);
            eventCollection.push(ec.getEventById(id));
            tableReload(eventCollection);
            ecCurrentEvent = null;
            calendarModal.hide();

        }, null, eventName.value,"", startDate, endDate, eventAllDay.checked,eventPlan.value, eventReport.value, eventComment.value, "",
        thisUser.Id
        , 1,Array.from(document.getElementById('usersSelecter').selectedOptions).map(option => parseInt(option.value)),[]);


    
    } else {
        // Code to handle when currentID is not null or undefined
        sendEventRequest(async function(error, response) {
            if (error) {
                xalert('Failed to update event request:'+error, 1, null);
                console.error('Failed to update event request:', error);
                return;
            }
            var color = await getColor(currentEvent.MainUserID);
            var eventCache ={
                Id: currentID,
                Title: eventName.value,
                Description: "",
                StartDate: startDate,
                EndDate: endDate,
                IsAllDay: eventAllDay.checked,
                Plan: eventPlan.value,
                Report: eventReport.value,
                Comment: eventComment.value,
                ConferenceURL: "",
                MainUserID: thisUser.Id,
            
            };
            var event = {id:currentID,allDay:eventAllDay.checked,editable:true,start:new Date(startDate),end: new Date(endDate),title:eventName.value,backgroundColor:color.color.code,textColor:color.textColor,extendedProps:[{MainUserId:currentEvent.MainUserID,EventCache:eventCache}]};
            ec.updateEvent(event);
            var eventIndex = eventCollection.findIndex(event => parseInt(event.id) === currentID);
            if (eventIndex !== -1) {
                eventCollection[eventIndex] = event;
            }
            tableReload(eventCollection);
            ecCurrentEvent = null;
            
            calendarModal.hide();

        },currentID, eventName.value,"", startDate, endDate, eventAllDay.checked,eventPlan.value, eventReport.value, eventComment.value, "",
            currentEvent.MainUserID
        , 1,Array.from(document.getElementById('usersSelecter').selectedOptions).map(option => parseInt(option.value)),[]);

    
    }

    
}



function sendEventRequest(callback,id,title,description,start,end,allday,plan,report,comment,conferenceurl,mainuserid,maincontactID,usersIDs,contactids) {
    var token = readToken();
    var xhr = new XMLHttpRequest();
    var urlEvent = id ? '/biomedapi/events/update' : '/biomedapi/events/create';
    var data = {
        Id: id,
        Title: title,
        Description: description,
        StartDate: timeFormater(start),
        EndDate: timeFormater(end),
        IsAllDay: allday,
        Plan: plan,
        Report: report,
        Comment: comment,
        Location:null,
        Conferenceurl: conferenceurl,
        Mainuserid: mainuserid,
        MaincontactID: maincontactID,
        SubUserIDs: usersIDs,
        SubContactIDs: contactids
    };

    xhr.open('POST', url+urlEvent, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', 'Bearer ' + token);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                callback(null, xhr.responseText); // No error
            } else {
                callback(new Error('Request failed with status ' + xhr.status+' '+xhr.responseText), null);
            }
        }
    };
    xhr.send(JSON.stringify(data));
}


function getEventInfo(eventId, callback) {
    var token = readToken();
    var xhr = new XMLHttpRequest();
    var urlEvent = '/biomedapi/events/' + eventId;

    xhr.open('GET', url + urlEvent, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', 'Bearer ' + token);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                var event = JSON.parse(xhr.responseText);
                callback(null, event); // No error
            } else {
                callback(new Error('Request failed with status ' + xhr.status), null);
            }
        }
    };
    xhr.send();
}


function openModal(ecName,ecPlan,ecStartDate,ecEndDate,allDay,id){


    const modalUsersList = document.getElementById('modalUsersList');
            
    const select = document.getElementById('usersSelecter');
    const groupSelect = document.getElementById('groupSelecter');

    if (id !== null && id !== undefined) {
        getEventInfo(id, function(error, event) {
            if (error) {
                console.error('Failed to fetch event info:', error);
                return;
            }
            // Code to populate modal with event info
            eventName.value = event.Title;
            eventPlan.value = event.Plan;

            // Code to use event info
            /*
            eventStartDate.value = timeFuck(event.StartDate).slice(0, 16);
            eventEndDate.value = timeFuck(event.EndDate).slice(0, 16);
            */
            eventStartDate.value = timeFuck(ecStartDate).slice(0,16);
            eventEndDate.value = timeFuck(ecEndDate).slice(0,16);
            eventComment.value = event.Comment;
            eventReport.value = event.Report;
            eventAllDay.checked = event.IsAllDay;
            currentEvent = event;
           
            // Code to select users in the selectpicker based on event info
            // Code to select users in the selectpicker based on event info
            let mainUser = null;
            getUsers((error, users) => {
                if (error) {
                    console.error('Failed to fetch users:', error);
                    return;
                }
        
                //And main responsible user
                const primaryBadge = document.createElement('span');
                primaryBadge.classList.add('badge', 'bg-info', 'text-dark', 'py-1', 'm-1', 'align-middle', 'text-wrap');
        
                const Muser = users.find(Muser => Muser.Id === event.MainUserID);3
                mainUser = Muser;
                if (Muser) {
                    primaryBadge.innerHTML = `<strong><i class="fi fi-rr-chess-king align-middle mx-1"></i>Primary: </strong>${Muser.FirstName} ${Muser.LastName} (${Muser.Position})`;
                }
                mainuserid = event.MainUserId;
                modalUsersList.appendChild(primaryBadge);
        
        
                select.innerHTML = '';

                users.forEach(user => {
                    if (user.Id !== event.MainUserID) {
                    const option = document.createElement('option');
                    option.value = user.Id;
                    option.textContent = `${user.FirstName} ${user.LastName}`;
                    option.setAttribute('data-subtext', `${user.Position}`);
                    select.appendChild(option);
                    }
                });

                
                
                $(select).on('changed.bs.select', function (e, clickedIndex, isSelected, previousValue) {
                
                    const selectedOptions = Array.from(e.target.selectedOptions);
                    modalUsersList.innerHTML = '';
                    modalUsersList.appendChild(primaryBadge);
                    selectedOptions.forEach(option => {
                        const badge = document.createElement('span');
                        badge.classList.add('badge', 'biomed-bg-accent', 'text-dark', 'py-1', 'm-1', 'align-middle', 'text-wrap');
                        badge.innerHTML = option.getAttribute('data-subtext') ? `${option.textContent} (${option.getAttribute('data-subtext')})` : option.textContent;
                        modalUsersList.appendChild(badge);
                    });
                    //document.getElementById("mainUsersList").innerHTML = modalUsersList.innerHTML;
                });
                
                
                //document.getElementById("mainUsersList").innerHTML = modalUsersList.innerHTML;
                // Refresh the selectpicker to update the options
        
                $(select).selectpicker('refresh');
                const userIds = event.EventUsers.map(leadUser => leadUser.UserId);
            const selectValues = userIds.map(String);
            $(select).selectpicker('val', selectValues);
            groupSelect.innerHTML ='';
            getGroups((err,groups) =>{
                if (err){
                    console.error('Failed to fetch users:',err);
                    return;
                }
                
                groups.forEach((group)=>{
                    const option = document.createElement('option');
                    option.value = group.Id;
                    option.textContent = group.GroupName;
                    groupSelect.appendChild(option);
                });
                $(groupSelect).on('changed.bs.select', function (e, clickedIndex, isSelected, previousValue) {
                    const selectedOptions = Array.from(e.target.selectedOptions);
                    selectedOptions.forEach((option) => {
                        getGroupMembers(option.value,(err,users)=>{
                            if (err){
                                console.error('Failed to fetch users:',err);
                                return;
                            }

                            valSelect = users.GroupUsers.map(user => user.UserId).filter(item => item !== mainUser.Id).map(String);
                            $(select).selectpicker('val', $(select).val().concat(valSelect));
                            console.log(valSelect);

                        });
                    });

                    //document.getElementById("mainUsersList").innerHTML = modalUsersList.innerHTML;
                });
                $(groupSelect).selectpicker('refresh');

            },false);
            $(groupSelect).selectpicker('refresh');
            }, false);
            
            

        });
    }else{
        
        myUserRequest(function(err, user) {
            if (err) {
                console.error('Failed to get myUser:', err);
                xalert('Failed to get myUser:'+err, 1, null);
                return;
            }
            // Use the 'user' variable here
            
            getUsers((error, users) => {
                if (error) {
                    console.error('Failed to fetch users:', error);
                    return;
                }
        
                //And main responsible user
                const primaryBadge = document.createElement('span');
                primaryBadge.classList.add('badge', 'bg-info', 'text-dark', 'py-1', 'm-1', 'align-middle', 'text-wrap');
        
                const Muser = user;
                if (Muser) {
                    primaryBadge.innerHTML = `<strong><i class="fi fi-rr-chess-king align-middle mx-1"></i>Primary: </strong>${Muser.FirstName} ${Muser.LastName} (${Muser.Position})`;
                }
                mainuserid = Muser.Id;
                modalUsersList.appendChild(primaryBadge);
        
                
                select.innerHTML = '';

                users.forEach(user => {
                    if (user.Id !==  Muser.Id) {
                    const option = document.createElement('option');
                    option.value = user.Id;
                    option.textContent = `${user.FirstName} ${user.LastName}`;
                    option.setAttribute('data-subtext', `${user.Position}`);
                    select.appendChild(option);
                    }
                });
                
                
                $(select).on('changed.bs.select', function (e, clickedIndex, isSelected, previousValue) {
                
                    const selectedOptions = Array.from(e.target.selectedOptions);
                    modalUsersList.innerHTML = '';
                    modalUsersList.appendChild(primaryBadge);
                    selectedOptions.forEach(option => {
                        const badge = document.createElement('span');
                        badge.classList.add('badge', 'biomed-bg-accent', 'text-dark', 'py-1', 'm-1', 'align-middle', 'text-wrap');
                        badge.innerHTML = option.getAttribute('data-subtext') ? `${option.textContent} (${option.getAttribute('data-subtext')})` : option.textContent;
                        modalUsersList.appendChild(badge);
                    });
                    //document.getElementById("mainUsersList").innerHTML = modalUsersList.innerHTML;
                });
                
                
                //document.getElementById("mainUsersList").innerHTML = modalUsersList.innerHTML;
                // Refresh the selectpicker to update the options
        
                $(select).selectpicker('refresh');
            }, false);
            groupSelect.innerHTML ='';
            getGroups((err,groups) =>{
                if (err){
                    console.error('Failed to fetch users:',err);
                    return;
                }
                
                groups.forEach((group)=>{
                    const option = document.createElement('option');
                    option.value = group.Id;
                    option.textContent = group.GroupName;
                    groupSelect.appendChild(option);
                });
                $(groupSelect).on('changed.bs.select', function (e, clickedIndex, isSelected, previousValue) {
                    const selectedOptions = Array.from(e.target.selectedOptions);
                    selectedOptions.forEach((option) => {
                        getGroupMembers(option.value,(err,users)=>{
                            if (err){
                                console.error('Failed to fetch users:',err);
                                return;
                            }

                            valSelect = users.GroupUsers.map(user => user.UserId).filter(item => item !== user.Id).map(String);
                            $(select).selectpicker('val', $(select).val().concat(valSelect));
                            console.log(valSelect);

                        });
                    });

                    //document.getElementById("mainUsersList").innerHTML = modalUsersList.innerHTML;
                });

            },false);


            $(groupSelect).selectpicker('refresh');
            /*const userIds = event.EventUsers.map(leadUser => leadUser.UserId);
            const selectValues = userIds.map(String);
            $(select).selectpicker('val', selectValues);*/

            if (ecName !== null && ecName !== undefined) {
                eventName.value = ecName;
            }

            if (ecStartDate !== null && ecStartDate !== undefined) {
                eventStartDate.value = ecStartDate;
            }

            if (ecEndDate !== null && ecEndDate !== undefined) {
                eventEndDate.value = ecEndDate;
            }

            if (allDay !== null && allDay !== undefined) {
                eventAllDay.checked = allDay;
            }



        });


        
    }




    calendarModal.show();
}

function clearModal()
{
    eventName.value = '';
    eventPlan.value = '';
    eventStartDate.value = null;
    eventEndDate.value = null;
    eventAllDay.checked = false;
    eventComment.value = '';
    eventReport.value = '';
    $(select).selectpicker('val', []);
    document.getElementById('modalUsersList').innerHTML = '';
    currentID = null;
    currentEvent = null;
    console.log('Modal cleared');
}

function deleteEvent(){
    
    if (currentID === null || currentID === undefined) {
        // Code to handle when currentID is null or undefined
        xalert('Cannot delete event with null or undefined ID', 2, 5000);
        console.error('Cannot delete event with null or undefined ID');
        clearModal();
        calendarModal.hide();
        return;
    }
    deleteEventRequest(currentID);
}

function deleteEventRequest(eventId) {
    var token = readToken();
    var xhr = new XMLHttpRequest();
    var urlEvent = '/biomedapi/events/delete';

    xhr.open('POST', url + urlEvent, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', 'Bearer ' + token);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                // Code to handle successful deletion
                console.log('Event deleted successfully');
                ec.removeEventById(eventId);
                eventCollection = eventCollection.filter(event => parseInt(event.id) !== eventId);
                xalert('Event deleted successfully', 0, 5000);
                clearModal();
                calendarModal.hide();
                tableReload(eventCollection);
            } else {
                // Code to handle deletion error
                console.error('Failed to delete event:', xhr.responseText);
                xalert('Failed to delete event', 1, null);
            }
        }
    };
    xhr.send(JSON.stringify({ Id: eventId }));
}


function operateFormatter(value, row, index) {
    return [
      '<a class="edit text-primary link link-underline link-underline-opacity-0" href="javascript:void(0)" title="Edit">',
      '<i class="fi fi-rr-edit"></i>',
      '</a>  '
    ].join('')
  }

  window.operateEvents = {
    'click .edit': function (e, value, row, index) {
      console.log('You click edit icon, row: ', row);
        currentID = row.Id;
        openModal(row.Title,row.Plan,row.StartDate,row.EndDate,row.IsAllDay,row.Id);
    

        
    }

}

function tableReload(data){
    console.log("Trying to reload table");
    contactTable.bootstrapTable('removeAll');

    var dataCache = [...data];
    if(Array.isArray(data) && data.length > 0 && data[0].id){
        var dataCache = data.map(item => item.extendedProps[0].EventCache);
        dataCache.forEach(function(data) {
            data.StartDateClone = timeFormater(new Date(data.StartDate)).toString();
            data.EndDateClone = timeFormater(new Date(data.EndDate)).toString();
            getUserById((err,user)=>{
                if(err){
                    xalert("Error Get User By ID:"+data.MainUserID,1,-1);
                    return;
                }
                data.MainResponsible = user.FirstName +" "+user.LastName+" ("+user.Position+")";
            },data.MainUserID);
            
        });
        contactTable.bootstrapTable('load', dataCache);
    }else{
        dataCache.forEach(function(data) {
            data.StartDateClone = timeFormater(new Date(data.StartDate)).toString();
            data.EndDateClone = timeFormater(new Date(data.EndDate)).toString();
            getUserById((err,user)=>{
                if(err){
                    xalert("Error Get User By ID:"+data.MainUserID,1,-1);
                    return;
                }
                data.MainResponsible = user.FirstName +" "+user.LastName+" ("+user.Position+")";
             },data.MainUserID);
        });
        

        contactTable.bootstrapTable('load', dataCache);
        

    }
    //timeFuck(Date.now());    
    contactTable.bootstrapTable('sortBy', {field: 'StartDate', sortOrder: 'asc'});
}

function cellStyle(row, index){

    return {classes:"fs-6 align-top"}
}