var pipelineCache = [];
function createModalPopup() {
    // Create the modal element
    const modal = document.createElement('div');
    modal.id = 'pipelineModal';
    
    modal.classList.add('modal', 'fade');
    modal.setAttribute('tabindex', '-1');
    modal.setAttribute('role', 'dialog');

    // Create the modal dialog element
    const modalDialog = document.createElement('div');
    modalDialog.classList.add('modal-dialog');
    modal.appendChild(modalDialog);

    // Create the modal content element
    const modalContent = document.createElement('div');
    modalContent.classList.add('modal-content');
    modalDialog.appendChild(modalContent);

    // Create the modal header element
    const modalHeader = document.createElement('div');
    modalHeader.classList.add('modal-header');
    modalContent.appendChild(modalHeader);

    // Create the modal title element
    const modalTitle = document.createElement('h5');
    modalTitle.classList.add('modal-title');
    modalTitle.textContent = 'Add Pipeline';
    modalHeader.appendChild(modalTitle);

    // Create the close button element
    const closeButton = document.createElement('button');
    closeButton.setAttribute('type', 'button');
    closeButton.classList.add('btn-close');
    closeButton.setAttribute('data-bs-dismiss', 'modal');
    closeButton.setAttribute('aria-label', 'Close');
    closeButton.addEventListener('click', removeModalPopup );
    modalHeader.appendChild(closeButton);

    // Create the modal body element
    const modalBody = document.createElement('div');
    modalBody.classList.add('modal-body');
    modalContent.appendChild(modalBody);

    // Create the text input element
    const inputGroup = document.createElement('div');
    inputGroup.classList.add('input-group', 'input-group-sm', 'mb-3');
    modalBody.appendChild(inputGroup);

    const inputGroupText = document.createElement('span');
    inputGroupText.classList.add('input-group-text');
    inputGroupText.style.width = '60px';
    inputGroupText.textContent = 'Title';
    inputGroup.appendChild(inputGroupText);

    const input = document.createElement('input');
    input.setAttribute('type', 'text');
    input.classList.add('form-control');
    input.setAttribute('aria-label', 'Sizing example input');
    input.setAttribute('aria-describedby', 'inputGroup-sizing-sm');
    input.id = 'pipelineTitle';
    inputGroup.appendChild(input);

    // Create the input group element
    const inputGroup2 = document.createElement('div');
    inputGroup2.classList.add('input-group', 'input-group-sm', 'mb-3');
    modalBody.appendChild(inputGroup2);

    // Create the input group text element
    const inputGroupText2 = document.createElement('span');
    inputGroupText2.classList.add('input-group-text');
    inputGroupText2.style.width = '60px';
    inputGroupText2.textContent = 'Order';
    inputGroup2.appendChild(inputGroupText2);

    // Create the input element
    const input2 = document.createElement('input');
    input2.setAttribute('type', 'number');
    input2.classList.add('form-control');
    input2.setAttribute('aria-label', 'Sizing example input');
    input2.setAttribute('aria-describedby', 'inputGroup-sizing-sm');
    input2.value = 0;
    input2.id = 'pipelineOrder';
    inputGroup2.appendChild(input2);

    // Create the button element
    const addButton = document.createElement('button');
    addButton.textContent = 'Add';
    addButton.classList.add('btn', 'btn-primary');
    addButton.setAttribute('data-bs-dismiss', 'modal');
    addButton.setAttribute('aria-label', 'Close');
    addButton.addEventListener('click', createCRMPipeline);
    modalBody.appendChild(addButton);

    // Append the modal to the document body

    document.body.appendChild(modal);
    var crmModal = new bootstrap.Modal("#pipelineModal", {focus: true,backdrop: 'static'});

    /*var wtfisthis = bootstrap.Modal.getInstance(document.getElementById('pipelineModal'));
    wtfisthis.addEventListener('hidden.bs.modal', function (event) {

        wtfisthis.dispose();
    });*/

    

    crmModal.show();
}

function createCRMPipeline(){
    createPipelineRequest();
    removeModalPopup();
}

function createPipelineRequest() {
    const token = readToken();
    const name = document.getElementById('pipelineTitle').value;
    const order = parseInt(document.getElementById('pipelineOrder').value);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', url+ '/biomedapi/crm/pipelines/create', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Request successful
                xalert('Pipeline created successfully',0,-1);
                
            } else {
                // Request failed
                xalert('Error '+xhr.status+" "+xhr.responseText,1,-1);
                
            }
        }
    };
    let rawdata = {
        PipelineName: name,
        Order: order
    };
    
    const data = JSON.stringify(rawdata);
    xhr.send(data);
}


function removeModalPopup() {
    document.getElementById('pipelineModal').remove();
}




window.onload = function() {
    getPipelines(function(error, pipelines) {
        if (error) {
            xalert('Error ' + error, 1, -1);
            // Handle the error here
        } else {
            const pipelineContainer = document.getElementById('pipelineContainer');
            pipelineCache = pipelines;
            pipelines.forEach(pipeline => {
                const pipelineElement = document.createElement('div');
                pipelineElement.classList.add('col', 'm-0', 'p-0', 'px-2', 'py-2');
                pipelineElement.style.minWidth = '256px';
                pipelineElement.innerHTML = `
                    <div class="m-1 p-1 row" id="${pipeline.Id}">
                        <h6 class="col-11 p-0 m-0 py-auto fw-bold auto-fit py-1">${pipeline.PipelineName}</h6>
                        <div class="btn-group m-0 p-0 d-grid justify-content-sm-end ms-auto col-1 dropstart">
                            <button class="btn btn-secondary btn-sm rounded m-0 p-0 ms-auto auto-fit" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fi fi-rr-menu-dots-vertical"></i>
                            </button>
                            <ul class="dropdown-menu">
                                <li><h6 class="dropdown-header">Quick Action</h6></li>
                                <li><a class="dropdown-item" href="#">Create Lead</a></li>
                            </ul>
                        </div>
                    </div>
                `;
                pipelineContainer.appendChild(pipelineElement);
            });
        }
        getLeads(function(error, leads) {
            if (error) {
                xalert('Error ' + error , 1, -1);
                // Handle the error here
            } else {
                leads.forEach(lead => {
                    
                    const leadsContainer = document.getElementById(lead.CRMPipelineId);
                    const leadElement = document.createElement('div');
                    var mainuser;
                    getUsers(
                    function
                    (err,users){
                    if (err) {
    
                        console.error(err);
                        mainuser = '';
                        return;
                    }
                    let temp = users.find(user => user.Id === lead.MainUserId);
                    if(temp === undefined||temp === null){
                        mainuser = '';
                        return;
                    }
                    let tempStr = temp.FirstName+" "+temp.LastName;
                    mainuser = tempStr;
                    return  ;
                },false);
    
                    leadElement.innerHTML = `
                        <div class="m-1 p-3 my-0 border bg-white"><!-- Single Lead-->
                            <div class="m-0 p-0 row"> 
                                <p class="m-0 p-0 py-0 fw-bold auto-fit col-9">${lead.LeadName}</p>
                                
                                <div class="btn-group m-0 p-0 d-grid justify-content-sm-end ms-auto col-3 dropstart">
                                    <button class="btn btn-secondary btn-sm rounded m-0 p-0 ms-auto auto-fit" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fi fi-rr-menu-dots-vertical"></i>
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li><h6 class="dropdown-header">Quick Action</h6></li>
                                        <li><a class="dropdown-item" href="#" onclick="openModal()">Create event from this lead</a></li>
                                        <li><a class="dropdown-item" href="#">Edit this lead</a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><h6 class="dropdown-header">Change Status to...</h6></li>
                                        <li><a class="dropdown-item" href="#">Sales Plan</a></li>
                                        <li><a class="dropdown-item" href="#">Initiate</a></li>
                                        <li><a class="dropdown-item" href="#">Following Up</a></li>
                                        <li><a class="dropdown-item" href="#">Qualified</a></li>
                                        <li><a class="dropdown-item" href="#">Confirmed Order</a></li>
                                        <li><a class="dropdown-item" href="#">Proposition</a></li>
                                        <li><a class="dropdown-item" href="#">PO Issued</a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item text-danger" href="#">Delete this lead</a></li>
                                    </ul>
                                </div>
    
                            </div>
                            <p class="m-0 py-1 fw-normal">${lead.ExpectedRevenue} THB</p>
                            <p class="m-0 py-1 fw-normal">${timeFriendly(lead.Creation)}</p>
                            <p class="m-0 py-1 fw-normal">${mainuser}</p>
                            <p class="m-0 py-0"><i class="fi fi-rr-circle-star text-warning"></i><i class="fi fi-rr-circle-star text-warning"></i><i class="fi fi-rr-circle-star text-secondary"></i></p>
                        </div>
                    `;
                    leadsContainer.appendChild(leadElement);
    
                });
            }
            
        });
    
    
    
    },true);



    


};



function createLeadPopup() {
    // Create the modal element
    const modal = document.createElement('div');
    modal.id = 'leadModal';
    
    modal.classList.add('modal', 'fade');
    modal.setAttribute('tabindex', '-1');
    modal.setAttribute('role', 'dialog');

    // Create the modal dialog element
    const modalDialog = document.createElement('div');
    modalDialog.classList.add('modal-dialog');
    modal.appendChild(modalDialog);

    // Create the modal content element
    const modalContent = document.createElement('div');
    modalContent.classList.add('modal-content');
    modalDialog.appendChild(modalContent);

    // Create the modal header element
    const modalHeader = document.createElement('div');
    modalHeader.classList.add('modal-header');
    modalContent.appendChild(modalHeader);

    // Create the modal title element
    const modalTitle = document.createElement('h5');
    modalTitle.classList.add('modal-title');
    modalTitle.textContent = 'Create Lead';
    modalHeader.appendChild(modalTitle);

    // Create the close button element
    const closeButton = document.createElement('button');
    closeButton.setAttribute('type', 'button');
    closeButton.classList.add('btn-close');
    closeButton.setAttribute('data-bs-dismiss', 'modal');
    closeButton.setAttribute('aria-label', 'Close');
    closeButton.addEventListener('click', removeLeadPopup );
    modalHeader.appendChild(closeButton);

    // Create the modal body element
    const modalBody = document.createElement('div');
    modalBody.classList.add('modal-body');
    modalContent.appendChild(modalBody);

    // Create the text input element for LeadName
    const leadNameInputGroup = document.createElement('div');
    leadNameInputGroup.classList.add('input-group', 'input-group-sm', 'mb-3');
    modalBody.appendChild(leadNameInputGroup);

    const leadNameInputGroupText = document.createElement('span');
    leadNameInputGroupText.classList.add('input-group-text');
    leadNameInputGroupText.style.width = '100px';
    leadNameInputGroupText.textContent = 'Lead Name';
    leadNameInputGroup.appendChild(leadNameInputGroupText);

    const leadNameInput = document.createElement('input');
    leadNameInput.setAttribute('type', 'text');
    leadNameInput.classList.add('form-control');
    leadNameInput.setAttribute('aria-label', 'Sizing example input');
    leadNameInput.setAttribute('aria-describedby', 'inputGroup-sizing-sm');
    leadNameInput.id = 'leadName';
    leadNameInputGroup.appendChild(leadNameInput);

    // Create the dropdown selection element
    const pipelineDropdown = document.createElement('select');
    pipelineDropdown.classList.add('form-select', 'mb-3');
    pipelineDropdown.setAttribute('aria-label', 'Select Pipeline');
    pipelineDropdown.id = 'pipelineDropdown';
    modalBody.appendChild(pipelineDropdown);

    // Add options to the dropdown from pipelineCache
    pipelineCache.forEach(pipeline => {
        const option = document.createElement('option');
        option.value = pipeline.Id;
        option.textContent = pipeline.PipelineName;
        pipelineDropdown.appendChild(option);
    });

    // Create the button element
    const createLeadButton = document.createElement('button');
    createLeadButton.textContent = 'Create Lead';
    createLeadButton.classList.add('btn', 'btn-primary');
    createLeadButton.setAttribute('data-bs-dismiss', 'modal');
    createLeadButton.setAttribute('aria-label', 'Close');
    createLeadButton.addEventListener('click', createLead);
    modalBody.appendChild(createLeadButton);

    // Append the modal to the document body
    document.body.appendChild(modal);
    var leadModal = new bootstrap.Modal("#leadModal", {focus: true});
    leadModal.show();
}

function createLead(){
    createLeadRequest();
    removeLeadPopup();
}

function createLeadRequest() {
    const token = readToken();
    const leadName = document.getElementById('leadName').value;
    const pipelineId = document.getElementById('pipelineDropdown').value;

    const xhr = new XMLHttpRequest();
    xhr.open('POST', url + '/biomedapi/leads/create', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Request successful
                xalert('Lead created successfully', 0, -1);
                setTimeout(() => {
                    const leadId = xhr.responseText;
                    window.location.href = `crm-detail.html?leadid=${leadId}`;
                }, 2000);
            } else {
                // Request failed
                xalert('Error ' + xhr.status + " " + xhr.responseText, 1, -1);
            }
        }
    };
    let rawdata = {
        LeadName: leadName,
        PipelineId: pipelineId
    };
    
    const data = JSON.stringify(rawdata);
    xhr.send(data);
}

function removeLeadPopup() {
    document.getElementById('leadModal').remove();
}

