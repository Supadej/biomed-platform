var url = ""; // empty string for production

const currentYear = new Date().getFullYear();
const Translator = [];

for (let year = 2023; year <= currentYear + 2; year++) {
  for (let quarter = 1; quarter <= 4; quarter++) {
    Translator.push(`Q${quarter} ${year}`);
  }
}

const permissionsType = [
  { value: 0, name: 'noType', description: 'Placeholder it do nothing' },
  { value: 1, name: 'user_manage', description: 'Manage users (Can view/edit any users)' },
  { value: 2, name: 'user_permission_manage', description: 'Manage user permissions(Can view/edit any permission of users)' },
  { value: 3, name: 'lead_creation', description: 'Create leads' },
  { value: 4, name: 'lead_manage', description: 'Manage leads (Can view/edit any leads)' },
  { value: 5, name: 'contact_manage', description: 'Manage contacts (Can create/view/edit any contacts)' },
  { value: 6, name: 'event_manage', description: 'Manage events (Can view/edit any events)' },
  { value: 7, name: 'project_manage', description: 'Manage projects (Can view/edit any projects)' },
  { value: 8, name: 'log_manage', description: 'Manage logs (Can view/edit any logs)' },
  { value: 9, name: 'helpdesk_manage', description: 'Manage helpdesk (Can view/edit any helpdesk ticket)' },
  { value: 10, name: 'crm_access', description: 'No use right now' },
  { value: 11, name: 'project_access', description: 'Create projects' },
  { value: 12, name: 'event_access', description: 'Create events' },
  { value: 13, name: 'contact_access', description: 'Export contacts' },
  { value: 18, name: 'helpdesk_access', description: 'Access helpdesk (Can view/create any helpdesk ticket)' },
  { value: 19, name: 'inventory_access', description: 'Access inventory (Can view inventory)' },
  { value: 20, name: 'brand_manage', description: 'Manage brands (Can view/edit any brand)' },
  { value: 21, name: 'product_manage', description: 'Manage products (Can view/edit any product)' },
  { value: 22, name: 'stock_manage', description: 'Manage stock (Can view/edit any stock)' }

];

const permissionsTypeIndividual = [
  { value: 14, name: 'lead_manage_individual', description: 'Manage individual leads (View/edit leads of specific users)' },
  { value: 15, name: 'helpdesk_manage_individual', description: 'Manage individual helpdesk tickets (View/edit helpdesk tickets of specific users)' },
  { value: 16, name: 'event_manage_individual', description: 'Manage individual events (View/edit events of specific users)' },
  { value: 17, name: 'project_manage_individual', description: 'Manage individual projects (View/edit projects of specific users)' }
];


function isDefined(input) {
  if (input !== undefined && input !== null) return true;
  return false;
}




function sendLoginRequest(username, password, callback) {
  var xhr = new XMLHttpRequest();
  xhr.open("POST", url + "/biomedapi/login", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        /*var response = JSON.parse(xhr.responseText);
                var token = response.token;*/
        // Save token to cookie
        document.cookie = "jwtToken=" + xhr.responseText;
        sessionStorage.setItem("jwtToken", xhr.responseText);
        myUserRequest(function (error, response) {
          if (error) {
            console.error(error);
            // Handle error
          } else {
            xalert(
              "Welcome " + response.FirstName + " " + response.LastName,
              0,
              -1
            );
            ////console.log(response);
            // Handle response
          }
        }, true);

        callback(null, xhr.responseText);
      } else if (xhr.status === 400) {
        callback(new Error("Incorrect Username/Password"), null);
      } else {
        callback(new Error(xhr.responseText), xhr.status);
      }
    }
  };
  var data = JSON.stringify({ username: username, password: password });
  xhr.send(data);
}

function myPermission(callback) {
  myUserRequest((error, user) => {

    if (error) {
      console.error('Failed to fetch user:', error);
      xalert('Failed to fetch user', 1, -1);
      return;
    }
    //console.log(user);
    var permissions = user.Permissions;
    var mainPermissions = permissions.filter(permission => !permission.Type.includes("individual"));
    var individualPermissions = permissions.filter(permission => permission.Type.includes("individual"));
    var FullPermissions = {
      "MainPermissions":mainPermissions,
      "IndividualPermissions":individualPermissions  
    };
    //console.log(FullPermissions);
    callback(null, FullPermissions);

  });

}

function getQuarterDateRange(quarter, year) {

  const yearAmp = year -1;
  //xalert("Year Amp: "+yearAmp,0,-1);
  //xalert("Quarter: "+quarter,0,-1);
  if (quarter === 0) {
      const quarterStartMonths = [5, 8, 11, 2]; // May, August, November, February
      const quarterEndMonths = [7, 10, 1, 4]; // July, October, January, April

      const quarterStartMonth = quarterStartMonths[0];
      const quarterEndMonth = quarterEndMonths[3];

      const startDate = new Date(`20${yearAmp}-${quarterStartMonth}-01`);
      const endDate = new Date(`20${yearAmp + 1}-${quarterEndMonth}-${getDaysInMonth(quarterEndMonth, yearAmp + 1)}`);
      endDate.setHours(23, 59, 59);
      //console.log("Quarter to Range",startDate, endDate);
      
      return {
          startDate,
          endDate
      };
  }
  const quarterStartMonths = [5, 8, 11, 2]; // May, August, November, February
  const quarterEndMonths = [7, 10, 1, 4]; // July, October, December, March
  if (quarter < 1 || quarter > 4) {
      throw new Error('Invalid quarter');
  }

  if (yearAmp < 0 || yearAmp > 99) {
      throw new Error('Invalid year');
  }
  let startYear = parseInt(yearAmp);
  let endYear = parseInt(yearAmp);
  if (quarter === 4) {
      startYear += 1;
      endYear += 1;
  }
  if (quarter === 3) {
      endYear += 1;
  }


  const quarterStartMonth = quarterStartMonths[quarter - 1];
  const quarterEndMonth = quarterEndMonths[quarter - 1];

  let startDate = new Date(`20${startYear.toString()}-${quarterStartMonth}-01`);
  let endDate = new Date(`20${endYear.toString()}-${quarterEndMonth}-${getDaysInMonth(quarterEndMonth, endYear.toString())}`);
  startDate.setHours(0, 0, 0);
  endDate.setHours(23, 59, 59);
  if(iOS()){
    console.warn("iOS detected attempting to fix date");
    console.warn("Before",startDate,endDate);
    startDate.setFullYear(parseInt('20'+startYear.toString()),quarterStartMonth-1,1);
    endDate.setFullYear(parseInt('20'+endYear.toString()),quarterEndMonth-1,getDaysInMonth(quarterEndMonth, endYear.toString()));
    console.warn("After",startDate,endDate);
    //xalert("iOS Detected",2,-1);
    //xalert(startDate,2,-1);
    //xalert(endDate,2,-1);
  }
  //console.log("Quarter to Range",startDate, endDate);
  return {
      startDate,
      endDate
  };
}

function getDaysInMonth(month, year) {
  return new Date(year, month, 0).getDate();
}


function myUserRequest(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("myUser");
  }
  var myUser = sessionStorage.getItem("myUser");
  if (myUser !== null) {
    if (callback === null) {
      return;
    }
    callback(null, JSON.parse(myUser));
    return;
  }

  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/myuser", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  var token = readToken();
  if (token === null) {
    callback("Token not found", null);
    return;
  }
  xhr.setRequestHeader("Authorization", "Bearer " + token);
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        var response = JSON.parse(xhr.responseText);
        // Save user object in session storage
        sessionStorage.setItem("myUser", JSON.stringify(response));
        if (callback === null) {
          return;
        }
        callback(null, response);
      } else {
        if (callback === null) {
          return;
        }
        callback(new Error(xhr.responseText), xhr.status);
      }
    }
  };
  xhr.send();
}

function decodeJwtPayload(token) {
  // 1. Split out the payload (second segment)
  const base64Url = token.split('.')[1];
  // 2. Convert from base64url to base64
  const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
  // 3. atob() gives us the raw JSON string
  const jsonString = decodeURIComponent(
    atob(base64)
      .split('')
      .map(c => {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
      })
      .join('')
  );
  // 4. Parse and return
  return JSON.parse(jsonString);
}

function readToken() {
  var token = null;
  if (sessionStorage.getItem("jwtToken")) {
    token = sessionStorage.getItem("jwtToken");
  }else{
    var cookies = document.cookie.split(";");
    for (var i = 0; i < cookies.length; i++) {
      var cookie = cookies[i].trim();
      if (cookie.startsWith("jwtToken=")) {
        token = cookie.substring("jwtToken=".length, cookie.length);
        break;
      }
    }
  }
  
  if (token === null) {
    window.location.href = "./login.html";
    return null;
  }

  const payload = decodeJwtPayload(token);
  console.log(payload);                  // see all claims
  const expSeconds = payload.exp;        // typically a UNIX timestamp (seconds)
  const expiresAt   = new Date(expSeconds * 1000);
  console.log('Expires at:', expiresAt);

  // Check if it’s already expired:
  if (Date.now() >= expSeconds * 1000) {
    console.log('Token has expired!');
    removeToken();
  } else {
    console.log(`Token still valid for ${(expSeconds * 1000 - Date.now()) / 1000} seconds`);
    return token;
  }

  return null;
}

function removeToken() {
    //console.log("Removing token");
    document.cookie = "jwtToken=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=*;";
    sessionStorage.removeItem("myUser");
    sessionStorage.removeItem("users");
    sessionStorage.removeItem("pipelines");
    sessionStorage.removeItem("groups");
    clearCache();
    window.location.href = "./login.html";
    //console.log(readToken());
}

function getEvents(callback,query) {
    var token = readToken();
    var xhr = new XMLHttpRequest();
    if(query === undefined || query === null){
        xhr.open('GET', url+'/biomedapi/events', true);
    }
    else{
        xhr.open('POST', url+'/biomedapi/events', true);
    }
    //xhr.open('GET', url+'/biomedapi/events', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', 'Bearer ' + token);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                var events = JSON.parse(xhr.responseText);
                //console.log(events);
                callback(null, events);
            } else {
                callback('Request failed with status ' + xhr.status+" error:"+xhr.responseText+"\nRequest:"+JSON.stringify(query), null);
            }
        }
    };
    if(query !== undefined && query !== null){
        xhr.send(JSON.stringify(query));
    }
    else{
        xhr.send();
    }
}

function xalert(text, style, time) {
  document.body.scrollTop = 0; // For Safari
  document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
  var alertBar = document.getElementById("alert-bar");
  alertBar.innerHTML = ""; // add // for debuging
  var styleClass = "";
  var styleText = "";

  switch (style) {
    case 0:
      styleClass = "success";
      styleText = "<strong>Successful</strong>";
      break;
    case 1:
      styleClass = "danger";
      styleText = "<strong>Error</strong>";
      break;
    case 2:
      styleClass = "warning";
      styleText = "<strong>Warning</strong>";
      break;
    case 3:
      styleClass = "info";
      styleText = "<strong>Info</strong>";
      break;
    default:
      styleClass = "info";
      styleText = "<strong>Info</strong>";
      break;
  }

  var alertElement = document.createElement("div");
  alertElement.classList.add(
    "alert",
    "alert-" + styleClass,
    "my-3",
    "mx-2",
    "text-wrap",
    "text-break"
  );
  alertElement.setAttribute("role", "alert");
  alertElement.innerHTML = styleText + "-" + text;

  alertBar.appendChild(alertElement);

  if (time !== -1 && time !== null) {
    setTimeout(function () {
      alertElement.remove();
    }, time);
  }
}
getUserById = function (callback, id) {
  intid = parseInt(id);
  if (isNaN(intid)) {
    callback(new Error("Invalid ID: ID should be an integer"), null);
    return;
  }

  getUsers((error, users) => {
    if (error) {
      console.error('Failed to fetch users:', error);
      return;
    }
    const user = users.find(user => user.Id === intid);
    callback(null, user);
  }, false);
}

function getUsers(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("users");
  }
  var users = sessionStorage.getItem("users");
  if (users !== null) {
    callback(null, JSON.parse(users));
    return;
  }
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/users", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());
  xhr.onload = function () {
    if (xhr.status === 200) {
      var users = JSON.parse(xhr.responseText);
      sessionStorage.setItem("users", JSON.stringify(users));
      callback(null, users);
    } else {
      callback(new Error(xhr.responseText), null);
    }
  };
  xhr.onerror = function () {
    callback(new Error("Request failed"), null);
  };
  xhr.send();
  
}

function getPipelines(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("pipelines");
  }
  var pipelines = sessionStorage.getItem("pipelines");
  if (pipelines !== null) {
    callback(null, JSON.parse(pipelines));
    return;
  }
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/crm/pipelines", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());
  xhr.onload = function () {
    if (xhr.status === 200) {
      var pipelines = JSON.parse(xhr.responseText);
      pipelines.sort((a, b) => a.Order - b.Order);
      sessionStorage.setItem("pipelines", JSON.stringify(pipelines));
      callback(null, pipelines);
    } else {
      callback(new Error(xhr.responseText), null);
    }
  };
  xhr.onerror = function () {
    callback(new Error("Request failed"), null);
  };
  xhr.send();
}

function isValidGuid(input) {
  var guidRegex =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return guidRegex.test(input);
}

function iOS() {
  //xalert(navigator.userAgent,3,-1);
  var iOS = /(iPad|iPhone|iPod|OS X)/g.test(navigator.userAgent);
  return iOS;
}


function timeFormater(input) {
  const options = {
    month: "numeric",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "numeric",
    second: "numeric",
    hour12: true,
  };
  //'en-US', options
  // Create DateRange record
  var temp = new Date(input).toLocaleString("en-US", options);
  //console.log(temp);
  /*if(iOS()){
    console.warn("iOS detected attempting to fix date");
    console.warn("Before",temp);
    temp = temp.replace(/-/g, "/");
    console.warn("After",temp);
  }*/
  return temp;
}
function timeIsoString(input) {
  const date = new Date(input);
  return date.toISOString();
}


function timeFriendly(input) {
  const options = {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  };

  var temp = new Date(input).toLocaleString("en-US", options);
  return temp;
}

function timeFriendlyString(input) {
  const date = new Date(input);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  const seconds = String(date.getSeconds()).padStart(2, "0");
  const ampm = hours >= 12 ? "PM" : "AM";

  const formattedDate = `${month}-${day}-${year}`;
  const formattedTime = `${hours}:${minutes}:${seconds} ${ampm}`;

  return `${formattedDate} ${formattedTime}`;
}

function getLeads(callback,query = null,deep = false) {
  const token = readToken();

  const xhr = new XMLHttpRequest();
  if(query === null){
    xhr.open("POST", url + "/biomedapi/leads", true);
    query = {};
  }
  else{
    xhr.open("POST", url + "/biomedapi/leads", true);
  }
  if (deep === true) {
    query = { "DeepDetails": true };
  }
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", `Bearer ${token}`);
  xhr.onreadystatechange = function () {
    if (xhr.readyState === XMLHttpRequest.DONE) {
      if (xhr.status === 200) {
        // Request successful
        //console.log(xhr.responseText);
        const leads = JSON.parse(xhr.responseText);

        callback(null, leads);
      } else {
        // Request failed
        xalert("Error " + xhr.status + " " + xhr.responseText+"\nRequest:"+JSON.stringify(query), 1, -1);
        callback(xhr.status, null);
      }
    }
  };
  if(query !== null){
    xhr.send(JSON.stringify(query));
  }
  else{
    xhr.send();
  }
}

function timeFuck(input) {
  date = new Date(input);

  // Extract the components in local time
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");

  // Format the datetime-local value
  const localDateTimeString = `${year}-${month}-${day}T${hours}:${minutes}`;

  return localDateTimeString;
}

async function getColor(inputNumber) {
  if (typeof inputNumber !== 'number' || isNaN(inputNumber)) {
    inputNumber = 0;
  }
  if (sessionStorage.getItem("colors")) {
    var colors = JSON.parse(sessionStorage.getItem("colors"));
    // Rest of the code that uses the colors
  } else {
    const response = await fetch("colors.json");
    var colors = await response.json();
    sessionStorage.setItem("colors", JSON.stringify(colors));
    // Rest of the code that uses the colors
  }
  // Define the color categories in the order they should be returned
  const colorCategories = [
    "red",
    "orange",
    "yellow",
    "green",
    "blue",
    "purple",
    "pink",
    "brown",
    "black",
    "gray",
    "white",
  ];

  // Calculate the color category and index within that category

  const colorCategory = inputNumber % colorCategories.length;
  const colorIndex = Math.floor(inputNumber / colorCategories.length);

  // Get the color and its hex code
  const color = colors[colorCategories[colorCategory]][colorIndex];

  const hexCode = color.code;

  // Calculate the brightness of the color to determine the text color
  const r = parseInt(hexCode.slice(1, 3), 16);
  const g = parseInt(hexCode.slice(3, 5), 16);
  const b = parseInt(hexCode.slice(5, 7), 16);
  const brightness = Math.round((r * 299 + g * 587 + b * 114) / 1000);
  const textColor = brightness > 125 ? "black" : "white";
  //console.log({ color: color, textColor: textColor });
  // Return the color and the text color
  return { color: color, textColor: textColor};
}

function getGroups(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("groups");
  }
  var groups = sessionStorage.getItem("groups");
  if (groups !== null) {
    callback(null, JSON.parse(groups));
    return;
  }
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/groups", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());
  xhr.onload = function () {
    if (xhr.status === 200) {
      var groups = JSON.parse(xhr.responseText);
      callback(null, groups);
      sessionStorage.setItem("groups", JSON.stringify(groups));
    } else {
      callback(new Error(xhr.responseText), null);
    }
  };
  xhr.onerror = function () {
    callback(new Error("Request failed"), null);
  };
  xhr.send();
}
async function promiseGroups(force = false) {
  return new Promise((resolve, reject) => {
    getGroups((error, groups) => {
      if (error) {
        console.error('Failed to fetch groups:', error);
        reject(error);
        return;
      }
      resolve(groups);
    }, force);
  });
}

function getGroupMembers(groupId, callback) {
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/groups/" + groupId, true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());
  xhr.onload = function () {
    if (xhr.status === 200) {
      var members = JSON.parse(xhr.responseText);
      //console.log(members);
      callback(null, members);
    } else {
      callback(new Error(xhr.responseText), null);
    }
  };
  xhr.onerror = function () {
    callback(new Error("Request failed"), null);
  };
  xhr.send();
}
function promiseGroupMembers(groupId) {
  return new Promise((resolve, reject) => {
    getGroupMembers(groupId, (error, members) => {
      if (error) {
        console.error('Failed to fetch group members:', error);
        reject(error);
        return;
      }
      resolve(members);
    });
  });
}


let timeoutId;

function startShaking(button, redirect) {
  button.classList.add("shake");
  timeoutId = setTimeout(() => {
    redirect();
  }, 1000);
}

function stopShaking(button) {
    clearTimeout(timeoutId);
    button.classList.remove('shake');
}


function getContacts(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("contacts");
    Object.keys(sessionStorage).forEach(key => {
      if (key.startsWith("contact:")) {
        sessionStorage.removeItem(key);
      }
    });
  }
  var contacts = sessionStorage.getItem("contacts");

  if (contacts !== null) {
    callback(null, JSON.parse(contacts));

  } else {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url + "/biomedapi/contacts", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onreadystatechange = function () {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          var contacts = JSON.parse(xhr.responseText);
          sessionStorage.setItem("contacts", JSON.stringify(contacts));
          callback(null, contacts);
        } else {
          callback(new Error("Failed to get contacts"), null);
        }
      }
    };
    xhr.send();
  }
}

function getContactById(id, callback) {
  var contact = sessionStorage.getItem("contact:"+id);
  if (contact !== null) {
    callback(null, JSON.parse(contact));
  } else {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", url + "/biomedapi/contacts/" + id, true);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.setRequestHeader("Authorization", "Bearer " + readToken());
        xhr.onload = function () {
          if (xhr.readyState === xhr.DONE) {
            if (xhr.status === 200) {
              var contact = JSON.parse(xhr.responseText);
              sessionStorage.setItem("contact:"+id, JSON.stringify(contact));
              callback(null, contact);
            } else {
              callback("Error: " + xhr.status);
            }
          }
        };
        xhr.onerror = function () {
          callback("Request failed");
        };
        xhr.send();
      }
}

function getIDFromSelection(selection) {
  return Array.from(
    selection.selectedOptions
  ).map((option) => parseInt(option.value))
}

function clearCache () {
  sessionStorage.clear();
}


function getBillings(callback,force) {
  if(force === true){
    sessionStorage.removeItem("billing");
  }
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/billinginformations", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());
  xhr.onload = function () {
    if (xhr.status === 200) {
      var billing = JSON.parse(xhr.responseText);
      sessionStorage.setItem("billing", JSON.stringify(billing));
      callback(null, billing);
    } else {
      callback(new Error(xhr.responseText), null);
    }
  };
  xhr.onerror = function () {
    callback(new Error("Request failed"), null);
  };
  xhr.send();
}

function getProducts(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("product");
  }
  var product = sessionStorage.getItem("product");
  if (product !== null) {
    callback(null, JSON.parse(product));
  } else {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url + "/biomedapi/products", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onload = function () {
      if (xhr.status === 200) {
        var product = JSON.parse(xhr.responseText);
        sessionStorage.setItem("product", JSON.stringify(product));
        callback(null, product);
      } else {
        callback(new Error(xhr.responseText), null);
      }
    };
    xhr.onerror = function () {
      callback(new Error("Request failed"), null);
    };
    xhr.send();
  }
}

function getProductById(id, callback) {
  var product = sessionStorage.getItem("product:" + id);
  if (product !== null) {
    callback(null, JSON.parse(product));
  } else {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url + "/biomedapi/products/" + id, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onload = function () {
      if (xhr.readyState === xhr.DONE) {
        if (xhr.status === 200) {
          sessionStorage.setItem("product:" + id, xhr.responseText);
          callback(null, JSON.parse(xhr.responseText));
        } else {
          callback("Error: " + xhr.status);
        }
      }
    };
    xhr.onerror = function () {
      callback("Request failed");
    };
    xhr.send();
  }
}

function getSaleAreas(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("saleArea");
  }
  var saleArea = sessionStorage.getItem("saleArea");
  if (saleArea !== null) {
    callback(null, JSON.parse(saleArea));
  } else {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url + "/biomedapi/saleareas", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onload = function () {
      if (xhr.status === 200) {
        var saleArea = JSON.parse(xhr.responseText);
        sessionStorage.setItem("saleArea", JSON.stringify(saleArea));
        callback(null, saleArea);
      } else {
        callback(new Error(xhr.responseText), null);
      }
    };
    xhr.onerror = function () {
      callback(new Error("Request failed"), null);
    };
    xhr.send();
  }
}
function getSaleAreaById(id) {
  return new Promise((resolve, reject) => {
    var saleArea = sessionStorage.getItem("saleArea:" + id);
    if (saleArea !== null) {
      resolve(JSON.parse(saleArea));
    } else {
      var xhr = new XMLHttpRequest();
      xhr.open("GET", url + "/biomedapi/saleareas/" + id, true);
      xhr.setRequestHeader("Content-Type", "application/json");
      xhr.setRequestHeader("Authorization", "Bearer " + readToken());
      xhr.onload = function () {
        if (xhr.readyState === xhr.DONE) {
          if (xhr.status === 200) {
            sessionStorage.setItem("saleArea:" + id, xhr.responseText);
            resolve(JSON.parse(xhr.responseText));
          } else {
            reject("Error: " + xhr.status);
          }
        }
      };
      xhr.onerror = function () {
        reject("Request failed");
      };
      xhr.send();
    }
  });
}

function getProjects(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("projects");
  }
  var projects = sessionStorage.getItem("projects");
  if (projects !== null) {
    callback(null, JSON.parse(projects));
  } else {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url + "/biomedapi/projects", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onload = function () {
      if (xhr.status === 200) {
        var projects = JSON.parse(xhr.responseText);
        sessionStorage.setItem("projects", JSON.stringify(projects));
        callback(null, projects);
      } else {
        callback(new Error(xhr.responseText), null);
      }
    };
    xhr.onerror = function () {
      callback(new Error("Request failed"), null);
    };
    xhr.send();
  }
}

function getProjectById(id, callback) {
  var project = sessionStorage.getItem("project:" + id);
  if (project !== null) {
    callback(null, JSON.parse(project));
  } else {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url + "/biomedapi/projects/" + id, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onload = function () {
      if (xhr.readyState === xhr.DONE) {
        if (xhr.status === 200) {
          sessionStorage.setItem("project:" + id, xhr.responseText);
          callback(null, JSON.parse(xhr.responseText));
        } else {
          callback("Error: " + xhr.status);
        }
      }
    };
    xhr.onerror = function () {
      callback("Request failed");
    };
    xhr.send();
  }
}

function headerSetup(){
  const header = document.querySelector("header");
  if (!header) {
    console.error("Header element not found.");
    return;
  }
  //console.log("Setting up header");
  //console.log(header);
  header.innerHTML = `
    <div class="px-1 py-0 biomed-bg-dark border-bottom">
  <div class="containerfluid">
    <div class="d-flex align-items-center justify-content-evenly flex-wrap flex-xxl-nowrap">
      <!-- Logo on the left -->
      <a href="/" class="p-0 m-0 text-decoration-none">
        <img src="https://www.biomedthai.com/images/logo.png" style="max-height:80px;" alt="biomed diagnostic">
      </a>
      <!-- Navigation on the right (or center, adjust as needed) -->
      <ul class="nav my-0 text-small">
        <li>
          <a href="index.html" class="nav-link biomed-hover rounded">
            <i class="fi fi-rr-user"></i>
            User
          </a>
        </li>
        <li>
          <a href="crm.html" class="nav-link biomed-hover rounded">
            <i class="fi fi-rr-crm-computer"></i>
            CRM
          </a>
        </li>
        <li>
          <a href="event.html" class="nav-link biomed-hover rounded">
            <i class="fi fi-rr-calendar-day"></i>
            Event
          </a>
        </li>
        <li>
          <a href="project.html" class="nav-link biomed-hover rounded">
            <i class="fi fi-rr-diagram-project"></i>
            Project
          </a>
        </li>
        <li>
          <a href="contact.html" class="nav-link biomed-hover rounded">
            <i class="fi fi-rr-review"></i>
            Contact
          </a>
        </li>
        <li>
          <a href="helpdesk.html" class="nav-link biomed-hover rounded">
            <i class="fi fi-rr-wrench-alt"></i>
            Helpdesk
          </a>
        </li>
        <li>
          <a href="#" class="nav-link biomed-disabled-nav disabled rounded">
            <i class="fi fi-rr-file-invoice"></i>
            Invoice & Order
          </a>
        </li>
        <li>
          <a href="inventory.html" class="nav-link biomed-hover rounded">
            <i class="fi fi-rr-box-alt"></i>
            Inventory
          </a>
        </li>
        <li>
          <a href="#" class="nav-link biomed-disabled-nav disabled rounded">
            <i class="fi fi-rr-shipping-fast"></i>
            Delivery
          </a>
        </li>
        <li>
          <a href="visualization.html" class="nav-link biomed-hover rounded">
            <i class="fi fi-rr-analyse-alt"></i>
            Data Visualization
          </a>
        </li>
        <li>
          <a href="d3.html" class="nav-link biomed-hover rounded">
            <i class="fi fi-rr-network-analytic"></i>
            D3 Network
          </a>
        </li>
        <li>
          <a href="management.html" class="nav-link biomed-hover rounded">
            <i class="fi fi-rr-user-gear"></i>
            Management
          </a>
        </li>
      </ul>
    </div>
  </div>
</div>

  `;
}
headerSetup(); //Run Header Setup


function clearsession(){
  clearCache();
  setTimeout(() => { location.reload(); }, 500);
}


function getTargets(callback,query = null){
  var xhr = new XMLHttpRequest();
  xhr.open("POST", url + "/biomedapi/targets", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        var targets = JSON.parse(xhr.responseText);
        callback(null, targets);
      } else {
        var error = new Error(xhr.responseText);
        error.message = error.message + "\nRequest:"+JSON.stringify(query);
        callback(error, null);
      }
    }
  };
  if(query !== null){
    xhr.send(JSON.stringify(query));
  }
  else{
    xhr.send();
  }

}
function formatDateTime(date) {
  const options = { day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' };
  const formattedDate = new Date(date).toLocaleDateString(undefined, options);
  return formattedDate;
}
function formatDateOnly(date) {
  const options = { day: '2-digit', month: 'long', year: 'numeric' };
  const formattedDate = new Date(date).toLocaleDateString(undefined, options);
  return formattedDate;
}
function formatTimeOnly(date) {
  const options = { hour: '2-digit', minute: '2-digit' };
  const formattedTime = new Date(date).toLocaleTimeString(undefined, options);
  return formattedTime;
}
function getRemainingDays(endDate, startDate = null, formatting = true) {
  const today = startDate === null? new Date(): new Date(startDate);
  const targetDate = new Date(endDate);
  const timeDiff = targetDate.getTime() - today.getTime();
  const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
  return formatting? daysDiff >= 0 ? (daysDiff <= 30 ? '⚠️' : '') + daysDiff + " Days remaining" : 'Overdue ' + Math.abs(daysDiff) + ' Days': daysDiff;
}

function getQuarterAndYearByDate(date) {
  const month = date.getMonth();
  const year = month <=3 ? date.getFullYear(): date.getFullYear()+1;
  let quarter;
  if(month == 4||month == 5||month == 6){
    quarter = "Q1";
  }
  if(month == 7||month == 8||month == 9){
    quarter = "Q2";
  }
  if(month == 10||month == 11||month == 0){
    quarter = "Q3";
  } 
  if(month == 1||month == 2||month == 3){
    quarter = "Q4";
  }

  let output = {
    input: date,
    quarter: quarter,
    month: month,
    year: year
  }

  console.log('Date to Quarter',output);
  return output;
}

function AutoComma(number) {
  return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}


//section of helpdesk
function GetHelpdeskPipeline(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("helpdeskPipeline");
  }
  var helpdeskPipeline = sessionStorage.getItem("helpdeskPipeline");
  if (helpdeskPipeline !== null) {
    callback(null, JSON.parse(helpdeskPipeline));
  } else {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url + "/biomedapi/v2/helpdesk/pipeline", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onload = function () {
      if (xhr.status === 200) {
        var helpdeskPipeline = JSON.parse(xhr.responseText);
        helpdeskPipeline.sort((a, b) => a.Order - b.Order);
        sessionStorage.setItem("helpdeskPipeline", JSON.stringify(helpdeskPipeline));
        callback(null, helpdeskPipeline);
      } else {
        callback(new Error(xhr.responseText), null);
      }
    };
    xhr.onerror = function () {
      callback(new Error("Request failed"), null);
    };
    xhr.send();
  }
}

function getTickets(callback, query = null) {
  const token = readToken();
  const xhr = new XMLHttpRequest();

  if (query === null) {
    xhr.open("GET", url + "/biomedapi/v2/helpdesk/tickets", true);
  } else {
    xhr.open("POST", url + "/biomedapi/v2/helpdesk/tickets", true);
  }

  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", `Bearer ${token}`);
  xhr.onreadystatechange = function () {
    if (xhr.readyState === XMLHttpRequest.DONE) {
      if (xhr.status === 200) {
        const tickets = JSON.parse(xhr.responseText);
        callback(null, tickets);
      } else {
        callback(new Error(xhr.responseText), null);
      }
    }
  };

  if (query !== null) {
    xhr.send(JSON.stringify(query));
  } else {
    xhr.send();
  }
}

function priorityFormatting(value) {
  var priority = 0;
  var intvalue = parseInt(value);
  switch (intvalue) {
    case -1:
      priority = "Any Priority📄";
          break;
    case 0:
      priority = "No Priority💤";
      break;
    case 1:
      priority = "Low🧊";
      break;
    case 2:
      priority = "Medium⚒️";
      break;
    case 3:
      priority = "High⚡";
      break;
    case 4:
      priority = "Urgent🔥";
      break;
    case 5:
      priority = "Critical❤️‍🔥";
      break;
    default:
      priority = "Unknown❓";
      break;
  }
  return priority;
}

function uploadFile(callback) {
  const input = document.createElement('input');
  input.type = 'file';
  input.onchange = function(event) {
    const file = event.target.files[0];
    if (!file) {
      callback(new Error("No file selected"), null);
      return;
    }

    const formData = new FormData();
    formData.append('file', file);
    

    const xhr = new XMLHttpRequest();
    xhr.open('POST', url + '/biomedapi/misc/uploadfile', true);
    xhr.setRequestHeader('Authorization', 'Bearer ' + readToken());
    xhr.onreadystatechange = function() {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          //console.log(xhr.responseText);
          callback(null, xhr.responseText);
        } else {
          console.error(xhr.status,xhr.responseText);
          callback(new Error(xhr.responseText), null);
        }
      }
    };
    
    xhr.send(formData);
  };
  input.click();
}
/*
var initialValues = {};
function cachingObject(){

  initialValues = {}; // Reset previous values

  document.querySelectorAll('input, select, textarea').forEach(element => {
      const key = element.name || element.id;

      if (element.tagName === 'SELECT' && element.multiple) {
          // Store an array of selected values for multiple selects
          initialValues[key] = Array.from(element.selectedOptions).map(option => option.value);
      } else {
          initialValues[key] = element.value;
      }
  });

}

function compareChange() {
  let changes = [];

    document.querySelectorAll('input, select, textarea').forEach(element => {
        const key = element.name || element.id;
        let newValue;

        if (element.tagName === 'SELECT' && element.multiple) {
            newValue = Array.from(element.selectedOptions).map(option => option.value);
        } else {
            newValue = element.value;
        }

        // Check for changes (array comparison for multi-select)
        if (JSON.stringify(initialValues[key]) !== JSON.stringify(newValue)) {
            changes.push({
                field: key,
                oldValue: initialValues[key],
                newValue: newValue
            });
        }
    });

    //console.log('Changes:', changes);
    return changes; // Returns an array of changed fields

  
}*/
//Campare Change Version 2
var initialValues = {};

function cachingObject() {
    initialValues = {}; // Reset previous values


    const selects = document.querySelectorAll('.multi-select');
    
    
    selects.forEach(el => {
        initialValues[el.id] = Array.from(el.querySelectorAll('input'))
          .map(input => input.value)
          .filter(value => value.trim() !== ""); // Store non-empty selected values for multi-selects
        initialValues[el.id].Multiple = true; // Mark as multiple select
    });


    document.querySelectorAll('input, select, textarea').forEach(element => {
        const key = element.name || element.id;
        let value;

        if (element.tagName === 'SELECT' && element.multiple) {
            // Store selected values for multiple selects
            value = Array.from(element.selectedOptions).map(option => option.value);
        } else if (element.type === "checkbox") {
            value = element.checked; // Store boolean for checkboxes
        } else if (element.type === "radio") {
            if (element.checked) {
                value = element.id; // Store radio ID if checked
            } else {
                return; // Skip unchecked radios
            }
        } else {
            value = element.value.trim(); // Trim spaces
        }

        // Store only non-empty values
        if (value !== "" && value !== null && value !== undefined) {
            initialValues[key] = value;
        }
    });

    //console.log("Cached Values:", initialValues);
}

async function compareChange() {
    let changes = [];

    Object.keys(initialValues).forEach(key => {
      if (initialValues[key].Multiple) {
      const currentValues = Array.from(document.querySelectorAll(`#${key} input`))
        .map(input => input.value)
        .filter(value => value.trim() !== ""); // Skip empty values
      if (JSON.stringify(initialValues[key]) !== JSON.stringify(currentValues)) {
        const oldValue = [...initialValues[key]]; // Create a shallow copy of the original object
        delete oldValue.Multiple; // Remove the Multiple property from the copy
        changes.push({
        field: key,
        oldValue: oldValue,
        newValue: currentValues
        });
      }
      }
    });

    document.querySelectorAll('input, select, textarea').forEach(element => {
        const key = element.name || element.id;
        let newValue;
        
        if (element.tagName === 'SELECT' && (element.multiple || element.multiple === "multiple")) {
            newValue = Array.from(element.selectedOptions).map(option => option.value);
        } else if (element.type === "checkbox") {
        
            newValue = element.checked; // Store boolean for checkboxes
        } else if (element.type === "radio") {
            if (element.checked) {
                newValue = element.id; // Get radio ID if checked
            } else {
                return; // Skip unchecked radios
            }
        } else if (element.type === "hidden") {
          return; // Skip hidden inputs
        }
        else {
            newValue = element.value.trim();
        }

        if (newValue !== "" && newValue !== null && newValue !== undefined) {
            const oldValue = initialValues[key];

            if (element.type === "radio" && oldValue !== newValue) {
                // For radio buttons, mark old one as false and new one as true
                changes.push({ field: oldValue, newValue: false, oldValue: true });
                changes.push({ field: newValue, newValue: true, oldValue: false });
            } else if (JSON.stringify(oldValue) !== JSON.stringify(newValue)) {
                changes.push({
                    field: key,
                    oldValue: typeof(oldValue)==='boolean'? oldValue: oldValue || "N/A",
                    newValue: newValue
                });
            }
        }
    });


    //console.log('Changes:', changes);
    let newChanges = await changeParse(changes);
    return newChanges;
}

async function changeParse(changes) {
  let newChanges = [];
  for (const change of changes) {
    let readableChange = {};
    readableChange.field = change.field;
    readableChange.oldValue = change.oldValue;
    readableChange.newValue = change.newValue;
    if (change.field === "contactsSelecter"||change.field === "contactsDropdown") {
      readableChange.oldValue = [];
      for (const element of change.oldValue) {
        await new Promise((resolve, reject) => {
          getContactById(element, (error, contact) => {
            if (error) {
              console.error('Failed to fetch contact:', error);
              reject(error);
              return;
            }
            readableChange.oldValue.push(contact.Name + "(" + element + ")");
            resolve();
          });
        });
      }

      readableChange.newValue = [];
      for (const element of change.newValue) {
        await new Promise((resolve, reject) => {
          getContactById(element, (error, contact) => {
            if (error) {
              console.error('Failed to fetch contact:', error);
              reject(error);
              return;
            }
            readableChange.newValue.push(contact.Name + "(" + element + ")");
            resolve();
          });
        });
      }
    }
    if (change.field === "productsDropdown") {
      readableChange.oldValue = [];
      for (const element of change.oldValue) {
        await new Promise((resolve, reject) => {
          getProductById(element, (error, contact) => {
            if (error) {
              console.error('Failed to fetch contact:', error);
              reject(error);
              return;
            }
            readableChange.oldValue.push(contact.Name + "(" + element + ")");
            resolve();
          });
        });
      }

      readableChange.newValue = [];
      for (const element of change.newValue) {
        await new Promise((resolve, reject) => {
          getProductById(element, (error, contact) => {
            if (error) {
              console.error('Failed to fetch contact:', error);
              reject(error);
              return;
            }
            readableChange.newValue.push(contact.Name + "(" + element + ")");
            resolve();
          });
        });
      }
    }
    if (change.field === "usersSelecter" ||change.field === "usersDropdown") {
      readableChange.oldValue = [];
      for (const element of change.oldValue) {
        await new Promise((resolve, reject) => {
          getUserById( (error, user) => {
            if (error) {
              console.error('Failed to fetch contact:', error);
              reject(error);
              return;
            }
            readableChange.oldValue.push(user.FirstName +" "+user.LastName + "(" + element + ")");
            resolve();
          },element);
        });
      }

      readableChange.newValue = [];
      for (const element of change.newValue) {
        await new Promise((resolve, reject) => {
          getUserById( (error, user) => {
            if (error) {
              console.error('Failed to fetch contact:', error);
              reject(error);
              return;
            }
            readableChange.newValue.push(user.FirstName +" "+user.LastName + "(" + element + ")");
            resolve();
          },element);
        });
      }
    }
    if (change.field === "saleArea"){
      readableChange.oldValue = change.oldValue !== "N/A"&&change.oldValue !=="-1"? (await new Promise((resolve, reject) => {
        getSaleAreaById(change.oldValue).then(resolve).catch(reject);
      })).Name+"("+change.oldValue+")":"N/A";

      readableChange.newValue = change.newValue!=="N/A"&&change.newValue !=="-1"?(await new Promise((resolve, reject) => {
        getSaleAreaById(change.newValue).then(resolve).catch(reject);
      })).Name+"("+change.newValue+")":"N/A";
    }
    if (change.field === "product" || change.field === "modalProduct") {
      readableChange.oldValue = change.oldValue !== "N/A"&&change.oldValue !=="-1"? (await new Promise((resolve, reject) => {
        getProductById(change.oldValue, (error, product) => {
          if (error) {
            console.error('Failed to fetch product:', error);
            reject(error);
            return;
          }
          resolve(product);
        });
      })).Name+"("+change.oldValue+")":"N/A";
      readableChange.newValue = change.newValue!=="N/A"&&change.newValue !=="-1"? (await new Promise((resolve, reject) => {
        getProductById(change.newValue, (error, product) => {
          if (error) {
            console.error('Failed to fetch product:', error);
            reject(error);
            return;
          }
          resolve(product);
        });
      })).Name+"("+change.newValue+")":"N/A";
    }
    if (change.field.startsWith("pipeline")) {
      const label = document.querySelector(`label[for="${change.field}"]`);
      if (label) {
        readableChange.field = label.textContent.trim() + " (" + change.field.replace("pipeline", "").trim()+")";
      }
    }

    newChanges.push(readableChange);
  }
  return newChanges;
}



const charset = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // No confusing chars like O/0/I/1

function intToFourDigitString(num) {
    let base = charset.length;
    let str = "";
    
    for (let i = 0; i < 4; i++) {
        str = charset[num % base] + str;
        num = Math.floor(num / base);
    }

    return str;
}

function fourDigitStringToInt(str) {
    let base = charset.length;
    let num = 0;
    
    for (let i = 0; i < str.length; i++) {
        num = num * base + charset.indexOf(str[i]);
    }

    return num;
}

// Example usage:
//let encoded = intToFourDigitString(12345);
////console.log(encoded); // Example: "7BFD"

//let decoded = fourDigitStringToInt(encoded);
////console.log(decoded); // 12345

async function processTargets(targets) {
  if (!targets || targets.length === 0) {
      return targets;
  }
  const sortedTargets = targets.sort((a, b) => new Date(b.EndDate).getTime() - new Date(a.EndDate).getTime());
  sortedTargets.forEach((target, index) => {
      target.order = index + 1;
  });
  //console.log("Sorted Targets",sortedTargets);

  //query and target processing
  const totalQuery = {};
  for (const target of sortedTargets) {
      if (!totalQuery.SaleAreaIDs) {
          totalQuery.SaleAreaIDs = [];
      }
      if (!totalQuery.ProductIDs) {
          totalQuery.ProductIDs = [];
      }
      if (!totalQuery.SaleAreaIDs.includes(target.SaleAreaID)) {
          totalQuery.SaleAreaIDs.push(target.SaleAreaID);
      }
      if (!totalQuery.ProductIDs.includes(target.ProductID)) {
          totalQuery.ProductIDs.push(target.ProductID);
      }
      const product = await promiseProductById(target.ProductID);
      const saleArea = await promiseSaleAreaById(target.SaleAreaID);
      target.Product = product;
      target.SaleArea = saleArea;
      target.Leads = [];
      target.Color = await getColor(target.ProductID);
  }
  const minStartDate = sortedTargets.reduce((min, target) => new Date(target.StartDate) < min ? new Date(target.StartDate) : min, new Date(sortedTargets[0].StartDate));
  const maxEndDate = sortedTargets.reduce((max, target) => new Date(target.EndDate) > max ? new Date(target.EndDate) : max, new Date(sortedTargets[0].EndDate));

  //console.log("Min Start Date:", minStartDate);
  //console.log("Max End Date:", maxEndDate);
  totalQuery.ExpectedStart = timeFormater(minStartDate);
  totalQuery.ExpectedEnd = timeFormater(maxEndDate);
  totalQuery.DeepSearch = true;
  //console.log("Total Query",totalQuery);
  const totalLeads = await promiseLeads(totalQuery);
  //console.log("Total Leads",totalLeads);

  for (const lead of totalLeads) {
      const target = sortedTargets.find(target => 
          target.ProductID === lead.ProductId && 
          target.SaleAreaID === lead.SaleAreaId &&
          new Date(lead.Expected) >= new Date(target.StartDate) &&
          new Date(lead.Expected) <= new Date(target.EndDate)
      );
      if (target) {
          if (!target.Leads) {
              target.Leads = [];
          }
          target.Leads.push(lead);
      }
  }
  return sortedTargets;
}

//it's time to promise!
async function promiseMyUser(){
  return new Promise((resolve, reject) => {
    myUserRequest((error, user) => {
          if (error) {
              console.error('Failed to fetch user:', error);
              reject(error);
              return;
          }
          resolve(user);
      });
  });
}

async function promiseLeads(query = null){
  return new Promise((resolve, reject) => {
      getLeads((error, leads) => {
          if (error) {
              console.error('Failed to fetch leads:', error);
              reject(error);
              return;
          }
          resolve(leads);
      },query);
  });
}
async function promiseUsers(force = false) {
  return new Promise((resolve, reject) => {
    getUsers((error, users) => {
      if (error) {
        console.error('Failed to fetch users:', error);
        reject(error);
        return;
      }
      resolve(users);
    }, force);
  });
}

async function promiseUserById(id) {
  return new Promise((resolve, reject) => {
      getUserById((error, user) => {
          if (error) {
              console.error('Failed to fetch contact:', error);
              reject(error);
              return;
          }
          //readableChange.oldValue.push(user.FirstName + " " + user.LastName + "(" + id + ")");
          resolve(user);
      }, id);
  });
}
async function promiseSaleAreaById(id) {
  return new Promise((resolve, reject) => {
      getSaleAreaById(id).then(resolve).catch(reject);
  });
}

async function promiseProductById(id) {
  return new Promise((resolve, reject) => {
      getProductById(id,(error, product) => {
          if (error) {
              console.error('Failed to fetch product:', error);
              reject(error);
              return;
          }
          resolve(product);
      });
  });
}
async function promiseProducts(force = false) {
  return new Promise((resolve, reject) => {
    getProducts((error, products) => {
      if (error) {
        console.error('Failed to fetch products:', error);
        reject(error);
        return;
      }
      resolve(products);
    }, force);
  });
}

async function promiseContacts(force = false) {
  return new Promise((resolve, reject) => {
    getContacts((error, contacts) => {
      if (error) {
        console.error('Failed to fetch contacts:', error);
        reject(error);
        return;
      }
      resolve(contacts);
    }, force);
  });
}
async function promiseContactById(id) {
  return new Promise((resolve, reject) => {
      getContactById(id,(error, contact) => {
          if (error) {
              console.error('Failed to fetch contact:', error);
              reject(error);
              return;
          }
          resolve(contact);
      });
  });
}
let pipelinesCache = [];
async function promiseCRMPipelines(){ 
  return new Promise((resolve, reject) => {
      if(pipelinesCache.length > 0){
          resolve(pipelinesCache);
          return;
      }
  getPipelines((error, pipelines) => {
      if (error) {
          console.error('Failed to fetch pipelines:', error);
          reject(error);
          return;
      }
      //console.log("CRM Pipelines",pipelines);
      pipelinesCache = pipelines;
      resolve(pipelines);
  });
});
}

async function promiseCRMPipelineById(id) {
  try {
      let pipelines = await promiseCRMPipelines();
      const pipeline = pipelines.find(p => p.Id === id);
      if (!pipeline) {
          //throw new Error('Pipeline not found');
          return {Id:id,PipelineName:"Unknown"};
      }
      return pipeline;
  } catch (error) {
      console.error(error);
      throw error;
  }
}

async function promiseTargets(query = null){
  return new Promise((resolve, reject) => {
      getTargets((error, targets) => {
          if (error) {
              console.error('Failed to fetch targets:', error);
              reject(error);
              return;
          }
          resolve(targets);
      },query);
  });
}

async function promiseEvents(query = null) {
  return new Promise((resolve, reject) => {
    getEvents((error, events) => {
      if (error) {
        console.error('Failed to fetch events:', error);
        reject(error);
        return;
      }
      resolve(events);
    }, query);
  });
}

async function promiseEventById(id) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", `${url}/biomedapi/v2/event/${id}`, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onreadystatechange = function () {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          const event = JSON.parse(xhr.responseText);
          resolve(event);
        } else {
          reject(new Error(xhr.responseText));
        }
      }
    };
    xhr.onerror = function () {
      reject(new Error("Request failed"));
    };
    xhr.send();
  });
}

async function promiseColorById(id) {
  return new Promise(async (resolve, reject) => {
    try {
      const color = await getColor(id);
      resolve(color);
    } catch (error) {
      console.error('Failed to fetch color:', error);
      reject(error);
    }
  });
}

async function v2_promiseEvents(filter = {DeepSearch:true}) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", url + "/biomedapi/v2/event", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onreadystatechange = function () {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          const events = JSON.parse(xhr.responseText);
          resolve(events);
        } else {
          reject(new Error(xhr.responseText));
        }
      }
    };
    xhr.onerror = function () {
      reject(new Error("Request failed"));
    };
    xhr.send(filter ? JSON.stringify(filter) : filter);
  });
}

function Label(color, text,objectMode = false) {

  const element = document.createElement("div");
  element.className = "m-1 p-1 rounded-5 c-shadow text-truncate";
  element.style.backgroundColor = "white";

  const colorSpan = document.createElement("span");
  colorSpan.className = "m-0 p-0 c-text-shadow";
  colorSpan.style.color = color;
  colorSpan.textContent = "⬤ ";

  const textSpan = document.createElement("span");
  textSpan.className = "m-0 p-0";
  textSpan.style.fontSize = "smaller";
  textSpan.textContent = text;

  element.appendChild(colorSpan);
  element.appendChild(textSpan);


  return (!objectMode)?`<div class="m-1 p-1 rounded-5 c-shadow text-truncate" style="background-color:white">
  <span class="m-0 p-0 c-text-shadow" style="color:${color}">⬤ </span>
  <span class="m-0 p-0" style="font-size:smaller;">${text}</span>
</div>`:element;
}

function showLoader() {
  // Check if loader already exists
  if (document.getElementById('loader')) {
    return; // Loader already exists, no need to create a new one
  }
  const loaderHTML = `
    <div class="position-fixed top-0 start-0 w-100 h-100" style="z-index: 99999; background-color: rgba(0, 0, 0, 0.5);" id="loader">
      <div class="d-flex justify-content-center align-items-center h-100">
        <div class="bg-white p-4 rounded-5">
          <div aria-label="Orange and tan hamster running in a metal wheel" role="img" class="wheel-and-hamster mx-auto">
            <div class="wheel"></div>
            <div class="hamster">
              <div class="hamster__body">
                <div class="hamster__head">
                  <div class="hamster__ear"></div>
                  <div class="hamster__eye"></div>
                  <div class="hamster__nose"></div>
                </div>
                <div class="hamster__limb hamster__limb--fr"></div>
                <div class="hamster__limb hamster__limb--fl"></div>
                <div class="hamster__limb hamster__limb--br"></div>
                <div class="hamster__limb hamster__limb--bl"></div>
                <div class="hamster__tail"></div>
              </div>
            </div>
            <div class="spoke"></div>
          </div>
          <p class="text-center mt-3" id="loadingText">Loading<span id="dots">.</span></p>
          
        </div>
      </div>
    </div>
  `;

  document.body.insertAdjacentHTML('beforeend', loaderHTML);
  const dotsElement = document.getElementById('dots');
  let dotCount = 1;
  dotsElement.LoadSpin =  setInterval(() => {
    dotCount = (dotCount % 3) + 1; // Cycle through 1 to 3
    dotsElement.textContent = '.'.repeat(dotCount);
  }, 500); // Update every 500ms

  // After 15 seconds, show error label, logout button, and errors box
  setTimeout(() => {
    const loader = document.getElementById('loader');
    if (!loader) return;
    const loaderContent = loader.querySelector('.bg-white');
    if (!loaderContent || loaderContent.querySelector('#loaderError')) return;
    const errorHTML = `
      <div id="loaderError" class="text-center mt-3">
        <p class="mb-2">Something went wrong?</p>
        <button class="btn c-con-primary" onclick="removeToken()">Logout</button>
        <button class="btn btn-secondary ms-2" onclick="alert('Please press F12 or Ctrl+Shift+I to open Developer Tools')">Developer Mode</button>
        <div class="mt-2 d-none">
          <textarea id="loaderErrors" class="form-control" rows="5" readonly></textarea>
        </div>
      </div>
    `;
    loaderContent.insertAdjacentHTML('beforeend', errorHTML);
    // populate console errors into textarea
    const errorList = window._loaderConsoleErrors || [];
    if (errorList.length > 0) {
      document.getElementById('loaderErrors').value = errorList.join('\n');
    }
  }, 15000);
}


function hideLoader() {
  // Check if loader exists
  if (!document.getElementById('loader')) {
    return; // Loader doesn't exist, no need to remove it
  }
  const loader = document.getElementById('loader');
  if (loader) {
    loader.remove();
  }
  const dotsElement = document.getElementById('dots');
  if (dotsElement && dotsElement.LoadSpin) {
    clearTimeout(dotsElement.LoadSpin);
    dotsElement.LoadSpin = null;
  }
}
;

(function() {
  // Capture console errors for loader error display
  window._loaderConsoleErrors = [];
  const origConsoleError = console.error;
  console.error = function(...args) {
    // capture error message and stack location
    const msg = args.map(arg => {
      try { return JSON.stringify(arg); } catch { return String(arg); }
    }).join(' ');
    const stackLine = (new Error()).stack.split("\n")[2] || '';
    window._loaderConsoleErrors.push(`${msg} at ${stackLine.trim()}`);
    origConsoleError.apply(console, args);
  };
  window.onerror = function(message, source, lineno, colno, error) {
    window._loaderConsoleErrors.push(`${message} at ${source}:${lineno}:${colno}`);
  };
  // Capture unhandled Promise rejections
  window.addEventListener('unhandledrejection', function(event) {
    const reason = event.reason instanceof Error ? event.reason.stack : String(event.reason);
    window._loaderConsoleErrors.push(`UnhandledRejection: ${reason}`);
  });
})();