var masterEventList = [];
var todayEvents = document.getElementById("todayEvents");
var upcomingEvents = document.getElementById("upcomingEvents");
var reportEvents = document.getElementById("reportEvents");
var doneEvents = document.getElementById("doneEvents");
var scheduledEvents = document.getElementById("scheduledEvents");

function clearEvents() {
    todayEvents.innerHTML = "";
    upcomingEvents.innerHTML = "";
    reportEvents.innerHTML = "";
    doneEvents.innerHTML = "";
    scheduledEvents.innerHTML = "";
}

function filterchange() {
    clearEvents();
    var masterEventListDup = [...masterEventList];
    var usersList = document.getElementById("usersList");
    var userIds = Array.from(
      usersList.querySelectorAll('input[type="checkbox"]:checked')
    ).map((checkbox) => checkbox.getAttribute("userId"));
    masterEventListDup = masterEventListDup.filter((event) => userIds.includes(event.MainUserID.toString()));

    EventsDisplay(masterEventListDup);

}
function selectAll(selection) {
    if (selection === true) {
      var checkboxes = document
        .getElementById("usersList")
        .querySelectorAll('input[type="checkbox"]');
      checkboxes.forEach(function (checkbox) {
        checkbox.checked = true;
      });
    } else if (selection===false){
      var checkboxes = document
        .getElementById("usersList")
        .querySelectorAll('input[type="checkbox"]');
      checkboxes.forEach(function (checkbox) {
        checkbox.checked = false;
        document.getElementById("flexCheckChecked"+userCache.Id).checked = true;   
      });
    }
    else {
        var checkboxes = document
        .getElementById("usersList")
        .querySelectorAll('input[type="checkbox"]');
      checkboxes.forEach(function (checkbox) {
        checkbox.checked = false;
      });
    }
    filterchange();
  }

var userCache;
window.onload = function() {
    myUserRequest(function(err, response) {
        console.log(response);
        if (err === null) {
            userCache = response;
            document.getElementById("displayName").innerText = response.FirstName + " " + response.LastName;
            document.getElementById("fullname").innerText = response.FirstName + " " + response.LastName;
            document.getElementById("position").innerText = response.Position;
            document.getElementById("telnumber").innerText = response.PhoneNumber;
            document.getElementById("email").innerText = response.Email;
            document.getElementById("floatingFirstName").value = response.FirstName;
            document.getElementById("floatingLastName").value = response.LastName;
            document.getElementById("floatingMiddleName").value = response.MiddleName;
            document.getElementById("floatingPosition").value = response.Position;
            document.getElementById("floatingEmail").value = response.Email;
            document.getElementById("floatingPhoneNumber").value = response.PhoneNumber;
            document.getElementById("floatingSubEmail").value = response.SubEmail;
            document.getElementById("floatingSubPhoneNumber").value = response.SubPhoneNumber;
            document.getElementById("floatingAddress").value = response.Address;
            document.getElementById("floatingLineID").value = response.LineID;
            if(response.ProfilePic == "00000000-0000-0000-0000-000000000000"){
                document.getElementById("profilepicImg").src = 'assets/profile-user.png';
            }else{
                
                document.getElementById("profilepicImg").src = "assets/profile/"+response.ProfilePic+".jpg";
            }
        } else if (err === "Token not found") {
           xalert("Token not found", 2, null);
        } else {
           xalert(xhr.status + "-" + xhr.responseText, 1, null);
        }
    }); 
    const startDate = new Date();
    startDate.setMonth(startDate.getMonth() - 1);
    const endDate = new Date();
    endDate.setMonth(endDate.getMonth() + 1);

    queryObject = {
        StartDate: startDate.toISOString(),
        EndDate: endDate.toISOString()
    }
    getEvents(function(error, events) {
        if (error) {
          console.error('Error fetching events:', error);
          xalert("Error fetching events", 1, null);
        } else {
            
            // Check for duplicate events
            var uniqueEvents = [];
            events.forEach(function(event) {
                var isDuplicate = uniqueEvents.some(function(uniqueEvent) {
                    return uniqueEvent.Id === event.Id;
                });
                if (!isDuplicate) {
                    uniqueEvents.push(event);
                }
            });

            //Add User to Control Panel
            var thisUser;

            myUserRequest(async function (err, user) {
            if (err) {
                console.error("Failed to fetch user:", err);
                xalert("Failed to fetch user:" + err, 1, null);
                return;
            }
            thisUser = user;
            var checkbox = document.createElement("div");
            checkbox.classList.add("form-check");
            
            var color = await getColor(user.Id);

            checkbox.innerHTML = `
                        <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked${user.Id}" checked userId="${user.Id}" onchange="filterchange()">
                        <label class="form-check-label" for="flexCheckChecked">
                            <span class="biomed-badge rounded flex-grow" style="background-color: ${color.color.code}; color: ${color.textColor};"><i class="fi fi-rr-circle-user"></i>${user.FirstName} ${user.LastName} (${user.Position})</span>
                        </label>
                    `;
            document.getElementById("usersList").appendChild(checkbox);


            },false);

            var myPermissions;
            myPermission(async function (err, permissions) {
            if (err) {
                console.error("Failed to fetch permissions:", err);
                xalert("Failed to fetch permissions:" + err, 1, null);
                return;
            }
            myPermissions = permissions;

            var individualPermissionsUserIds = [];

            myPermissions.IndividualPermissions.forEach(function (permission) {
            if (permission.Type == "event_manage_individual"){
                getUserById(async function (error, user) {
                if (error) {
                    console.error("Failed to fetch user:", error);
                    xalert("Failed to fetch user:" + error, 1, null);
                    return;
                }
                if (thisUser.Id == user.Id){
                    return;
                }
                individualPermissionsUserIds.push(user.Id);
                var checkbox = document.createElement("div");
                checkbox.classList.add("form-check");
        
                var color = await getColor(user.Id);
        
                checkbox.innerHTML = `
                            <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked${user.Id}" userId="${user.Id}" onchange="filterchange()">
                            <label class="form-check-label" for="flexCheckChecked">
                                <span class="biomed-badge rounded flex-grow" style="background-color: ${color.color.code}; color: ${color.textColor};"><i class="fi fi-rr-employees"></i>${user.FirstName} ${user.LastName} (${user.Position})</span>
                            </label>
                        `;
                document.getElementById("usersList").appendChild(checkbox);

                }, parseInt(permission.PermissionKey));
            }
            }
            );


            var allUsers;
            getUsers(function (error, users) {
            if (error) {
                console.error("Failed to fetch users:", error);
                xalert("Failed to fetch users:" + error, 1, null);
                return;
            }
            allUsers = users;


            if(myPermissions.MainPermissions.find(permission => permission.Type == "event_manage")){
                var trimmedUsers = allUsers.filter(user => !individualPermissionsUserIds.includes(user.Id)&&user.Id!=thisUser.Id);
                trimmedUsers.forEach(async function (user) {
                    getUserById(async function (error, user) {
                    if (error) {
                        console.error("Failed to fetch user:", error);
                        xalert("Failed to fetch user:" + error, 1, null);
                        return;
                    }
                    var checkbox = document.createElement("div");
                    checkbox.classList.add("form-check");
    
                    var color = await getColor(user.Id);
    
                    checkbox.innerHTML = `
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked${user.Id}" userId="${user.Id}" onchange="filterchange()">
                                <label class="form-check-label" for="flexCheckChecked">
                                    <span class="biomed-badge rounded flex-grow" style="background-color: ${color.color.code}; color: ${color.textColor};"><i class="fi fi-rr-globe"></i>${user.FirstName} ${user.LastName} (${user.Position})</span>
                                </label>
                            `;
                    document.getElementById("usersList").appendChild(checkbox);
                    }, user.Id);
                });
                }
               /* var uniqueUserIds = [...new Set(events.map((event) => event.MainUserID))];
                uniqueUserIds.forEach(async function (userId) {
                getUserById(async function (error, user) {
                    if (error) {
                    console.error("Failed to fetch user:", error);
                    xalert("Failed to fetch user:" + error, 1, null);
                    return;
                    }
                    var checkbox = document.createElement("div");
                    checkbox.classList.add("form-check");
    
                    var color = await getColor(user.Id);
    
                    checkbox.innerHTML = `
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked${user.Id}" checked userId="${user.Id}" onchange="filterchange()">
                                <label class="form-check-label" for="flexCheckChecked">
                                <span class="badge py-1 m-1 align-middle text-wrap" style="background-color: ${color.color.code}; color: ${color.textColor};">${user.FirstName} ${user.LastName} (${user.Position})</span>
                                </label>
                            `;
                    document.getElementById("usersList").appendChild(checkbox);
                }, userId);
                });
                console.log(uniqueUserIds);*/
    
                // Update events array with unique events
                masterEventList = uniqueEvents;
                EventsDisplay(uniqueEvents);


            });
            });// end of myPermission
            


            

            


            // Rest of the code...

            


        }
      },queryObject);
      
      setTimeout(function() {
        selectAll(false);
    }, 1000);
      

};

function EventsDisplay(events) {
    events.sort(function(a, b) {
        return new Date(a.StartDate) - new Date(b.StartDate);
    });
    events.forEach(function(event) {
        var eventElement = document.createElement("div");
        
        eventElement.classList.add("m-1", "p-2", "border", "rounded", "biomed-bg-white");
        eventElement.setAttribute("userId", event.MainUserID);
        var eventTitle = document.createElement("h6");
        eventTitle.textContent = event.Title + " ";
        var editLink = document.createElement("a");
        
        editLink.classList.add("link", "link-underline", "link-underline-opacity-0", "link-light");
        editLink.href = "event.html?id=" + event.Id;
        var editIcon = document.createElement("i");
        editIcon.classList.add("fi", "fi-rr-edit");
        editLink.appendChild(editIcon);
        var editBadge = document.createElement("span");
        editBadge.classList.add("badge", "rounded-pill", "bg-primary");
        editBadge.appendChild(editLink);
        editLink.innerHTML += " Edit";
        eventTitle.appendChild(editBadge);
        eventElement.appendChild(eventTitle);

        var planP = document.createElement("p");
        var planBadge = document.createElement("span");
        planBadge.classList.add("badge", "rounded-pill", "bg-secondary");
        planBadge.textContent = "Plan";
        var planText = document.createElement("strong");
        planText.appendChild(planBadge);
        planP.appendChild(planText);

        var planValue = document.createElement("span");
        planValue.textContent = " "+event.Plan;
        planP.appendChild(planValue);
        eventElement.appendChild(planP);

        var timeP = document.createElement("p");
        var timeBadge = document.createElement("span");
        timeBadge.classList.add("badge", "rounded-pill", "bg-secondary");
        timeBadge.textContent = "Time";
        var timeText = document.createElement("strong");
        timeText.appendChild(timeBadge);
        timeP.appendChild(timeText);

        var timeValue = document.createElement("span");
        if (event.IsAllDay) {
            timeValue.textContent = " All Day Event";
        } else {
            var startTime = new Date(event.StartDate);
            var endTime = new Date(event.EndDate);
            var timeString = " "+startTime.toLocaleTimeString() + "-" + endTime.toLocaleTimeString();
            timeValue.textContent = timeString;
        }
        
        timeP.appendChild(timeValue);
        eventElement.appendChild(timeP);

        var dateP = document.createElement("p");
        var dateBadge = document.createElement("span");
        dateBadge.classList.add("badge", "rounded-pill", "bg-secondary");
        dateBadge.textContent = "Date";
        var dateText = document.createElement("strong");
        dateText.appendChild(dateBadge);
        dateP.appendChild(dateText);

        var dateValue = document.createElement("span");
        var startDate = new Date(event.StartDate);
        var endDate = new Date(event.EndDate);
        if (startDate.toDateString() === endDate.toDateString()) {
            dateValue.textContent = " "+ startDate.toLocaleDateString();
        } else {
            var dateString = " "+startDate.toLocaleDateString() + "-" + endDate.toLocaleDateString();
            dateValue.textContent = dateString;
        }
        dateP.appendChild(dateValue);
        eventElement.appendChild(dateP);

        /*var planP = document.createElement("p");
        var planBadge = document.createElement("span");
        planBadge.classList.add("badge", "rounded-pill", "bg-secondary");
        planBadge.textContent = "Plan";
        var planText = document.createElement("strong");
        planText.appendChild(planBadge);
        planP.appendChild(planText);

        var planValue = document.createElement("span");
        planValue.textContent = " " + event.Plan;
        planP.appendChild(planValue);
        eventElement.appendChild(planP);*/ //duplicated plan

        var reportP = document.createElement("p");
        var reportBadge = document.createElement("span");
        reportBadge.classList.add("badge", "rounded-pill", "bg-secondary");
        reportBadge.textContent = "Report";
        var reportText = document.createElement("strong");
        reportText.appendChild(reportBadge);
        reportP.appendChild(reportText);

        var reportValue = document.createElement("span");
        reportValue.textContent = " "+event.Report;
        reportP.appendChild(reportValue);
        eventElement.appendChild(reportP);

        var commentP = document.createElement("p");
        var commentBadge = document.createElement("span");
        commentBadge.classList.add("badge", "rounded-pill", "bg-secondary");
        commentBadge.textContent = "Comment";
        var commentText = document.createElement("strong");
        commentText.appendChild(commentBadge);
        commentP.appendChild(commentText);

        var commentValue = document.createElement("span");
        commentValue.textContent = " "+event.Comment;
        commentP.appendChild(commentValue);
        eventElement.appendChild(commentP);

        var mainP = document.createElement("p");
        var mainResponsibleBadge = document.createElement("span");
        mainResponsibleBadge.classList.add("badge", "rounded-pill", "bg-secondary");
        mainResponsibleBadge.textContent = "Main Responsible";
        var mainResponsibleText = document.createElement("strong");
        mainResponsibleText.appendChild(mainResponsibleBadge);
        mainP.appendChild(mainResponsibleText);

        var mainResponsibleValue = document.createElement("span");
        if (event.MainUser !== undefined && event.MainUser !== null) {
               mainResponsibleValue.textContent = " " +event.MainUser.FirstName + " " + event.MainUser.LastName;
           }else{
            getUserById((err,user)=>{
                if(err){
                    console.log(err);
                    xalert("Error while fetching user",1,null);
                }
                mainResponsibleValue.textContent = " " +user.FirstName + " " + user.LastName;
               } ,event.MainUserID);
           }
     
        mainP.appendChild(mainResponsibleValue);
        eventElement.appendChild(mainP);


        if (isToday(new Date(event.StartDate)) || isBetween(new Date(event.StartDate), new Date(event.EndDate))) {
            todayEvents.appendChild(eventElement);
        } else if (isWithin7Days(new Date(event.StartDate))&&!isPast(new Date(event.EndDate))) {
            upcomingEvents.appendChild(eventElement);
        } else if (isPast(new Date(event.EndDate)) && event.Report === "") {
            reportEvents.appendChild(eventElement);
        } else if (!isWithin7Days(new Date(event.StartDate))&&!isPast(new Date(event.EndDate))){
            scheduledEvents.appendChild(eventElement);
        } else {
            doneEvents.appendChild(eventElement);
        }

        function isToday(date) {
            var today = new Date();
            return date.toDateString() === today.toDateString();
        }

        function isBetween(startDate, endDate) {
            var now = new Date();
            return startDate <= now && now <= endDate;
        }

        function isWithin7Days(date) {
            var now = new Date();
            var sevenDaysFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
            return date <= sevenDaysFromNow;
        }

        function isPast(date) {
            var now = new Date();
            return date < now;
        }
    });
    
  console.log('Fetched events:', events);

}
function updateUser() {
    var myuser;
    myUserRequest(function(err, response) {
        if (err) {
           xalert("There is an error while getting the user request", 1, null);
        } else {
            myuser = response;
        }
    });
    var updateUserRequest = {
        Id: myuser.Id,
        Password: null,
        ProfilePic: document.getElementById("floatingProfilePic").value,
        FirstName: document.getElementById("floatingFirstName").value,
        LastName: document.getElementById("floatingLastName").value,
        MiddleName: document.getElementById("floatingMiddleName").value,
        Email: document.getElementById("floatingEmail").value,
        PhoneNumber: document.getElementById("floatingPhoneNumber").value,
        SubEmail: document.getElementById("floatingSubEmail").value,
        SubPhoneNumber: document.getElementById("floatingSubPhoneNumber").value,
        Address: document.getElementById("floatingAddress").value,
        LineID: document.getElementById("floatingLineID").value
    };
    var PasswordField = document.getElementById("floatingPassword").value;
    if (PasswordField !== "") {
        updateUserRequest.Password = PasswordField;
    }
    var xhr = new XMLHttpRequest();
    xhr.open("POST", url+"/biomedapi/users/update", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
               xalert("Updated User", 0, 5000);
                myUserRequest(null, true);
            } else {
               xalert(xhr.status + "-" + xhr.responseText, 1, -1);
            }
        }
    };
    xhr.send(JSON.stringify(updateUserRequest));
}

function logout() {
    removeToken();
    //window.location.href = "login.html";
}



function resizeImage(image, maxWidth, maxHeight) {
    var canvas = document.createElement('canvas');
    var ctx = canvas.getContext('2d');

    var width = image.width;
    var height = image.height;

    if (width < height) {
        if (width > maxWidth) {
            height *= maxWidth / width;
            width = maxWidth;
        }
    } else {
        if (height > maxHeight) {
            width *= maxHeight / height;
            height = maxHeight;
        }
    }

    canvas.width = width;
    canvas.height = height;

    ctx.fillStyle = 'white'; // Set background color to white
    ctx.fillRect(0, 0, canvas.width, canvas.height); // Fill the canvas with white color

    ctx.drawImage(image, 0, 0, width, height); // Draw the image on the canvas

    return canvas.toDataURL('image/jpeg');
}

function cropImage(imageDataUrl, size) {
    return new Promise((resolve, reject) => {
        var image = new Image();
        var canvas = document.createElement('canvas');
        var ctx = canvas.getContext('2d');

        canvas.width = size;
        canvas.height = size;

        image.onload = function() {
            var width = image.width;
            var height = image.height;

            var x = (width - size) / 2;
            var y = (height - size) / 2;

            ctx.drawImage(image, x, y, size, size, 0, 0, size, size);
            resolve(canvas.toDataURL('image/jpeg'));
        };

        image.onerror = reject; // Handle image load errors
        image.src = imageDataUrl;
    });
}

function processImage(file) {
    var reader = new FileReader();
    reader.onload = function(event) {
        var image = new Image();
        image.onload = async function() {
            var resizedImageDataUrl = resizeImage(image, 300, 300);
            try {
                var croppedImageDataUrl = await cropImage(resizedImageDataUrl, 300);
                var formData = new FormData();
                formData.append('file', dataURItoBlob(croppedImageDataUrl));
                var xhr = new XMLHttpRequest();
                xhr.open('POST', url + '/biomedapi/upload/profile', true);
                xhr.setRequestHeader('Authorization', 'Bearer ' + readToken());
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4) {
                        if (xhr.status === 200) {
                            xalert('Profile picture uploaded successfully', 0, 5000);
                            myUserRequest(function(err, response) {
                                if (err) {
                                    console.log(err);
                                    xalert("Error while fetching user", 1, null);
                                }
                            }, true);
                            setTimeout(function() {
                                location.reload();
                            }, 2000);
                        } else {
                            xalert(xhr.status + '-' + xhr.responseText, 1, -1);
                        }
                    }
                };
                xhr.send(formData);
            } catch (error) {
                console.error("Error cropping image:", error);
            }
        };
        image.src = event.target.result;
    };
    reader.readAsDataURL(file);
}

function dataURItoBlob(dataURI) {
    var byteString = atob(dataURI.split(',')[1]);
    var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
    var ab = new ArrayBuffer(byteString.length);
    var ia = new Uint8Array(ab);
    for (var i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([ab], { type: mimeString });
}

function uploadProfilePic() {
    var input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = function(event) {
        var file = event.target.files[0];
        processImage(file);
    };
    input.click();

    // Read in file
}