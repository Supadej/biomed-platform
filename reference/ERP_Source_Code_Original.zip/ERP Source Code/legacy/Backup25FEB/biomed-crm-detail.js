const urlParams = new URLSearchParams(window.location.search);
const leadid = urlParams.get("leadid");

const modalUsersList = document.getElementById("modalUsersList");
const select = document.getElementById("usersSelecter");
const groupSelect = document.getElementById("groupSelecter");
const contactSelect = document.getElementById("contactsSelecter");
const mainContactSelect = document.getElementById("mainContactsSelecter");

const modalContact = document.getElementById("modalContact");
const mainContactsList = document.getElementById("mainContactsList");

const modalContactsList = document.getElementById("modalContactsList");

// Sync modalIndividualPermissionsList with individualPermissionsUsersList
function syncContactsList() {
    const mainContactsList = document.getElementById('mainContactsList');
    mainContactsList.innerHTML = modalContactsList.innerHTML;
}

// Call the syncPermissionsList function whenever there is a change in modalIndividualPermissionsList
const observer = new MutationObserver(syncContactsList);
observer.observe(modalContactsList, { childList: true });

// Add an event listener to mainContactsList to update modalContact when its value changes

var mainuserid;





window.onload = function () {
  // Get the leadid from the URL parameter

  if (leadid === null) {
    xalert("Error: No leadid parameter found in the URL", 1, null);
    return;
  }

  // Get the token from the readToken() function
  const token = readToken();

  // Create a new XHR object
  const xhr = new XMLHttpRequest();

  // Open the XHR request
  xhr.open("GET", url + `/biomedapi/leads/${leadid}`, true);

  // Set the request headers
  xhr.setRequestHeader("Authorization", `Bearer ${token}`);

  // Set the onload function to handle the response
  xhr.onload = function () {
    if (xhr.status === 200) {
      getProducts((err, products) => {
        if (err) {
          console.error("Failed to fetch products:", err);
          return;
        }
        var productSelect = document.getElementById("product");
        products.forEach((product) => {
          const option = document.createElement("option");
          option.value = product.Id;
          option.textContent = product.Name;
          // Add any additional attributes or data to the option element if needed
          // option.setAttribute("data-subtext", product.Description);
          // option.setAttribute("data-price", product.Price);
          // ...

          // Append the option to the select element
          productSelect.appendChild(option);
        });
      });

      getSaleAreas((err, saleAreas) => {
        if (err) {
          console.error("Failed to fetch sale areas:", err);
          return;
        }
        var saleAreaSelect = document.getElementById("saleArea");
        saleAreas.forEach((saleArea) => {
          const option = document.createElement("option");
          option.value = saleArea.Id;
          option.textContent = saleArea.Name;
          // Add any additional attributes or data to the option element if needed
          // option.setAttribute("data-subtext", saleArea.Description);
          // option.setAttribute("data-price", saleArea.Price);
          // ...

          // Append the option to the select element
          saleAreaSelect.appendChild(option);
        });
      });
      // Parse the response JSON
      const response = JSON.parse(xhr.responseText);

      if (response.LeadName !== undefined && response.LeadName !== null) {
        document.getElementById("leadName").value = response.LeadName;
      }
      // if (response.MainCustomer !== undefined && response.MainCustomer !== null) {
      //     document.getElementById('mainCustomer').value = response.MainCustomer;
      // }
      // if (response.MainCustomerId !== undefined && response.MainCustomerId !== null) {
      //     document.getElementById('mainCustomerId').value = response.MainCustomerId;
      // }
      // if (response.MainUser !== undefined && response.MainUser !== null) {
      //     document.getElementById('mainUser').value = response.MainUser;
      // }
      // if (response.MainUserId !== undefined && response.MainUserId !== null) {
      //     document.getElementById('mainUserId').value = response.MainUserId;
      // }
      if (response.Creation !== undefined && response.Creation !== null) {
        document.getElementById("creation").value = timeFuck(response.Creation);
      }
      if (response.Expected !== undefined && response.Expected !== null) {
        document.getElementById("expected").value = timeFuck(response.Expected);
      }
      if (
        response.ExpectedRevenue !== undefined &&
        response.ExpectedRevenue !== null
      ) {
        document.getElementById("expectedRevenue").value =
          response.ExpectedRevenue;
      }
      if (
        response.AchivedRevenue !== undefined &&
        response.AchivedRevenue !== null
      ) {
        document.getElementById("achievedRevenue").value =
          response.AchivedRevenue;
      }
      if (
        response.CustomerNeeds !== undefined &&
        response.CustomerNeeds !== null
      ) {
        document.getElementById("customerNeeds").value = response.CustomerNeeds;
      }
      if (
        response.KeyDicisionMaker !== undefined &&
        response.KeyDicisionMaker !== null
      ) {
        document.getElementById("keyDecisionMaker").value =
          response.KeyDicisionMaker;
      }
      if (
        response.KeySellingPoints !== undefined &&
        response.KeySellingPoints !== null
      ) {
        document.getElementById("keySellingPoints").value =
          response.KeySellingPoints;
      }
      if (
        response.CompetitorInfo !== undefined &&
        response.CompetitorInfo !== null
      ) {
        document.getElementById("competitorInfo").value =
          response.CompetitorInfo;
      }
      if (
        response.AdditionalInfo !== undefined &&
        response.AdditionalInfo !== null
      ) {
        document.getElementById("additionalInfo").value =
          response.AdditionalInfo;
      }
      if (response.Budget !== undefined && response.Budget !== null) {
        document.getElementById("budget").value = response.Budget;
      }
      if (
        response.FundingSource !== undefined &&
        response.FundingSource !== null
      ) {
        document.getElementById("fundingSource").value = response.FundingSource;
      }
      if (response.ProjectID !== undefined && response.ProjectID !== null) {
        document.getElementById("projectID").value = response.ProjectID;
      }
      if (response.IsPO !== undefined && response.IsPO !== null) {
        document.getElementById("isPO").value = response.IsPO;
      }
      if (response.IsCollected !== undefined && response.IsCollected !== null) {
        document.getElementById("isCollected").value = response.IsCollected;
      }
      if (response.PaymentDue !== undefined && response.PaymentDue !== null) {
        document.getElementById("paymentDue").value = timeFuck(
          response.PaymentDue
        );
      }
      if (response.Other !== undefined && response.Other !== null) {
        document.getElementById("other").value = response.Other;
      }
      if (response.ProductId !== undefined && response.ProductId !== null) {
        document.getElementById("product").value = response.ProductId;
      }
      if (response.SaleAreaId !== undefined && response.SaleAreaId !== null) {
        document.getElementById("saleArea").value = response.SaleAreaId;
      }
      // Use the extracted data as needed
      // ...
      getPipelines((err, response) => {
        if (err) {
          console.error("Failed to fetch pipelines:", err);
          return;
        }

        const pipelineSelection = document.getElementById("pipelineSelection");

        response.forEach((pipeline) => {
          const radioInput = document.createElement("input");
          radioInput.type = "radio";
          radioInput.className = "btn-check";
          radioInput.name = "btnradio";
          radioInput.id = `pipeline${pipeline.Id}`;
          radioInput.autocomplete = "off";

          const label = document.createElement("label");
          label.className = "btn btn-outline-secondary small";
          label.htmlFor = `pipeline${pipeline.Id}`;
          label.textContent = pipeline.PipelineName;

          pipelineSelection.appendChild(radioInput);
          pipelineSelection.appendChild(label);
        });
      }, false);

      const pipelineId = response.CRMPipelineId;
      const pipelineRadio = document.getElementById(`pipeline${pipelineId}`);
      if (pipelineRadio) {
        pipelineRadio.checked = true;
      }

      const modalUsersList = document.getElementById("modalUsersList");

      const select = document.getElementById("usersSelecter");

      getUsers((error, users) => {
        if (error) {
          console.error("Failed to fetch users:", error);
          return;
        }

        //And main responsible user
        const primaryBadge = document.createElement("span");
        primaryBadge.classList.add(
          "badge",
          "bg-info",
          "text-dark",
          "py-1",
          "m-1",
          "align-middle",
          "text-wrap"
        );
        const Muser = users.find((Muser) => Muser.Id === response.MainUserId);
        if (Muser) {
          primaryBadge.innerHTML = `<strong><i class="fi fi-rr-chess-king align-middle mx-1"></i>Primary: </strong>${Muser.FirstName} ${Muser.LastName} (${Muser.Position})`;
        }
        mainuserid = response.MainUserId;
        modalUsersList.appendChild(primaryBadge);

        users.forEach((user) => {
          if (user.Id !== response.MainUserId) {
            const option = document.createElement("option");
            option.value = user.Id;
            option.textContent = `${user.FirstName} ${user.LastName}`;
            option.setAttribute("data-subtext", `${user.Position}`);
            select.appendChild(option);
          }
        });

        $(select).on(
          "changed.bs.select",
          function (e, clickedIndex, isSelected, previousValue) {
            const selectedOptions = Array.from(e.target.selectedOptions);
            modalUsersList.innerHTML = "";
            modalUsersList.appendChild(primaryBadge);
            selectedOptions.forEach((option) => {
              const badge = document.createElement("span");
              badge.classList.add(
                "badge",
                "biomed-bg-accent",
                "text-dark",
                "py-1",
                "m-1",
                "align-middle",
                "text-wrap"
              );
              badge.innerHTML = option.getAttribute("data-subtext")
                ? `${option.textContent} (${option.getAttribute(
                    "data-subtext"
                  )})`
                : option.textContent;
              modalUsersList.appendChild(badge);
            });
            document.getElementById("mainUsersList").innerHTML =
              modalUsersList.innerHTML;
          }
        );

        document.getElementById("mainUsersList").innerHTML =
          modalUsersList.innerHTML;
        // Refresh the selectpicker to update the options

        $(select).selectpicker("refresh");
      }, false);

      const userIds = response.LeadUsers.map((leadUser) => leadUser.UserId);
      const selectValues = userIds.map(String);
      $(select).selectpicker("val", selectValues);

      groupSelect.innerHTML = "";
      getGroups((err, groups) => {
        if (err) {
          console.error("Failed to fetch users:", err);
          return;
        }

        groups.forEach((group) => {
          const option = document.createElement("option");
          option.value = group.Id;
          option.textContent = group.GroupName;
          groupSelect.appendChild(option);
        });

        $(groupSelect).on(
          "changed.bs.select",
          function (e, clickedIndex, isSelected, previousValue) {
            const selectedOptions = Array.from(e.target.selectedOptions);
            selectedOptions.forEach((option) => {
              getGroupMembers(option.value, (err, users) => {
                if (err) {
                  console.error("Failed to fetch users:", err);
                  return;
                }

                valSelect = users.GroupUsers.map((user) => user.UserId)
                  .filter((item) => item !== response.mainUserId)
                  .map(String);
                $(select).selectpicker(
                  "val",
                  $(select).val().concat(valSelect)
                );
                console.log(valSelect);
              });
            });

            //document.getElementById("mainUsersList").innerHTML = modalUsersList.innerHTML;
          }
        );
        $(groupSelect).selectpicker("refresh");
      }, false);

      $(groupSelect).selectpicker("refresh");


      
      //Get contacts


      mainContactSelect.innerHTML = "";
      contactSelect.innerHTML = "";
      getContacts((err, contacts) => {
        if (err) {
          console.error("Failed to fetch users:", err);
          xalert("Failed to fetch users:" + err, 1, null);
          return;
        }
        
        contacts.forEach((contact) => {
          const option = document.createElement("option");
          option.value = contact.Id;
          option.textContent = contact.Name;
          if (contact.Position !== null && contact.Position !== undefined) {
            option.setAttribute("data-subtext", `${contact.Position}`);
          }
          contactSelect.appendChild(option);

          const mainOption = document.createElement("option");
          mainOption.value = contact.Id;
          mainOption.textContent = contact.Name;
          if (contact.Position !== null && contact.Position !== undefined) {
            mainOption.setAttribute("data-subtext", `${contact.Position}`);
          }
          mainContactSelect.appendChild(mainOption);
        });
        
        $(mainContactSelect).on(
            "changed.bs.select",
            modalContactsUpdate
        );


        $(contactSelect).on(
            "changed.bs.select",
            modalContactsUpdate
        );

        $(contactSelect).selectpicker("refresh");
        $(mainContactSelect).selectpicker("refresh");
        $(mainContactSelect).selectpicker("val", response.MainCustomerId.toString());
        const contactIds = response.LeadContacts.map(
            (contact) => contact.ContactId
        ).filter((id) => id !== response.MainUserId);
        const contactSelectValues = contactIds.map(String);
        $(contactSelect).selectpicker("val", contactSelectValues);
      }, false);
      $(contactSelect).selectpicker("refresh");
      $(mainContactSelect).selectpicker("refresh");
      cachingObject();
    } else {
      // Handle the error case
      xalert("Error:" + xhr.status, 1, null);
      console.error("Error:", xhr.status);
    }
  };

  // Send the XHR request
  xhr.send();
};

function contactsModal() {
    var contactsModal = new bootstrap.Modal("#multiContactModal", {
        focus: true
    });
    contactsModal.show();
    
}

function usersModal() {
  var multiSelectModal = new bootstrap.Modal("#multiSelectModal", {
    focus: true
  });
  multiSelectModal.show();
}
function updateLead(){
  let changedComponent = compareChange();
  let readableChanges = changedComponent.map(change => {
    let oldValue = Array.isArray(change.oldValue) ? change.oldValue.join(", ") : (change.oldValue || "N/A");
    let newValue = Array.isArray(change.newValue) ? change.newValue.join(", ") : (change.newValue || "N/A");
    return `${change.field}: ${oldValue} -> ${newValue}`;
  }).join("\n");

  console.log(readableChanges);
  createLog(readableChanges, JSON.stringify(changedComponent), parseInt(leadid), null, null, null, null, 4, function(err, log){
    if(err){
      console.error(err);
      return;
    }
    console.log('Log created successfully:', log);
    updateLeadRequest();
  });
}

function updateLeadRequest() {
  // Create a new XMLHttpRequest object
  


  var xhr = new XMLHttpRequest();
  if (document.querySelector('input[name="btnradio"]:checked') === null) {
    // The element is null, meaning no input with name "btnradio" is checked
    xalert("Error: No pipeline selected", 2, 5000);
    return;
  } 
  // Configure the POST request
  xhr.open("POST", url + "/biomedapi/leads/update", true);

  // Set the request headers
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());

  var mainContacts = Array.from(mainContactSelect.selectedOptions)
  // Prepare the data from the HTML form
  var data = {
    Id: leadid,
    LeadName: document.getElementById("leadName").value,
    MainCustomerId: parseInt(mainContacts[0].value),
    MainUserId: parseInt(mainuserid),
    Creation: timeFormater(document.getElementById("creation").value),
    LastUpdated: timeFormater(Date.now()),
    Expected: timeFormater(document.getElementById("expected").value),
    ExpectedRevenue: document.getElementById("expectedRevenue").value,
    AchivedRevenue: document.getElementById("achievedRevenue").value,
    CustomerNeeds: document.getElementById("customerNeeds").value,
    KeyDecisionMaker: document.getElementById("keyDecisionMaker").value,
    KeySellingPoints: document.getElementById("keySellingPoints").value,
    CompetitorInfo: document.getElementById("competitorInfo").value,
    AdditionalInfo: document.getElementById("additionalInfo").value,
    Budget: document.getElementById("budget").value,
    FundingSource: document.getElementById("fundingSource").value,
    ProjectID: document.getElementById("projectID").value,
    IsPO: document.getElementById("isPO").checked,
    IsCollected: document.getElementById("isCollected").checked,
    PaymentDue: timeFormater(document.getElementById("paymentDue").value),
    Other: document.getElementById("other").value,
    PipelineId: document
      .querySelector('input[name="btnradio"]:checked')
      .id.replace("pipeline", ""),

    //UserIds: document.getElementById('userIds').value.split(',').map(Number)
  };
  data.UserIds = Array.from(
    document.getElementById("usersSelecter").selectedOptions
  ).map((option) => parseInt(option.value));
  data.ContactIds = Array.from(
      document.getElementById("contactsSelecter").selectedOptions
  ).filter(option => option.value !== mainContacts[0].value)
  .map(option => parseInt(option.value));
  data.ProductId = parseInt(document.getElementById("product").value);
  data.SaleAreaId = parseInt(document.getElementById("saleArea").value);

  // Set the onload function to handle the response
  xhr.onload = function () {
    if (xhr.status === 200) {
      // Handle the success case
      xalert("Lead updated successfully", 0, null);
      console.log("Lead updated successfully");
      setTimeout(() => {
        window.location.href = "crm.html";
      }, 1000);
    } else {
      // Handle the error case
      xalert("Error:" + xhr.status + " " + xhr.responseText, 1, null);
      console.error("Error:", xhr.status);
    }
  };

  // Send the request with the JSON stringified data
  xhr.send(JSON.stringify(data));
}

function modalContactsUpdate() {
    const mainselectedOptions = Array.from(mainContactSelect.selectedOptions);
    modalContactsList.innerHTML = "";
    mainselectedOptions.forEach((option) => {
      const badge = document.createElement("span");
      badge.classList.add(
        "badge",
        "bg-info",
        "text-dark",
        "py-1",
        "m-1",
        "align-middle",
        "text-wrap"
      );
      badge.innerHTML = option.getAttribute("data-subtext")
        ? `${option.textContent} (${option.getAttribute(
            "data-subtext"
          )})`
        : option.textContent;
      modalContactsList.appendChild(badge);
    });
    const selectedOptions = Array.from(contactSelect.selectedOptions);
    
    selectedOptions.forEach((option) => {
      const badge = document.createElement("span");
      badge.classList.add(
        "badge",
        "biomed-bg-accent",
        "text-dark",
        "py-1",
        "m-1",
        "align-middle",
        "text-wrap"
      );
      badge.innerHTML = option.getAttribute("data-subtext")
        ? `${option.textContent} (${option.getAttribute(
            "data-subtext"
          )})`
        : option.textContent;
        if(mainselectedOptions[0].value !== option.value){
            modalContactsList.appendChild(badge);
        }
      
    });
}

function deleteLead(){
  // Create a new XMLHttpRequest object
  var xhr = new XMLHttpRequest();

  // Configure the DELETE request
  xhr.open("POST", url + "/biomedapi/leads/delete", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  // Set the request headers
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());

  // Set the onload function to handle the response
  xhr.onload = function () {
    if (xhr.status === 200) {
      // Handle the success case
      xalert("Lead deleted successfully", 0, null);
      console.log("Lead deleted successfully");
      setTimeout(() => {
        window.location.href = "crm.html";
      }, 1000);
    } else {
      // Handle the error case
      xalert("Error:" + xhr.status + " " + xhr.responseText, 1, null);
      console.error("Error:", xhr.status);
    }
  };

  
  // Send the DELETE request
  xhr.send(JSON.stringify({ Id: parseInt(leadid) }));
}
