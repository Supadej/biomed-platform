var url = ""; // empty string for production

const permissionsType = [
  { value: 0, name: 'noType', description: 'Placeholder it do nothing' },
  { value: 1, name: 'user_manage', description: 'Manage users (Can view/edit any users)' },
  { value: 2, name: 'user_permission_manage', description: 'Manage user permissions(Can view/edit any permission of users)' },
  { value: 3, name: 'lead_creation', description: 'Create leads' },
  { value: 4, name: 'lead_manage', description: 'Manage leads (Can view/edit any leads)' },
  { value: 5, name: 'contact_manage', description: 'Manage contacts (Can create/view/edit any contacts)' },
  { value: 6, name: 'event_manage', description: 'Manage events (Can view/edit any events)' },
  { value: 7, name: 'project_manage', description: 'Manage projects (Can view/edit any projects)' },
  { value: 8, name: 'log_manage', description: 'Manage logs (Can view/edit any logs)' },
  { value: 9, name: 'helpdesk_manage', description: 'Manage helpdesk (Can view/edit any helpdesk ticket)' },
  { value: 10, name: 'crm_access', description: 'No use right now' },
  { value: 11, name: 'project_access', description: 'Create projects' },
  { value: 12, name: 'event_access', description: 'Create events' },
  { value: 13, name: 'contact_access', description: 'Export contacts' },
  { value: 18, name: 'helpdesk_access', description: 'Access helpdesk (Can view/create any helpdesk ticket)' },
  { value: 19, name: 'inventory_access', description: 'Access inventory (Can view inventory)' },
  { value: 20, name: 'brand_manage', description: 'Manage brands (Can view/edit any brand)' },
  { value: 21, name: 'product_manage', description: 'Manage products (Can view/edit any product)' },
  { value: 22, name: 'stock_manage', description: 'Manage stock (Can view/edit any stock)' }

];

const permissionsTypeIndividual = [
  { value: 14, name: 'lead_manage_individual', description: 'Manage individual leads (View/edit leads of specific users)' },
  { value: 15, name: 'helpdesk_manage_individual', description: 'Manage individual helpdesk tickets (View/edit helpdesk tickets of specific users)' },
  { value: 16, name: 'event_manage_individual', description: 'Manage individual events (View/edit events of specific users)' },
  { value: 17, name: 'project_manage_individual', description: 'Manage individual projects (View/edit projects of specific users)' }
];


function isDefined(input) {
  if (input !== undefined && input !== null) return true;
  return false;
}

function sendLoginRequest(username, password, callback) {
  var xhr = new XMLHttpRequest();
  xhr.open("POST", url + "/biomedapi/login", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        /*var response = JSON.parse(xhr.responseText);
                var token = response.token;*/
        // Save token to cookie
        document.cookie = "jwtToken=" + xhr.responseText;
        myUserRequest(function (error, response) {
          if (error) {
            console.error(error);
            // Handle error
          } else {
            xalert(
              "Welcome " + response.FirstName + " " + response.LastName,
              0,
              -1
            );
            console.log(response);
            // Handle response
          }
        }, true);

        callback(null, xhr.responseText);
      } else if (xhr.status === 400) {
        callback(new Error("Incorrect Username/Password"), null);
      } else {
        callback(new Error(xhr.responseText), xhr.status);
      }
    }
  };
  var data = JSON.stringify({ username: username, password: password });
  xhr.send(data);
}

function myPermission(callback) {
  myUserRequest((error, user) => {

    if (error) {
      console.error('Failed to fetch user:', error);
      xalert('Failed to fetch user', 1, -1);
      return;
    }
    console.log(user);
    var permissions = user.Permissions;
    var mainPermissions = permissions.filter(permission => !permission.Type.includes("individual"));
    var individualPermissions = permissions.filter(permission => permission.Type.includes("individual"));
    var FullPermissions = {
      "MainPermissions":mainPermissions,
      "IndividualPermissions":individualPermissions  
    };
    console.log(FullPermissions);
    callback(null, FullPermissions);

  });

}

function getQuarterDateRange(quarter, year) {

  const yearAmp = year -1;
  //xalert("Year Amp: "+yearAmp,0,-1);
  //xalert("Quarter: "+quarter,0,-1);
  if (quarter === 0) {
      const quarterStartMonths = [5, 8, 11, 2]; // May, August, November, February
      const quarterEndMonths = [7, 10, 1, 4]; // July, October, January, April

      const quarterStartMonth = quarterStartMonths[0];
      const quarterEndMonth = quarterEndMonths[3];

      const startDate = new Date(`20${yearAmp}-${quarterStartMonth}-01`);
      const endDate = new Date(`20${yearAmp + 1}-${quarterEndMonth}-${getDaysInMonth(quarterEndMonth, yearAmp + 1)}`);
      endDate.setHours(23, 59, 59);
      console.log("Quarter to Range",startDate, endDate);
      
      return {
          startDate,
          endDate
      };
  }
  const quarterStartMonths = [5, 8, 11, 2]; // May, August, November, February
  const quarterEndMonths = [7, 10, 1, 4]; // July, October, December, March
  if (quarter < 1 || quarter > 4) {
      throw new Error('Invalid quarter');
  }

  if (yearAmp < 0 || yearAmp > 99) {
      throw new Error('Invalid year');
  }
  let startYear = parseInt(yearAmp);
  let endYear = parseInt(yearAmp);
  if (quarter === 4) {
      startYear += 1;
      endYear += 1;
  }
  if (quarter === 3) {
      endYear += 1;
  }


  const quarterStartMonth = quarterStartMonths[quarter - 1];
  const quarterEndMonth = quarterEndMonths[quarter - 1];

  let startDate = new Date(`20${startYear.toString()}-${quarterStartMonth}-01`);
  let endDate = new Date(`20${endYear.toString()}-${quarterEndMonth}-${getDaysInMonth(quarterEndMonth, endYear.toString())}`);
  startDate.setHours(0, 0, 0);
  endDate.setHours(23, 59, 59);
  if(iOS()){
    console.warn("iOS detected attempting to fix date");
    console.warn("Before",startDate,endDate);
    startDate.setFullYear(parseInt('20'+startYear.toString()),quarterStartMonth-1,1);
    endDate.setFullYear(parseInt('20'+endYear.toString()),quarterEndMonth-1,getDaysInMonth(quarterEndMonth, endYear.toString()));
    console.warn("After",startDate,endDate);
    //xalert("iOS Detected",2,-1);
    //xalert(startDate,2,-1);
    //xalert(endDate,2,-1);
  }
  console.log("Quarter to Range",startDate, endDate);
  return {
      startDate,
      endDate
  };
}

function getDaysInMonth(month, year) {
  return new Date(year, month, 0).getDate();
}


function myUserRequest(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("myUser");
  }
  var myUser = sessionStorage.getItem("myUser");
  if (myUser !== null) {
    if (callback === null) {
      return;
    }
    callback(null, JSON.parse(myUser));
    return;
  }

  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/myuser", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  var token = readToken();
  if (token === null) {
    callback("Token not found", null);
    return;
  }
  xhr.setRequestHeader("Authorization", "Bearer " + token);
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        var response = JSON.parse(xhr.responseText);
        // Save user object in session storage
        sessionStorage.setItem("myUser", JSON.stringify(response));
        if (callback === null) {
          return;
        }
        callback(null, response);
      } else {
        if (callback === null) {
          return;
        }
        callback(new Error(xhr.responseText), xhr.status);
      }
    }
  };
  xhr.send();
}

function readToken() {
  var token = null;
  var cookies = document.cookie.split(";");
  for (var i = 0; i < cookies.length; i++) {
    var cookie = cookies[i].trim();
    if (cookie.startsWith("jwtToken=")) {
      token = cookie.substring("jwtToken=".length, cookie.length);
      break;
    }
  }
  if (token === null) {
    window.location.href = "login.html";
  }
  return token;
}

function removeToken() {
    console.log("Removing token");
    document.cookie = "jwtToken=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=*;";
    sessionStorage.removeItem("myUser");
    sessionStorage.removeItem("users");
    sessionStorage.removeItem("pipelines");
    sessionStorage.removeItem("groups");
    console.log(readToken());
}

function getEvents(callback,query) {
    var token = readToken();
    var xhr = new XMLHttpRequest();
    if(query === undefined || query === null){
        xhr.open('GET', url+'/biomedapi/events', true);
    }
    else{
        xhr.open('POST', url+'/biomedapi/events', true);
    }
    //xhr.open('GET', url+'/biomedapi/events', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', 'Bearer ' + token);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                var events = JSON.parse(xhr.responseText);
                console.log(events);
                callback(null, events);
            } else {
                callback('Request failed with status ' + xhr.status+" error:"+xhr.responseText+"\nRequest:"+JSON.stringify(query), null);
            }
        }
    };
    if(query !== undefined && query !== null){
        xhr.send(JSON.stringify(query));
    }
    else{
        xhr.send();
    }
}

function xalert(text, style, time) {
  document.body.scrollTop = 0; // For Safari
  document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
  var alertBar = document.getElementById("alert-bar");
  alertBar.innerHTML = ""; // add // for debuging
  var styleClass = "";
  var styleText = "";

  switch (style) {
    case 0:
      styleClass = "success";
      styleText = "<strong>Successful</strong>";
      break;
    case 1:
      styleClass = "danger";
      styleText = "<strong>Error</strong>";
      break;
    case 2:
      styleClass = "warning";
      styleText = "<strong>Warning</strong>";
      break;
    case 3:
      styleClass = "info";
      styleText = "<strong>Info</strong>";
      break;
    default:
      styleClass = "info";
      styleText = "<strong>Info</strong>";
      break;
  }

  var alertElement = document.createElement("div");
  alertElement.classList.add(
    "alert",
    "alert-" + styleClass,
    "my-3",
    "mx-2",
    "text-wrap",
    "text-break"
  );
  alertElement.setAttribute("role", "alert");
  alertElement.innerHTML = styleText + "-" + text;

  alertBar.appendChild(alertElement);

  if (time !== -1 && time !== null) {
    setTimeout(function () {
      alertElement.remove();
    }, time);
  }
}
getUserById = function (callback,id ) {
  
  getUsers((error, users) => {

    if (error) {
      console.error('Failed to fetch users:', error);
      return;
    }
      const user = users.find(user => user.Id === id);
      callback(null, user);
  },false);



}

function getUsers(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("users");
  }
  var users = sessionStorage.getItem("users");
  if (users !== null) {
    callback(null, JSON.parse(users));
    return;
  }
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/users", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());
  xhr.onload = function () {
    if (xhr.status === 200) {
      var users = JSON.parse(xhr.responseText);
      sessionStorage.setItem("users", JSON.stringify(users));
      callback(null, users);
    } else {
      callback(new Error(xhr.responseText), null);
    }
  };
  xhr.onerror = function () {
    callback(new Error("Request failed"), null);
  };
  xhr.send();
}

function getPipelines(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("pipelines");
  }
  var pipelines = sessionStorage.getItem("pipelines");
  if (pipelines !== null) {
    callback(null, JSON.parse(pipelines));
    return;
  }
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/crm/pipelines", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());
  xhr.onload = function () {
    if (xhr.status === 200) {
      var pipelines = JSON.parse(xhr.responseText);
      pipelines.sort((a, b) => a.Order - b.Order);
      sessionStorage.setItem("pipelines", JSON.stringify(pipelines));
      callback(null, pipelines);
    } else {
      callback(new Error(xhr.responseText), null);
    }
  };
  xhr.onerror = function () {
    callback(new Error("Request failed"), null);
  };
  xhr.send();
}

function isValidGuid(input) {
  var guidRegex =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return guidRegex.test(input);
}

function iOS() {
  //xalert(navigator.userAgent,3,-1);
  var iOS = /(iPad|iPhone|iPod|OS X)/g.test(navigator.userAgent);
  return iOS;
}


function timeFormater(input) {
  const options = {
    month: "numeric",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "numeric",
    second: "numeric",
    hour12: true,
  };
  //'en-US', options
  // Create DateRange record
  var temp = new Date(input).toLocaleString("en-US", options);
  console.log(temp);
  /*if(iOS()){
    console.warn("iOS detected attempting to fix date");
    console.warn("Before",temp);
    temp = temp.replace(/-/g, "/");
    console.warn("After",temp);
  }*/
  return temp;
}


function timeFriendly(input) {
  const options = {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  };

  var temp = new Date(input).toLocaleString("en-US", options);
  return temp;
}

function timeFriendlyString(input) {
  const date = new Date(input);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  const seconds = String(date.getSeconds()).padStart(2, "0");
  const ampm = hours >= 12 ? "PM" : "AM";

  const formattedDate = `${month}-${day}-${year}`;
  const formattedTime = `${hours}:${minutes}:${seconds} ${ampm}`;

  return `${formattedDate} ${formattedTime}`;
}

function getLeads(callback,query = null) {
  const token = readToken();

  const xhr = new XMLHttpRequest();
  if(query === null){
    xhr.open("GET", url + "/biomedapi/leads", true);
  }
  else{
    xhr.open("POST", url + "/biomedapi/leads", true);
  }
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", `Bearer ${token}`);
  xhr.onreadystatechange = function () {
    if (xhr.readyState === XMLHttpRequest.DONE) {
      if (xhr.status === 200) {
        // Request successful
        console.log(xhr.responseText);
        const leads = JSON.parse(xhr.responseText);

        callback(null, leads);
      } else {
        // Request failed
        xalert("Error " + xhr.status + " " + xhr.responseText+"\nRequest:"+JSON.stringify(query), 1, -1);
        callback(xhr.status, null);
      }
    }
  };
  if(query !== null){
    xhr.send(JSON.stringify(query));
  }
  else{
    xhr.send();
  }
}

function timeFuck(input) {
  date = new Date(input);

  // Extract the components in local time
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");

  // Format the datetime-local value
  const localDateTimeString = `${year}-${month}-${day}T${hours}:${minutes}`;

  return localDateTimeString;
}

async function getColor(inputNumber) {
  if (sessionStorage.getItem("colors")) {
    var colors = JSON.parse(sessionStorage.getItem("colors"));
    // Rest of the code that uses the colors
  } else {
    const response = await fetch("colors.json");
    var colors = await response.json();
    sessionStorage.setItem("colors", JSON.stringify(colors));
    // Rest of the code that uses the colors
  }
  // Define the color categories in the order they should be returned
  const colorCategories = [
    "red",
    "orange",
    "yellow",
    "green",
    "blue",
    "purple",
    "pink",
    "brown",
    "black",
    "gray",
    "white",
  ];

  // Calculate the color category and index within that category

  const colorCategory = inputNumber % colorCategories.length;
  const colorIndex = Math.floor(inputNumber / colorCategories.length);

  // Get the color and its hex code
  const color = colors[colorCategories[colorCategory]][colorIndex];

  const hexCode = color.code;

  // Calculate the brightness of the color to determine the text color
  const r = parseInt(hexCode.slice(1, 3), 16);
  const g = parseInt(hexCode.slice(3, 5), 16);
  const b = parseInt(hexCode.slice(5, 7), 16);
  const brightness = Math.round((r * 299 + g * 587 + b * 114) / 1000);
  const textColor = brightness > 125 ? "black" : "white";
  console.log({ color: color, textColor: textColor });
  // Return the color and the text color
  return { color: color, textColor: textColor};
}

function getGroups(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("groups");
  }
  var groups = sessionStorage.getItem("groups");
  if (groups !== null) {
    callback(null, JSON.parse(groups));
    return;
  }
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/groups", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());
  xhr.onload = function () {
    if (xhr.status === 200) {
      var groups = JSON.parse(xhr.responseText);
      callback(null, groups);
      sessionStorage.setItem("groups", JSON.stringify(groups));
    } else {
      callback(new Error(xhr.responseText), null);
    }
  };
  xhr.onerror = function () {
    callback(new Error("Request failed"), null);
  };
  xhr.send();
}

function getGroupMembers(groupId, callback) {
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/groups/" + groupId, true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());
  xhr.onload = function () {
    if (xhr.status === 200) {
      var members = JSON.parse(xhr.responseText);
      console.log(members);
      callback(null, members);
    } else {
      callback(new Error(xhr.responseText), null);
    }
  };
  xhr.onerror = function () {
    callback(new Error("Request failed"), null);
  };
  xhr.send();
}

let timeoutId;

function startShaking(button, redirect) {
  button.classList.add("shake");
  timeoutId = setTimeout(() => {
    redirect();
  }, 1000);
}

function stopShaking(button) {
    clearTimeout(timeoutId);
    button.classList.remove('shake');
}


function getContacts(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("contacts");
    Object.keys(sessionStorage).forEach(key => {
      if (key.startsWith("contact:")) {
        sessionStorage.removeItem(key);
      }
    });
  }
  var contacts = sessionStorage.getItem("contacts");

  if (contacts !== null) {
    callback(null, JSON.parse(contacts));

  } else {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url + "/biomedapi/contacts", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onreadystatechange = function () {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          var contacts = JSON.parse(xhr.responseText);
          sessionStorage.setItem("contacts", JSON.stringify(contacts));
          callback(null, contacts);
        } else {
          callback(new Error("Failed to get contacts"), null);
        }
      }
    };
    xhr.send();
  }
}

function getContactById(id, callback) {
  var contact = sessionStorage.getItem("contact:"+id);
  if (contact !== null) {
    callback(null, JSON.parse(contact));
  } else {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", url + "/biomedapi/contacts/" + id, true);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.setRequestHeader("Authorization", "Bearer " + readToken());
        xhr.onload = function () {
          if (xhr.readyState === xhr.DONE) {
            if (xhr.status === 200) {
              var contact = JSON.parse(xhr.responseText);
              sessionStorage.setItem("contact:"+id, JSON.stringify(contact));
              callback(null, contact);
            } else {
              callback("Error: " + xhr.status);
            }
          }
        };
        xhr.onerror = function () {
          callback("Request failed");
        };
        xhr.send();
      }
}

function getIDFromSelection(selection) {
  return Array.from(
    selection.selectedOptions
  ).map((option) => parseInt(option.value))
}

function clearCache () {
  sessionStorage.clear();
}


function getBillings(callback,force) {
  if(force === true){
    sessionStorage.removeItem("billing");
  }
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/billinginformations", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());
  xhr.onload = function () {
    if (xhr.status === 200) {
      var billing = JSON.parse(xhr.responseText);
      sessionStorage.setItem("billing", JSON.stringify(billing));
      callback(null, billing);
    } else {
      callback(new Error(xhr.responseText), null);
    }
  };
  xhr.onerror = function () {
    callback(new Error("Request failed"), null);
  };
  xhr.send();
}

function getProducts(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("product");
  }
  var product = sessionStorage.getItem("product");
  if (product !== null) {
    callback(null, JSON.parse(product));
  } else {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url + "/biomedapi/products", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onload = function () {
      if (xhr.status === 200) {
        var product = JSON.parse(xhr.responseText);
        sessionStorage.setItem("product", JSON.stringify(product));
        callback(null, product);
      } else {
        callback(new Error(xhr.responseText), null);
      }
    };
    xhr.onerror = function () {
      callback(new Error("Request failed"), null);
    };
    xhr.send();
  }
}

function getProductById(id, callback) {
  var product = sessionStorage.getItem("product:" + id);
  if (product !== null) {
    callback(null, JSON.parse(product));
  } else {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url + "/biomedapi/products/" + id, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onload = function () {
      if (xhr.readyState === xhr.DONE) {
        if (xhr.status === 200) {
          sessionStorage.setItem("product:" + id, xhr.responseText);
          callback(null, JSON.parse(xhr.responseText));
        } else {
          callback("Error: " + xhr.status);
        }
      }
    };
    xhr.onerror = function () {
      callback("Request failed");
    };
    xhr.send();
  }
}

function getSaleAreas(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("saleArea");
  }
  var saleArea = sessionStorage.getItem("saleArea");
  if (saleArea !== null) {
    callback(null, JSON.parse(saleArea));
  } else {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url + "/biomedapi/saleareas", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onload = function () {
      if (xhr.status === 200) {
        var saleArea = JSON.parse(xhr.responseText);
        sessionStorage.setItem("saleArea", JSON.stringify(saleArea));
        callback(null, saleArea);
      } else {
        callback(new Error(xhr.responseText), null);
      }
    };
    xhr.onerror = function () {
      callback(new Error("Request failed"), null);
    };
    xhr.send();
  }
}
function getSaleAreaById(id) {
  return new Promise((resolve, reject) => {
    var saleArea = sessionStorage.getItem("saleArea:" + id);
    if (saleArea !== null) {
      resolve(JSON.parse(saleArea));
    } else {
      var xhr = new XMLHttpRequest();
      xhr.open("GET", url + "/biomedapi/saleareas/" + id, true);
      xhr.setRequestHeader("Content-Type", "application/json");
      xhr.setRequestHeader("Authorization", "Bearer " + readToken());
      xhr.onload = function () {
        if (xhr.readyState === xhr.DONE) {
          if (xhr.status === 200) {
            sessionStorage.setItem("saleArea:" + id, xhr.responseText);
            resolve(JSON.parse(xhr.responseText));
          } else {
            reject("Error: " + xhr.status);
          }
        }
      };
      xhr.onerror = function () {
        reject("Request failed");
      };
      xhr.send();
    }
  });
}

function getProjects(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("projects");
  }
  var projects = sessionStorage.getItem("projects");
  if (projects !== null) {
    callback(null, JSON.parse(projects));
  } else {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url + "/biomedapi/projects", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onload = function () {
      if (xhr.status === 200) {
        var projects = JSON.parse(xhr.responseText);
        sessionStorage.setItem("projects", JSON.stringify(projects));
        callback(null, projects);
      } else {
        callback(new Error(xhr.responseText), null);
      }
    };
    xhr.onerror = function () {
      callback(new Error("Request failed"), null);
    };
    xhr.send();
  }
}

function getProjectById(id, callback) {
  var project = sessionStorage.getItem("project:" + id);
  if (project !== null) {
    callback(null, JSON.parse(project));
  } else {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url + "/biomedapi/projects/" + id, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onload = function () {
      if (xhr.readyState === xhr.DONE) {
        if (xhr.status === 200) {
          sessionStorage.setItem("project:" + id, xhr.responseText);
          callback(null, JSON.parse(xhr.responseText));
        } else {
          callback("Error: " + xhr.status);
        }
      }
    };
    xhr.onerror = function () {
      callback("Request failed");
    };
    xhr.send();
  }
}

function headerSetup(){
  const header = document.querySelector("header");
  console.log("Setting up header");
  console.log(header);
  header.innerHTML = `
    <div class="px-3 py-2 biomed-bg-dark border-bottom">
      <div class="container">
        <div class="row mx-auto my-auto px-3 py-0 auto-fit fs-2 fw-bold">
          <a href="/" class="p-0 m-0 text-decoration-none">
            <img src="https://www.biomedthai.com/images/logo.png" alt="biomed diagnostic">
          </a>
        </div>
        <div class="d-flex flex-wrap align-items-center justify-content-between">
          <ul class="nav col-12 my-2 justify-content-center my-md-0 text-small">
            <li>
              <a href="index.html" class="nav-link biomed-hover rounded">
                <i class="fi fi-rr-user"></i>
                User
              </a>
            </li>
            <li>
              <a href="crm.html" class="nav-link biomed-hover rounded">
                <i class="fi fi-rr-crm-computer"></i>
                CRM
              </a>
            </li>
            <li>
              <a href="event.html" class="nav-link biomed-hover rounded">
                <i class="fi fi-rr-calendar-day"></i>
                Event
              </a>
            </li>
            <li>
              <a href="project.html" class="nav-link biomed-hover rounded">
                <i class="fi fi-rr-diagram-project"></i>
                Project
              </a>
            </li>
            <li>
              <a href="contact.html" class="nav-link biomed-hover rounded">
                <i class="fi fi-rr-review"></i>
                Contact
              </a>
            </li>
            <li>
              <a href="helpdesk.html" class="nav-link biomed-hover rounded">
                <i class="fi fi-rr-wrench-alt"></i>
                Helpdesk
              </a>
            </li>
            <li>
              <a href="#" class="nav-link biomed-disabled-nav disabled rounded">
                <i class="fi fi-rr-file-invoice"></i>
                Invoice & Order
              </a>
            </li>
            <li>
              <a href="#" class="nav-link biomed-hover biomed-disabled-nav disabled rounded">
                <i class="fi fi-rr-box-alt"></i>
                Inventory
              </a>
            </li>
            <li>
              <a href="#" class="nav-link biomed-disabled-nav disabled rounded">
                <i class="fi fi-rr-shipping-fast"></i>
                Delivery
              </a>
            </li>
            <li>
              <a href="#" class="nav-link biomed-disabled-nav disabled rounded">
                <i class="fi fi-rr-analyse-alt"></i>
                Data Visualization
              </a>
            </li>
            <li>
              <a href="management.html" class="nav-link biomed-hover rounded">
                <i class="fi fi-rr-user-gear"></i>
                Management
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  `;
}
headerSetup(); //Run Header Setup


function clearsession(){
  clearCache();
  setTimeout(() => { location.reload(); }, 500);
}


function getTargets(callback,query = null){
  var xhr = new XMLHttpRequest();
  xhr.open("POST", url + "/biomedapi/targets", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        var targets = JSON.parse(xhr.responseText);
        callback(null, targets);
      } else {
        var error = new Error(xhr.responseText);
        error.message = error.message + "\nRequest:"+JSON.stringify(query);
        callback(error, null);
      }
    }
  };
  if(query !== null){
    xhr.send(JSON.stringify(query));
  }
  else{
    xhr.send();
  }

}
function formatDateOnly(date) {
  const options = { day: '2-digit', month: '2-digit', year: 'numeric' };
  const formattedDate = new Date(date).toLocaleDateString(undefined, options);
  return formattedDate;
}
function getRemainingDays(endDate) {
  const today = new Date();
  const targetDate = new Date(endDate);
  const timeDiff = targetDate.getTime() - today.getTime();
  const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
  return daysDiff >= 0 ? (daysDiff <= 30 ? '⚠️' : '') + daysDiff + " Days remaining" : 'Overdue ' + Math.abs(daysDiff) + ' Days';
}

function getQuarterAndYearByDate(date) {
  const month = date.getMonth();
  const year = month <=3 ? date.getFullYear(): date.getFullYear()+1;
  let quarter;
  if(month == 4||month == 5||month == 6){
    quarter = "Q1";
  }
  if(month == 7||month == 8||month == 9){
    quarter = "Q2";
  }
  if(month == 10||month == 11||month == 0){
    quarter = "Q3";
  } 
  if(month == 1||month == 2||month == 3){
    quarter = "Q4";
  }

  let output = {
    input: date,
    quarter: quarter,
    month: month,
    year: year
  }

  console.log('Date to Quarter',output);
  return output;
}

function AutoComma(number) {
  return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}


//section of helpdesk
function GetHelpdeskPipeline(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("helpdeskPipeline");
  }
  var helpdeskPipeline = sessionStorage.getItem("helpdeskPipeline");
  if (helpdeskPipeline !== null) {
    callback(null, JSON.parse(helpdeskPipeline));
  } else {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url + "/biomedapi/helpdesk/pipeline", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onload = function () {
      if (xhr.status === 200) {
        var helpdeskPipeline = JSON.parse(xhr.responseText);
        helpdeskPipeline.sort((a, b) => a.Order - b.Order);
        sessionStorage.setItem("helpdeskPipeline", JSON.stringify(helpdeskPipeline));
        callback(null, helpdeskPipeline);
      } else {
        callback(new Error(xhr.responseText), null);
      }
    };
    xhr.onerror = function () {
      callback(new Error("Request failed"), null);
    };
    xhr.send();
  }
}

function getTickets(callback, query = null) {
  const token = readToken();
  const xhr = new XMLHttpRequest();

  if (query === null) {
    xhr.open("GET", url + "/biomedapi/helpdesk/tickets", true);
  } else {
    xhr.open("POST", url + "/biomedapi/helpdesk/tickets", true);
  }

  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", `Bearer ${token}`);
  xhr.onreadystatechange = function () {
    if (xhr.readyState === XMLHttpRequest.DONE) {
      if (xhr.status === 200) {
        const tickets = JSON.parse(xhr.responseText);
        callback(null, tickets);
      } else {
        callback(new Error(xhr.responseText), null);
      }
    }
  };

  if (query !== null) {
    xhr.send(JSON.stringify(query));
  } else {
    xhr.send();
  }
}

function priorityFormatting(value) {
  var priority = 0;
  var intvalue = parseInt(value);
  switch (intvalue) {
    case -1:
      priority = "Any Priority📄";
          break;
    case 0:
      priority = "No Priority💤";
      break;
    case 1:
      priority = "Low🧊";
      break;
    case 2:
      priority = "Medium⚒️";
      break;
    case 3:
      priority = "High⚡";
      break;
    case 4:
      priority = "Urgent🔥";
      break;
    case 5:
      priority = "Critical❤️‍🔥";
      break;
    default:
      priority = "Unknown❓";
      break;
  }
  return priority;
}

function uploadFile(callback) {
  const input = document.createElement('input');
  input.type = 'file';
  input.onchange = function(event) {
    const file = event.target.files[0];
    if (!file) {
      callback(new Error("No file selected"), null);
      return;
    }

    const formData = new FormData();
    formData.append('file', file);
    

    const xhr = new XMLHttpRequest();
    xhr.open('POST', url + '/biomedapi/misc/uploadfile', true);
    xhr.setRequestHeader('Authorization', 'Bearer ' + readToken());
    xhr.onreadystatechange = function() {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          console.log(xhr.responseText);
          callback(null, xhr.responseText);
        } else {
          console.error(xhr.status,xhr.responseText);
          callback(new Error(xhr.responseText), null);
        }
      }
    };
    
    xhr.send(formData);
  };
  input.click();
}

var initialValues = {};
function cachingObject(){

  initialValues = {}; // Reset previous values

  document.querySelectorAll('input, select, textarea').forEach(element => {
      const key = element.name || element.id;

      if (element.tagName === 'SELECT' && element.multiple) {
          // Store an array of selected values for multiple selects
          initialValues[key] = Array.from(element.selectedOptions).map(option => option.value);
      } else {
          initialValues[key] = element.value;
      }
  });

}

function compareChange() {
  let changes = [];

    document.querySelectorAll('input, select, textarea').forEach(element => {
        const key = element.name || element.id;
        let newValue;

        if (element.tagName === 'SELECT' && element.multiple) {
            newValue = Array.from(element.selectedOptions).map(option => option.value);
        } else {
            newValue = element.value;
        }

        // Check for changes (array comparison for multi-select)
        if (JSON.stringify(initialValues[key]) !== JSON.stringify(newValue)) {
            changes.push({
                field: key,
                oldValue: initialValues[key],
                newValue: newValue
            });
        }
    });

    console.log('Changes:', changes);
    return changes; // Returns an array of changed fields

  
}