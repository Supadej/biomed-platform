const urlParams = new URLSearchParams(window.location.search);
const hdid = urlParams.get("leadid");

const modalUsersList = document.getElementById("modalUsersList");
const select = document.getElementById("usersSelecter");
const groupSelect = document.getElementById("groupSelecter");
const contactSelect = document.getElementById("contactsSelecter");
const mainContactSelect = document.getElementById("mainContactsSelecter");

const modalContact = document.getElementById("modalContact");
const mainContactsList = document.getElementById("mainContactsList");

const modalContactsList = document.getElementById("modalContactsList");

// Sync modalIndividualPermissionsList with individualPermissionsUsersList
function syncContactsList() {
    const mainContactsList = document.getElementById('mainContactsList');
    mainContactsList.innerHTML = modalContactsList.innerHTML;
}
const jobType = [
  { value: 0, jobType: "Safe_Support" },
  { value: 1, jobType: "Maintenance" },
  { value: 2, jobType: "Installation" },
  { value: 3, jobType: "Scheduled_Maintenance" },
  { value: 4, jobType: "Relocation" },
  { value: 5, jobType: "Repair" },
  { value: 6, jobType: "Training" },
  { value: 7, jobType: "Update" },
  { value: 8, jobType: "Calibration" },
  { value: 9, jobType: "Upgrade" },
  { value: 10, jobType: "Other" }
];
const instumentalStatus = [
  { value: 0, status: "In_Warranty" },
  { value: 1, status: "Reagent_Rental" },
  { value: 2, status: "Out_of_Warranty" },
  { value: 3, status: "Company_Property" },
  { value: 4, status: "Service_Contract" },
  { value: 5, status: "Customer_Property" },
  { value: 6, status: "Other" }
];

// Call the syncPermissionsList function whenever there is a change in modalIndividualPermissionsList
const observer = new MutationObserver(syncContactsList);
observer.observe(modalContactsList, { childList: true });

// Add an event listener to mainContactsList to update modalContact when its value changes

var mainuserid;




function readPermission() {
  myPermission(function (err, Permissions) {
    if (err) {
      xalert("Failed to fetch permissions:" + err, 1, null);
      return;
    }/* ideally
    if(Permissions.MainPermissions.find(permission => permission.Type === "helpdesk_manage")){ //Helpdesk Manage check
      getUsers((error, users) => {
        if (error) {
          console.error("Failed to fetch users:", error);
          return;
        }
        const assignedUserSelect = document.getElementById("assignedUser");
        users.forEach((user) => {
          const option = document.createElement("option");
          option.value = user.Id;
          option.textContent = `${user.FirstName} ${user.LastName}`;
          assignedUserSelect.appendChild(option);
        });
      });
    }
    else if(Permissions.IndividualPermissions.find(permission => permission.Type === "helpdesk_manage_individual")){ //Helpdesk Manage Individual check
      getUsers((error, users) => {
        if (error) {
          console.error("Failed to fetch users:", error);
          return;
        }
        const assignedUserSelect = document.getElementById("assignedUser");
        users.forEach((user) => {
            if(Permissions.IndividualPermissions.find(permission => permission.PermissionKey === user.Id.toString() && permission.Type === "helpdesk_manage_individual")){
            const option = document.createElement("option");
            option.value = user.Id;
            option.textContent = `${user.FirstName} ${user.LastName}`;
            assignedUserSelect.appendChild(option);
        }
        });
      });
    }*/


      if(Permissions.MainPermissions.find(permission => permission.Type === "helpdesk_manage")){ //Helpdesk Manage check
          getUsers((error, users) => {
            if (error) {
              console.error("Failed to fetch users:", error);
              return;
            }
            const assignedUserSelect = document.getElementById("assignedUser");
            users.forEach((user) => {
                if(Permissions.IndividualPermissions.find(permission => permission.PermissionKey === user.Id.toString() && permission.Type === "helpdesk_manage_individual")){
                const option = document.createElement("option");
                option.value = user.Id;
                option.textContent = `${user.FirstName} ${user.LastName}`;
                assignedUserSelect.appendChild(option);
            }
            });
          });
      }
    {
      
    }
    
  });
}

function disableInputs() {

  // Select all input, textarea, and select elements
const inputs = document.querySelectorAll('input');
const textareas = document.querySelectorAll('textarea');
const selects = document.querySelectorAll('select');

// Make all input and textarea elements read-only
inputs.forEach(input => input.setAttribute('readonly', true));
textareas.forEach(textarea => textarea.setAttribute('readonly', true));

// Make all select elements disabled
selects.forEach(select => select.setAttribute('disabled', true));
}

function shareLead() {
  window.location.href = `ticket-report.html?id=${hdid}`;
}

window.onload = function () {
  // Get the leadid from the URL parameter

  if (hdid === null) {
    xalert("Error: No hdid parameter found in the URL", 1, null);
    return;
  }

  // Get the token from the readToken() function
var priority = document.getElementById('priority');

noUiSlider.create(priority, {
    start: [0],
    step: 1,
    tooltips: {to:function (value) {return priorityFormatting(value);}},
    range: {
        'min': 0,
        'max': 5
    }
});


  const token = readToken();

  // Create a new XHR object
  const xhr = new XMLHttpRequest();
  readPermission();
  // Open the XHR request
  xhr.open("GET", url + `/biomedapi/helpdesk/ticket/${hdid}`, true);

  // Set the request headers
  xhr.setRequestHeader("Authorization", `Bearer ${token}`);

  // Set the onload function to handle the response
  xhr.onload = function () {
    if (xhr.status === 200) {
      // Parse the response JSON
      const response = JSON.parse(xhr.responseText);
      console.log(response);


      getProducts((err, products) => {
        if (err) {
          console.error("Failed to fetch products:", err);
          return;
        }
        var productSelect = document.getElementById("product");
        products.forEach((product) => {
          const option = document.createElement("option");
          option.value = product.Id;
          option.textContent = product.Name;
          // Add any additional attributes or data to the option element if needed
          // option.setAttribute("data-subtext", product.Description);
          // option.setAttribute("data-price", product.Price);
          // ...

          // Append the option to the select element
          productSelect.appendChild(option);
        });
        
      if (response.ProductId !== undefined && response.ProductId !== null) {
        document.getElementById("product").value = response.ProductId;

      }
      });

      getSaleAreas((err, saleAreas) => {
        if (err) {
          console.error("Failed to fetch sale areas:", err);
          return;
        }
        var saleAreaSelect = document.getElementById("saleArea");
        saleAreas.forEach((saleArea) => {
          const option = document.createElement("option");
          option.value = saleArea.Id;
          option.textContent = saleArea.Name;
          // Add any additional attributes or data to the option element if needed
          // option.setAttribute("data-subtext", saleArea.Description);
          // option.setAttribute("data-price", saleArea.Price);
          // ...

          // Append the option to the select element
          saleAreaSelect.appendChild(option);
        });
        if (response.SaleAreaId !== undefined && response.SaleAreaId !== null) {
          document.getElementById("saleArea").value = response.SaleAreaId;
        }
      });
 
      myPermission(function (err, Permissions) {
        if (err) {
          xalert("Failed to fetch permissions:" + err, 1, null);
          return;
        }
        myUserRequest(function (error, user) {
          if (error) {
            xalert("Failed to fetch user:" + error, 1, null);
            return; 
          }
          if(Permissions.MainPermissions.find(permission => permission.Type === "helpdesk_manage")){
            console.log("Main Permission");
            if(response.AssignedToUserId !== undefined&& response.AssignedToUserId !== null){
              assignedUserSelect = document.getElementById("assignedUser");

              if (!Array.from(assignedUserSelect.options).some(option => option.value == response.AssignedToUserId)) {
                getUserById((err,user) => {
                  if (err) {
                    console.error("Failed to fetch user:", err);
                    return;
                  }
                  assignedUserSelect = document.getElementById("assignedUser");
                  const option = document.createElement("option");
                  option.value = user.Id;
                  option.textContent = `${user.FirstName} ${user.LastName}`;
                  assignedUserSelect.appendChild(option);
                  assignedUserSelect.value = response.AssignedToUserId;
                },response.AssignedToUserId);
              }
              
            }else{
             // assignedUserSelect.value = response.AssignedToUserId;
            }
            
          }else if(response.AssignedToUserId == user.Id )
          {
            priority.noUiSlider.disable();
            assignedUserSelect = document.getElementById("assignedUser");
            assignedUserSelect.innerHTML = "";
            const option = document.createElement("option");
            option.value = user.Id;
            option.textContent = `${user.FirstName} ${user.LastName}`;
            assignedUserSelect.appendChild(option);
          }
          else{
            disableInputs();
            document.getElementById("controlpane").innerHTML = "Read Only";
            priority.noUiSlider.disable();
            if(response.AssignedToUserId !== null && response.AssignedToUserId !== undefined){
             
              getUserById((err,user) => {
                if (err) {
                  console.error("Failed to fetch user:", err);
                  return;
                }
                assignedUserSelect = document.getElementById("assignedUser");
                assignedUserSelect.innerHTML = "";
                const option = document.createElement("option");
                option.value = user.Id;
                option.textContent = `${user.FirstName} ${user.LastName}`;
                assignedUserSelect.appendChild(option);

              },response.AssignedToUserId);
              
            }else{
                assignedUserSelect = document.getElementById("assignedUser");
                assignedUserSelect.innerHTML = "";
                const option = document.createElement("option");
                option.value = -1;
                option.textContent = `Unassigned`;
                assignedUserSelect.appendChild(option);
            }
            

            console.log("Disabled inputs");
          }
    
          });
    

        });
        
      
      if (response.Title !== undefined && response.Title !== null) {
        document.getElementById("leadName").value = response.Title;
      }
      if (response.Problem !== undefined && response.Problem !== null) {
        document.getElementById("problem").value = response.Problem;
        
      }
      if (response.CreatedDate !== undefined && response.CreatedDate !== null) {
        document.getElementById("creation").value = timeFuck(response.CreatedDate);
      }
      // if (response.MainCustomer !== undefined && response.MainCustomer !== null) {
      //     document.getElementById('mainCustomer').value = response.MainCustomer;
      // }
      // if (response.MainCustomerId !== undefined && response.MainCustomerId !== null) {
      //     document.getElementById('mainCustomerId').value = response.MainCustomerId;
      // }
      // if (response.MainUser !== undefined && response.MainUser !== null) {
      //     document.getElementById('mainUser').value = response.MainUser;
      // }
      // if (response.MainUserId !== undefined && response.MainUserId !== null) {
      //     document.getElementById('mainUserId').value = response.MainUserId;
      // }
      if (response.Priority !== undefined && response.Priority !== null) {
        priority.noUiSlider.set(response.Priority);
      }

      if (response.Solution !== undefined && response.Solution !== null) {
        document.getElementById("solution").value = response.Solution;
      }
      if (response.Instumental !== undefined && response.Instumental !== null) {
        document.getElementById("instumental").value = response.Instumental;
      }
      if (response.Model !== undefined && response.Model !== null) {
        document.getElementById("model").value = response.Model;
      }
      if (response.SerialNumber !== undefined && response.SerialNumber !== null) {
        document.getElementById("serialNumber").value = response.SerialNumber;
      }
      if (response.InstumentalStatus !== undefined && response.InstumentalStatus !== null) {
        const instrumentalStatusValue = instumentalStatus.find(status => status.status === response.InstumentalStatus)?.value;
        document.getElementById("instumentalStatus").value = instrumentalStatusValue !== undefined ? instrumentalStatusValue : 0;
      }
      if (response.JobType !== undefined && response.JobType !== null) {
        const jobTypeValue = jobType.find(job => job.jobType === response.JobType)?.value;
        document.getElementById("jobType").value = jobTypeValue !== undefined ? jobTypeValue : 0;
      }
      
      // Use the extracted data as needed
      // ...
      GetHelpdeskPipeline((err, response) => {
        if (err) {
          console.error("Failed to fetch pipelines:", err);
          return;
        }

        const pipelineSelection = document.getElementById("pipelineSelection");

        response.forEach((pipeline) => {
          const radioInput = document.createElement("input");
          radioInput.type = "radio";
          radioInput.className = "btn-check";
          radioInput.name = "btnradio";
          radioInput.id = `pipeline${pipeline.Id}`;
          radioInput.autocomplete = "off";

          const label = document.createElement("label");
          label.className = "btn btn-outline-secondary small";
          label.htmlFor = `pipeline${pipeline.Id}`;
          label.textContent = pipeline.Name;

          pipelineSelection.appendChild(radioInput);
          pipelineSelection.appendChild(label);
        });
      }, false);

      const pipelineId = response.PipelineId;
      const pipelineRadio = document.getElementById(`pipeline${pipelineId}`);
      if (pipelineRadio) {
        pipelineRadio.checked = true;
      }

      const modalUsersList = document.getElementById("modalUsersList");

      const select = document.getElementById("usersSelecter");

      getUsers((error, users) => {
        if (error) {
          console.error("Failed to fetch users:", error);
          return;
        }

        //And main responsible user
        const primaryBadge = document.createElement("span");
        primaryBadge.classList.add(
          "badge",
          "bg-info",
          "text-dark",
          "py-1",
          "m-1",
          "align-middle",
          "text-wrap"
        );
        const Muser = users.find((Muser) => Muser.Id === response.CreatedByUserId);
        if (Muser) {
          primaryBadge.innerHTML = `<strong><i class="fi fi-rr-chess-king align-middle mx-1"></i>Primary: </strong>${Muser.FirstName} ${Muser.LastName} (${Muser.Position})`;
        }
        mainuserid = response.CreatedByUserId;
        modalUsersList.appendChild(primaryBadge);

        users.forEach((user) => {
          if (user.Id !== response.CreatedByUserId) {
            const option = document.createElement("option");
            option.value = user.Id;
            option.textContent = `${user.FirstName} ${user.LastName}`;
            option.setAttribute("data-subtext", `${user.Position}`);
            select.appendChild(option);
          }
        });

        $(select).on(
          "changed.bs.select",
          function (e, clickedIndex, isSelected, previousValue) {
            const selectedOptions = Array.from(e.target.selectedOptions);
            modalUsersList.innerHTML = "";
            modalUsersList.appendChild(primaryBadge);
            selectedOptions.forEach((option) => {
              const badge = document.createElement("span");
              badge.classList.add(
                "badge",
                "biomed-bg-accent",
                "text-dark",
                "py-1",
                "m-1",
                "align-middle",
                "text-wrap"
              );
              badge.innerHTML = option.getAttribute("data-subtext")
                ? `${option.textContent} (${option.getAttribute(
                    "data-subtext"
                  )})`
                : option.textContent;
              modalUsersList.appendChild(badge);
            });
            document.getElementById("mainUsersList").innerHTML =
              modalUsersList.innerHTML;
          }
        );

        document.getElementById("mainUsersList").innerHTML =
          modalUsersList.innerHTML;
        // Refresh the selectpicker to update the options

        $(select).selectpicker("refresh");
      }, false);

      const userIds = response.UserHelpdesks.map((leadUser) => leadUser.UserId);
      const selectValues = userIds.map(String);
      $(select).selectpicker("val", selectValues);

      groupSelect.innerHTML = "";
      getGroups((err, groups) => {
        if (err) {
          console.error("Failed to fetch users:", err);
          return;
        }

        groups.forEach((group) => {
          const option = document.createElement("option");
          option.value = group.Id;
          option.textContent = group.GroupName;
          groupSelect.appendChild(option);
        });

        $(groupSelect).on(
          "changed.bs.select",
          function (e, clickedIndex, isSelected, previousValue) {
            const selectedOptions = Array.from(e.target.selectedOptions);
            selectedOptions.forEach((option) => {
              getGroupMembers(option.value, (err, users) => {
                if (err) {
                  console.error("Failed to fetch users:", err);
                  return;
                }

                valSelect = users.GroupUsers.map((user) => user.UserId)
                  .filter((item) => item !== response.mainUserId)
                  .map(String);
                $(select).selectpicker(
                  "val",
                  $(select).val().concat(valSelect)
                );
                console.log(valSelect);
              });
            });

            //document.getElementById("mainUsersList").innerHTML = modalUsersList.innerHTML;
          }
        );
        $(groupSelect).selectpicker("refresh");
      }, false);

      $(groupSelect).selectpicker("refresh");


      
      //Get contacts


      mainContactSelect.innerHTML = "";
      contactSelect.innerHTML = "";
      getContacts((err, contacts) => {
        if (err) {
          console.error("Failed to fetch users:", err);
          xalert("Failed to fetch users:" + err, 1, null);
          return;
        }
        
        contacts.forEach((contact) => {
          const option = document.createElement("option");
          option.value = contact.Id;
          option.textContent = contact.Name;
          if (contact.Position !== null && contact.Position !== undefined) {
            option.setAttribute("data-subtext", `${contact.Position}`);
          }
          contactSelect.appendChild(option);

          const mainOption = document.createElement("option");
          mainOption.value = contact.Id;
          mainOption.textContent = contact.Name;
          if (contact.Position !== null && contact.Position !== undefined) {
            mainOption.setAttribute("data-subtext", `${contact.Position}`);
          }
          mainContactSelect.appendChild(mainOption);
        });
        
        $(mainContactSelect).on(
            "changed.bs.select",
            modalContactsUpdate
        );


        $(contactSelect).on(
            "changed.bs.select",
            modalContactsUpdate
        );

        $(contactSelect).selectpicker("refresh");
        $(mainContactSelect).selectpicker("refresh");
        $(mainContactSelect).selectpicker("val", response.ContactId.toString());
        const contactIds = response.ContactHelpdesks.map(
            (contact) => contact.ContactId
        ).filter((id) => id !== response.MainUserId);
        const contactSelectValues = contactIds.map(String);
        $(contactSelect).selectpicker("val", contactSelectValues);
      }, false);
      $(contactSelect).selectpicker("refresh");
      $(mainContactSelect).selectpicker("refresh");
      cachingObject();
    } else {
      // Handle the error case
      xalert("Error:" + xhr.status, 1, null);
      console.error("Error:", xhr.status);
    }
  };

  // Send the XHR request
  xhr.send();
};

function contactsModal() {
    var contactsModal = new bootstrap.Modal("#multiContactModal", {
        focus: true
    });
    contactsModal.show();
    
}

function usersModal() {
  var multiSelectModal = new bootstrap.Modal("#multiSelectModal", {
    focus: true
  });
  multiSelectModal.show();
}
function updateLead(){
  let changedComponent = compareChange();
  let readableChanges = changedComponent.map(change => {
    let oldValue = Array.isArray(change.oldValue) ? change.oldValue.join(", ") : (change.oldValue || "N/A");
    let newValue = Array.isArray(change.newValue) ? change.newValue.join(", ") : (change.newValue || "N/A");
    return `${change.field}: ${oldValue} -> ${newValue}`;
  }).join("\n");

  console.log(readableChanges);
  createLog(readableChanges, JSON.stringify(changedComponent), null, null, null, parseInt(hdid), null, 4, function(err, log){
    if(err){
      console.error(err);
      return;
    }
    console.log('Log created successfully:', log);
    updateLeadRequest();
  });
}
function updateLeadRequest() {
  // Create a new XMLHttpRequest object
  


  var xhr = new XMLHttpRequest();
  if (document.querySelector('input[name="btnradio"]:checked') === null) {
    // The element is null, meaning no input with name "btnradio" is checked
    xalert("Error: No pipeline selected", 2, 5000);
    return;
  } 
  // Configure the POST request
  xhr.open("POST", url + "/biomedapi/helpdesk/ticket/update", true);

  // Set the request headers
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());

  var mainContacts = Array.from(mainContactSelect.selectedOptions)
  // Prepare the data from the HTML form
  var data = {
    Id: hdid,
    Title: document.getElementById("leadName").value,
    ContactId: parseInt(mainContacts[0].value),
    Description: document.getElementById("problem").value,
    Solution: document.getElementById("solution").value,
    Instumental: document.getElementById("instumental").value,
    Model: document.getElementById("model").value,
    SerialNumber: document.getElementById("serialNumber").value,
    JobType: jobType[parseInt(document.getElementById("jobType").value)].jobType,
    InstumentalStatus: instumentalStatus[parseInt(document.getElementById("instumentalStatus").value)].status,
    Priority: parseInt(document.getElementById("priority").noUiSlider.get()),
    ProductId: parseInt(document.getElementById("product").value),
    SaleAreaId: parseInt(document.getElementById("saleArea").value),
    AssignedToUserId: parseInt(document.getElementById("assignedUser").value),
    HelpDeskItems:[],

    PipelineId: document
      .querySelector('input[name="btnradio"]:checked')
      .id.replace("pipeline", ""),

    //UserIds: document.getElementById('userIds').value.split(',').map(Number)
  };
  data.UserIds = Array.from(
    document.getElementById("usersSelecter").selectedOptions
  ).map((option) => parseInt(option.value));
  data.ContactIds = Array.from(
      document.getElementById("contactsSelecter").selectedOptions
  ).filter(option => option.value !== mainContacts[0].value)
  .map(option => parseInt(option.value));
  data.ProductId = parseInt(document.getElementById("product").value);
  data.SaleAreaId = parseInt(document.getElementById("saleArea").value);

  // Set the onload function to handle the response
  xhr.onload = function () {
    if (xhr.status === 200) {
      // Handle the success case
      xalert("Ticket updated successfully", 0, null);
      console.log("Ticket updated successfully");
      setTimeout(() => {
        window.location.href = "helpdesk.html";
      }, 1000);
    } else {
      // Handle the error case
      xalert("Error:" + xhr.status + " " + xhr.responseText, 1, null);
      console.error("Error:", xhr.status);
    }
  };

  console.log(data);
  // Send the request with the JSON stringified data
  xhr.send(JSON.stringify(data));
}

function modalContactsUpdate() {
    const mainselectedOptions = Array.from(mainContactSelect.selectedOptions);
    modalContactsList.innerHTML = "";
    mainselectedOptions.forEach((option) => {
      const badge = document.createElement("span");
      badge.classList.add(
        "badge",
        "bg-info",
        "text-dark",
        "py-1",
        "m-1",
        "align-middle",
        "text-wrap"
      );
      badge.innerHTML = option.getAttribute("data-subtext")
        ? `${option.textContent} (${option.getAttribute(
            "data-subtext"
          )})`
        : option.textContent;
      modalContactsList.appendChild(badge);
    });
    const selectedOptions = Array.from(contactSelect.selectedOptions);
    
    selectedOptions.forEach((option) => {
      const badge = document.createElement("span");
      badge.classList.add(
        "badge",
        "biomed-bg-accent",
        "text-dark",
        "py-1",
        "m-1",
        "align-middle",
        "text-wrap"
      );
      badge.innerHTML = option.getAttribute("data-subtext")
        ? `${option.textContent} (${option.getAttribute(
            "data-subtext"
          )})`
        : option.textContent;
        if(mainselectedOptions[0].value !== option.value){
            modalContactsList.appendChild(badge);
        }
      
    });
}

function deleteLead(){
  // Create a new XMLHttpRequest object
  var xhr = new XMLHttpRequest();

  // Configure the DELETE request
  xhr.open("POST", url + "/biomedapi/helpdesk/ticket/delete", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  // Set the request headers
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());

  // Set the onload function to handle the response
  xhr.onload = function () {
    if (xhr.status === 200) {
      // Handle the success case
      xalert("Ticket deleted successfully", 0, null);
      console.log("Ticket deleted successfully");
      setTimeout(() => {
        window.location.href = "helpdesk.html";
      }, 1000);
    } else {
      // Handle the error case
      xalert("Error:" + xhr.status + " " + xhr.responseText, 1, null);
      console.error("Error:", xhr.status);
    }
  };

  
  // Send the DELETE request
  xhr.send(JSON.stringify({ Id: parseInt(hdid) }));
}