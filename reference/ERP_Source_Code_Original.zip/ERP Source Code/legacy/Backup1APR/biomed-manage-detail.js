const urlParams = new URLSearchParams(window.location.search);
const id = urlParams.get('id');
const modalPermissionsList = document.getElementById('modalPermissionsList');
const modalIndividualPermissionsList = document.getElementById('modalIndividualPermissionsList');
const select = document.getElementById('permissionsSelector');
const permissionUserSelectBox = document.getElementById('permissionUserSelectBox');
const individualSelectBox = document.getElementById('individualSelectBox');

const modalProductsList = document.getElementById('modalProductsList');
const modalSaleAreasList = document.getElementById('modalSaleAreasList');
const productUserSelectBox = document.getElementById('ProductsSelector');
const saleAreaUserSelectBox = document.getElementById('SaleAreasSelector');
const productsUsersList = document.getElementById('productsUsersList');
const saleAreasUsersList = document.getElementById('saleAreasUsersList');
function productsModal() {
    
        var productsSelect = new bootstrap.Modal("#productsModalSelector", {focus: true});
        productsSelect.show();
}
function saleAreasModal() {
        var saleAreasSelect = new bootstrap.Modal("#saleAreasModalSelector", {focus: true});
        saleAreasSelect.show();
}

function permissionsModal() {

    var multiSelectModal = new bootstrap.Modal("#multiSelectModal", {focus: true});
    multiSelectModal.show();
}
function individualPermissionsModal() {

    var individualPerms = new bootstrap.Modal("#individualPermissionsModal", {focus: true});
    individualPerms.show();
}


window.onload = function() {


    // Get the id from the URL

    if (!id) {
       xalert("No id please check your url",1,null);
        return;
    }
    // Make a GET request to fetch user details
    const xhr = new XMLHttpRequest();
    xhr.open('GET', url+`/biomedapi/users/${id}`);
    xhr.setRequestHeader('Authorization', `Bearer ${readToken()}`);
    xhr.onload = function() {
        if (xhr.status === 200) {
            const user = JSON.parse(xhr.responseText);

            // Update the form fields with user details
            document.getElementById('username').value = user.username;
            //document.getElementById('profile-pic').value = user.ProfilePic;
            document.getElementById('first-name').value = user.FirstName;
            document.getElementById('last-name').value = user.LastName;
            document.getElementById('middle-name').value = user.MiddleName;
            document.getElementById('position').value = user.Position;
            document.getElementById('email').value = user.Email;
            document.getElementById('sale-code').value = user.SaleCode;
            document.getElementById('phone-number').value = user.PhoneNumber;
            document.getElementById('sub-email').value = user.SubEmail;
            document.getElementById('sub-phone-number').value = user.SubPhoneNumber;
            document.getElementById('address').value = user.Address;
            document.getElementById('line-id').value = user.LineID;
            //document.getElementById('area-code').value = user.AreaCode;
            //document.getElementById('products').value = user.Products;
            const employedDate = user.EmployedDate
            const formattedEmployedDate = employedDate.split('T')[0];
            document.getElementById('employed-date').value = formattedEmployedDate;

            permissionsType.forEach(permission => {
                const option = document.createElement('option');
                option.value = permission.value;
                option.textContent = permission.name;
                option.setAttribute('data-subtext', permission.description);
                select.appendChild(option);
            });

            // Update the permissions select
            $(select).on('changed.bs.select', function (e, clickedIndex, isSelected, previousValue) {
            
                const selectedOptions = Array.from(e.target.selectedOptions);
                modalPermissionsList.innerHTML = '';
                selectedOptions.forEach(option => {
                    const badge = document.createElement('span');
                    badge.classList.add('badge', 'biomed-bg-accent', 'text-dark', 'py-1', 'm-1', 'align-middle', 'text-wrap');
                    badge.innerHTML = option.getAttribute('data-subtext') ? `${option.textContent} (${option.getAttribute('data-subtext')})` : option.textContent;
                    modalPermissionsList.appendChild(badge);
                    document.getElementById("permissionsUsersList").innerHTML = modalPermissionsList.innerHTML;
                });
            });
            $(select).selectpicker('refresh');
            document.getElementById("permissionsUsersList").innerHTML = modalPermissionsList.innerHTML;

            // Call the getUsers function to fetch the list of users
            getUsers(function(err, response) {
                if (err) {
                    console.error(err);
                   xalert("Error while fetching users", 1, null);
                    return;
                }
                
                // Get the select element for report-to
                const reportToSelect = document.getElementById('report-to');
                
                // Get the select element for coach
                const coachSelect = document.getElementById('coach');
                
                // Loop through the response and create options for report-to and coach
                response.forEach(user => {
                    // Create an option element for report-to
                    const reportToOption = document.createElement('option');
                    reportToOption.value = user.Id;
                    reportToOption.text = `${user.Id}:${user.FirstName} ${user.LastName}`;
                    reportToSelect.appendChild(reportToOption);
                    
                    // Create an option element for coach
                    const coachOption = document.createElement('option');
                    coachOption.value = user.Id;
                    coachOption.text = `${user.Id}:${user.FirstName} ${user.LastName}`;
                    coachSelect.appendChild(coachOption);

                    const individualPermissionOption = document.createElement('option');
                    individualPermissionOption.value = user.Id;
                    individualPermissionOption.text = `${user.Id}:${user.FirstName} ${user.LastName}`;
                    permissionUserSelectBox.appendChild(individualPermissionOption);
                });

                permissionsTypeIndividual.forEach(permission => {

                    const option = document.createElement('option');
                    option.value = permission.value;
                    option.textContent = permission.name;
                    option.setAttribute('data-subtext', permission.description);
                    individualSelectBox.appendChild(option);
                });

                if (user.ReportToID) {
                    reportToSelect.value = user.ReportToID;
                }

                if (user.CoachID) {
                    coachSelect.value = user.CoachID;
                }
            });
            console.log(user);

            
            var permsList = [];
            
           
            user.Permissions.forEach(permission => {
                if (permissionsType.some(p => p.name === permission.Type)) {
                    const p = permissionsType.find(p => p.name === permission.Type);
                    if(permission.Value === 'Allow'||permission.Value === 3){
                        permsList.push(p.value);
                    }
                    console.log(permission.Type);
                }
                else {
                    console.log(permission.Type+"-"+permission.PermissionKey);
                    const p = permissionsTypeIndividual.find(p => p.name === permission.Type);
                    if(permission.Value === 'Allow'||permission.Value === 3){
                        addIndividualPermission(permission.PermissionKey, p.value.toString());
                    }
                }

            });
            const selectValues = permsList.map(String);
            $(select).selectpicker('val', selectValues);
            $(select).selectpicker('refresh');
            initializeProducts(user);
            initializeSaleAreas(user);

        }
    };
    xhr.send();
};


function addIndividualPermission(userId = null, permissionType = null) {

    
    if(userId && permissionType){
        var userSelectElement = document.getElementById('permissionUserSelectBox');
        var selectedUserOption = Array.from(userSelectElement.options).find(option => option.value === userId);
        var selectedUser = selectedUserOption ? selectedUserOption.value : null;
        var selectedUserText = selectedUserOption ? selectedUserOption.text : null;

        var permissionSelectElement = document.getElementById('individualSelectBox');
        var selectedPermissionOption = Array.from(permissionSelectElement.options).find(option => option.value === permissionType);
        var selectedPermission = selectedPermissionOption ? selectedPermissionOption.value : null;
        var selectedPermissionText = selectedPermissionOption ? selectedPermissionOption.text : null;
    }else{

        var userSelectElement = document.getElementById('permissionUserSelectBox');
        var selectedUserOption = userSelectElement.options[userSelectElement.selectedIndex];
        var selectedUser = selectedUserOption.value;
        var selectedUserText = selectedUserOption.text;
    
        var permissionSelectElement = document.getElementById('individualSelectBox');
        var selectedPermissionOption = permissionSelectElement.options[permissionSelectElement.selectedIndex];
        var selectedPermission = selectedPermissionOption.value;
        var selectedPermissionText = selectedPermissionOption.text;
    }

    const existingPermissions = Array.from(modalIndividualPermissionsList.children);
    const isExisting = existingPermissions.some(permission => {
        const userId = permission.getAttribute('userid');
        const permissionType = permission.getAttribute('permissiontype');
        return userId === selectedUser && permissionType === selectedPermission;
    });

    if (isExisting) {
        return;
    }

    const badge = document.createElement('span');
    badge.classList.add('badge', 'biomed-bg-accent', 'text-dark', 'py-1', 'm-1', 'align-middle', 'text-wrap');
    badge.textContent = selectedUserText+"⚡"+selectedPermissionText;

    const deleteButton = document.createElement('i');
    deleteButton.classList.add('fi', 'fi-rr-cross', 'delete-button','mx-1');
    deleteButton.setAttribute('userid', selectedUser);
    deleteButton.setAttribute('permissiontype', selectedPermission);
    deleteButton.addEventListener('click', deleteIndividualPermission);
    deleteButton.style.color = 'red';

    const permissionElement = document.createElement('div');
    permissionElement.classList.add('permission-element');
    permissionElement.setAttribute('userid', selectedUser);
    permissionElement.setAttribute('permissiontype', selectedPermission);
    permissionElement.appendChild(badge);
    badge.appendChild(deleteButton);

    modalIndividualPermissionsList.appendChild(permissionElement);
}

function deleteIndividualPermission(event) {
    const permissionElement = event.target.closest('.permission-element');
    if (permissionElement) {
        permissionElement.remove();
    }
}

// Sync modalIndividualPermissionsList with individualPermissionsUsersList
function syncPermissionsList() {
    const individualPermissionsUsersList = document.getElementById('individualPermissionsUsersList');
    individualPermissionsUsersList.innerHTML = modalIndividualPermissionsList.innerHTML;
}

// Call the syncPermissionsList function whenever there is a change in modalIndividualPermissionsList
const observer = new MutationObserver(syncPermissionsList);
observer.observe(modalIndividualPermissionsList, { childList: true });




function sendUserData() {
    // Create a new XMLHttpRequest object
    
    if (!id) {
       xalert("No id please check your url",1,null);
        return;
    }
    let xhr = new XMLHttpRequest();


    // Get form fields
    let username = document.getElementById('username').value;

    let password = document.getElementById('password').value;
    let FirstName = document.getElementById('first-name').value;
    let LastName = document.getElementById('last-name').value;
    let MiddleName = document.getElementById('middle-name').value;
    let Position = document.getElementById('position').value;
    let Email = document.getElementById('email').value;
    let SaleCode = document.getElementById('sale-code').value;
    let PhoneNumber = document.getElementById('phone-number').value;
    let SubEmail = document.getElementById('sub-email').value;
    let SubPhoneNumber = document.getElementById('sub-phone-number').value;
    let Address = document.getElementById('address').value;
    let LineID = document.getElementById('line-id').value;
    //let AreaCode = document.getElementById('area-code').value;
    let reportToID = document.getElementById('report-to').value ? document.getElementById('report-to').value : null;
    let coachID = document.getElementById('coach').value ? document.getElementById('coach').value : null;
    //let Products = document.getElementById('products').value;
    let EmployedDate = timeFormater(document.getElementById('employed-date').value);
    
    let data = {
        Id: id,
        Username: username,
        Password: password === "" ? null : password,
        ProfilePic: null,
        FirstName: FirstName,
        LastName: LastName,
        MiddleName: MiddleName,
        Position: Position,
        Email: Email,
        SaleCode: "Obsoleted",
        PhoneNumber: PhoneNumber,
        SubEmail: SubEmail,
        SubPhoneNumber: SubPhoneNumber,
        Address: Address,
        LineID: LineID,
        AreaCode: "Obsoleted",
        ReportToID: reportToID,
        CoachID: coachID,
        Products: "Obsoleted",
        EmployedDate: EmployedDate
        // ... repeat for all other fields
    };

    // Add the permissions to the data object
    // Create a list of permission objects
    const permissions = [];

    // Get the selected options from the 'select' element
    const selectedOptions = Array.from(select.selectedOptions).map(option => parseInt(option.value));

    // Add the selected options to the permissions list
    selectedOptions.forEach(option => {
        permissions.push({
            Type: option,
            Value: 3
        });
    });

    // Get the permission elements from the 'modalIndividualPermissionsList' element
    const permissionElements = Array.from(modalIndividualPermissionsList.getElementsByClassName('permission-element'));

    // Add the permission elements to the permissions list
    permissionElements.forEach(element => {
        const permissionType = parseInt(element.getAttribute('permissiontype'));
        const permissionKey = element.getAttribute('userid');
        
        permissions.push({
            Type: permissionType,
            Value: 3,
            PermissionKey: permissionKey
        });
    });

    // Add the Products to the data object
    const selectedProducts = Array.from(productUserSelectBox.selectedOptions).map(option => parseInt(option.value));

    data.ProductIDs = selectedProducts;

    // Add the SaleAreas to the data object
    const selectedSaleAreas = Array.from(saleAreaUserSelectBox.selectedOptions).map(option => parseInt(option.value));

    data.SaleAreaIDs = selectedSaleAreas;
    // Add the permissions to the data object
    data.Permissions = permissions;
    console.log(data);

    // Convert data to JSON
    let jsonData = JSON.stringify(data);

    // Specify the type of request and the URL
    xhr.open('POST', url+ '/biomedapi/users/update'); // replace 'api_endpoint' with the actual API endpoint

    // Set request headers
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', 'Bearer ' + readToken());

    // Send the request
    xhr.send(jsonData);

    // Function to run when the state changes
    xhr.onreadystatechange = function () {

        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log(username + ' updated successfully');
           xalert("User updated successfully", 0, -1);
        }
        else if (xhr.readyState === 4 && xhr.status !== 200){
            console.error('Error while updating user '+xhr.status+'-'+ xhr.responseText);
           xalert("Error while updating user "+xhr.status+"-"+ xhr.responseText, 1, null);
        }
    };
}


function resizeImage(image, maxWidth, maxHeight) {
    var canvas = document.createElement('canvas');
    var ctx = canvas.getContext('2d');

    var width = image.width;
    var height = image.height;

    if (width < height) {
        if (width > maxWidth) {
            height *= maxWidth / width;
            width = maxWidth;
        }
    } else {
        if (height > maxHeight) {
            width *= maxHeight / height;
            height = maxHeight;
        }
    }

    canvas.width = width;
    canvas.height = height;
    
    ctx.fillStyle = 'white'; // Set background color to white
    ctx.fillRect(0, 0, canvas.width, canvas.height); // Fill the canvas with white color


    ctx.drawImage(image, 0, 0, width, height); // Fix coordinates to start from (0, 0)

    return canvas.toDataURL('image/jpeg');
}

function cropImage(imageDataUrl, size) {
    return new Promise((resolve, reject) => {
        var image = new Image();
        var canvas = document.createElement('canvas');
        var ctx = canvas.getContext('2d');

        canvas.width = size;
        canvas.height = size;

        image.onload = function() {
            var width = image.width;
            var height = image.height;

            var x = (width - size) / 2;
            var y = (height - size) / 2;

            ctx.drawImage(image, x, y, size, size, 0, 0, size, size);
            resolve(canvas.toDataURL('image/jpeg'));
        };

        image.onerror = reject; // Handle image load errors
        image.src = imageDataUrl;
    });
}

function processImage(file) {
    var reader = new FileReader();
    reader.onload = function(event) {
        var image = new Image();
        image.onload = async function() {
            var resizedImageDataUrl = resizeImage(image, 300, 300);
            try {
                var croppedImageDataUrl = await cropImage(resizedImageDataUrl, 300);
                var formData = new FormData();
                formData.append('file', dataURItoBlob(croppedImageDataUrl));
                var xhr = new XMLHttpRequest();
                xhr.open('POST', url + '/biomedapi/upload/profile/'+id, true);
                xhr.setRequestHeader('Authorization', 'Bearer ' + readToken());
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4) {
                        if (xhr.status === 200) {
                            xalert('Profile picture uploaded successfully', 0, 5000);
                            myUserRequest(function(err, response) {
                                if (err) {
                                    console.log(err);
                                    xalert("Error while fetching user", 1, null);
                                }
                            }, true);
                            setTimeout(function() {
                                location.reload();
                            }, 2000);
                        } else {
                            xalert(xhr.status + '-' + xhr.responseText, 1, -1);
                        }
                    }
                };
                xhr.send(formData);
            } catch (error) {
                console.error("Error cropping image:", error);
            }
        };
        image.src = event.target.result;
    };
    reader.readAsDataURL(file);
}

function dataURItoBlob(dataURI) {
    var byteString = atob(dataURI.split(',')[1]);
    var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
    var ab = new ArrayBuffer(byteString.length);
    var ia = new Uint8Array(ab);
    for (var i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([ab], { type: mimeString });
}

function uploadProfilePic() {
    var input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = function(event) {
        var file = event.target.files[0];
        processImage(file);
    };
    input.click();

    // Read in file
}


const projectObserver = new MutationObserver(syncProductsList);
projectObserver.observe(modalProductsList, { childList: true });
function syncProductsList() {
    const productsUsersList = document.getElementById('productsUsersList');
    productsUsersList.innerHTML = modalProductsList.innerHTML;
}

function initializeProducts(user){
    // Call the getProducts function to fetch the list of products
    getProducts(function(err, response) {
        if (err) {
            console.error(err);
            xalert("Error while fetching products", 1, null);
            return;
        }
        console.log("Products",response);

        // Loop through the product response and add each product as an option
        response.forEach(product => {
            const option = document.createElement('option');
            option.value = product.Id;
            option.textContent = product.Name;
            option.setAttribute('data-subtext', product.Description);
            productUserSelectBox.appendChild(option);
        });

        $(productUserSelectBox).on('changed.bs.select', function (e, clickedIndex, isSelected, previousValue) {
            
            const selectedOptions = Array.from(e.target.selectedOptions);
            modalProductsList.innerHTML = '';
            selectedOptions.forEach(option => {
                const badge = document.createElement('span');
                badge.classList.add('badge', 'biomed-bg-accent', 'text-dark', 'py-1', 'm-1', 'align-middle', 'text-wrap');
                badge.innerHTML = option.getAttribute('data-subtext') ? `${option.textContent} (${option.getAttribute('data-subtext')})` : option.textContent;
                modalProductsList.appendChild(badge);
                //document.getElementById("productsUsersList").innerHTML = modalProductsList.innerHTML;
            });
        });
        $(productUserSelectBox).selectpicker('refresh');
        var userProducts = [];
            
        if (user.ProductUsers) {
            user.ProductUsers.forEach(productId => {
            userProducts.push(productId.ProductId);

        });
        }   

        const selectValues = userProducts.map(String);
        $(productUserSelectBox).selectpicker('val', selectValues);

    });
}



const saleAreaObserver = new MutationObserver(syncSaleAreasList);
saleAreaObserver.observe(modalSaleAreasList, { childList: true });
function syncSaleAreasList() {
    const saleAreasUsersList = document.getElementById('saleAreasUsersList');
    saleAreasUsersList.innerHTML = modalSaleAreasList.innerHTML;
}

function initializeSaleAreas(user){
    // Call the getSaleAreas function to fetch the list of sale areas
    getSaleAreas(function(err, response) {
        if (err) {
            console.error(err);
            xalert("Error while fetching sale areas", 1, null);
            return;
        }
        console.log("Sale Areas",response);

        // Loop through the sale area response and add each sale area as an option
        response.forEach(saleArea => {
            const option = document.createElement('option');
            option.value = saleArea.Id;
            option.textContent = saleArea.Name;
            option.setAttribute('data-subtext', saleArea.Description);
            saleAreaUserSelectBox.appendChild(option);
        });

        $(saleAreaUserSelectBox).on('changed.bs.select', function (e, clickedIndex, isSelected, previousValue) {
            
            const selectedOptions = Array.from(e.target.selectedOptions);
            modalSaleAreasList.innerHTML = '';
            selectedOptions.forEach(option => {
                const badge = document.createElement('span');
                badge.classList.add('badge', 'biomed-bg-accent', 'text-dark', 'py-1', 'm-1', 'align-middle', 'text-wrap');
                badge.innerHTML = option.getAttribute('data-subtext') ? `${option.textContent} (${option.getAttribute('data-subtext')})` : option.textContent;
                modalSaleAreasList.appendChild(badge);
                //document.getElementById("saleAreasUsersList").innerHTML = modalSaleAreasList.innerHTML;
            });
        });
        $(saleAreaUserSelectBox).selectpicker('refresh');
        var userSaleAreas = [];
            
           
        user.SaleAreaUsers.forEach(saleAreaId => {
            userSaleAreas.push(saleAreaId.SaleAreaId);

        });
        const selectValues = userSaleAreas.map(String);
        $(saleAreaUserSelectBox).selectpicker('val', selectValues);

    });
}