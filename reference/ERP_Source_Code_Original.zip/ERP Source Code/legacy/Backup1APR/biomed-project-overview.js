var pipelineCache = [];
var pipelineIdCache = null;
var projectCache = null;

function editpipeline(pipelineId) {
    createModalPopup(pipelineId);
}

function deletepipeline(pipelineId) {

    createModalPopup(pipelineId,true);

}

function getUniqueLeads(leads) {
    const uniqueLeads = leads.reduce((acc, lead) => {
        if (!acc.some(existingLead => existingLead.Id === lead.Id)) {
            acc.push(lead);
        }
        return acc;
    }, []);
    return uniqueLeads;
}



function createModalPopup(pipelineId = null, deletePipeline = false) {
    // Create the modal element
    pipelineIdCache = pipelineId;
    const modal = document.createElement('div');
    modal.id = 'pipelineModal';
    
    modal.classList.add('modal', 'fade');
    modal.setAttribute('tabindex', '-1');
    modal.setAttribute('role', 'dialog');

    // Create the modal dialog element
    const modalDialog = document.createElement('div');
    modalDialog.classList.add('modal-dialog');
    modal.appendChild(modalDialog);

    // Create the modal content element
    const modalContent = document.createElement('div');
    modalContent.classList.add('modal-content');
    modalDialog.appendChild(modalContent);

    // Create the modal header element
    const modalHeader = document.createElement('div');
    modalHeader.classList.add('modal-header');
    modalContent.appendChild(modalHeader);

    // Create the modal title element
    const modalTitle = document.createElement('h5');
    modalTitle.classList.add('modal-title');
    modalTitle.textContent = 'Add Pipeline';
    if (pipelineId) {
        modalTitle.textContent = 'Edit Pipeline';
    }
    if (deletePipeline) {
        modalTitle.textContent = 'Are you sure you want to delete this pipeline? Please ensure that you move or delete all activities in this pipeline before proceeding.';
    }
    modalHeader.appendChild(modalTitle);

    // Create the close button element
    const closeButton = document.createElement('button');
    closeButton.setAttribute('type', 'button');
    closeButton.classList.add('btn-close');
    closeButton.setAttribute('data-bs-dismiss', 'modal');
    closeButton.setAttribute('aria-label', 'Close');
    closeButton.addEventListener('click', removeModalPopup );
    modalHeader.appendChild(closeButton);

    // Create the modal body element
    const modalBody = document.createElement('div');
    modalBody.classList.add('modal-body');
    modalContent.appendChild(modalBody);

    // Create the text input element
    const inputGroup = document.createElement('div');
    inputGroup.classList.add('input-group', 'input-group-sm', 'mb-3');
    modalBody.appendChild(inputGroup);

    const inputGroupText = document.createElement('span');
    inputGroupText.classList.add('input-group-text');
    inputGroupText.style.width = '60px';
    inputGroupText.textContent = 'Title';
    inputGroup.appendChild(inputGroupText);

    const input = document.createElement('input');
    input.setAttribute('type', 'text');
    input.classList.add('form-control');
    input.setAttribute('aria-label', 'Sizing example input');
    input.setAttribute('aria-describedby', 'inputGroup-sizing-sm');
    input.id = 'pipelineTitle';
    if (pipelineId) {
        const pipeline = pipelineCache.find(pipeline => pipeline.Id === pipelineId);
        input.value = pipeline.PipelineName;
        //input2.value = pipeline.Order;
    }
    if (deletePipeline) {
        input.readOnly = true;
    }
    inputGroup.appendChild(input);

    // Create the input group element
    const inputGroup2 = document.createElement('div');
    inputGroup2.classList.add('input-group', 'input-group-sm', 'mb-3');
    modalBody.appendChild(inputGroup2);

    // Create the input group text element
    const inputGroupText2 = document.createElement('span');
    inputGroupText2.classList.add('input-group-text');
    inputGroupText2.style.width = '60px';
    inputGroupText2.textContent = 'Order';
    inputGroup2.appendChild(inputGroupText2);

    // Create the input element
    const input2 = document.createElement('input');
    input2.setAttribute('type', 'number');
    input2.classList.add('form-control');
    input2.setAttribute('aria-label', 'Sizing example input');
    input2.setAttribute('aria-describedby', 'inputGroup-sizing-sm');
    input2.value = 0;
    if (pipelineId) {
        const pipeline = pipelineCache.find(pipeline => pipeline.Id === pipelineId);
        //input.value = pipeline.PipelineName;
        input2.value = pipeline.Order;
    }
    if (deletePipeline) {
        input2.readOnly = true;
    }
    input2.id = 'pipelineOrder';
    inputGroup2.appendChild(input2);

    // Create the button element
    const addButton = document.createElement('button');
    addButton.textContent = 'Add';
    if (pipelineId) {
        addButton.textContent = 'Update';
    }
    if (deletePipeline) {
        addButton.textContent = 'Delete';
        addButton.setAttribute('data-bs-dismiss', 'modal');
        addButton.setAttribute('aria-label', 'Close');
        addButton.classList.add('btn', 'btn-danger');
        addButton.addEventListener('click', function() {
            deletePipelineRequest(pipelineId);
            removeModalPopup();
        });
    }else{
        addButton.classList.add('btn', 'btn-primary');
        addButton.setAttribute('data-bs-dismiss', 'modal');
        addButton.setAttribute('aria-label', 'Close');
        addButton.addEventListener('click', createCRMPipeline);
    }
    modalBody.appendChild(addButton);

    // Append the modal to the document body

    document.body.appendChild(modal);
    var crmModal = new bootstrap.Modal("#pipelineModal", {focus: true});

    /*var wtfisthis = bootstrap.Modal.getInstance(document.getElementById('pipelineModal'));
    wtfisthis.addEventListener('hidden.bs.modal', function (event) {

        wtfisthis.dispose();
    });*/

    

    crmModal.show();
}

function createCRMPipeline(){
    createPipelineRequest(pipelineIdCache);
    removeModalPopup();
}

function deletePipelineRequest(pipelineId) {
    const token = readToken();
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url + '/biomedapi/projects/pipelines/delete', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Request successful
                xalert('Pipeline deleted successfully', 0, -1);
                setTimeout(function() {
                    location.reload();
                }, 1000);
            } else {
                // Request failed
                xalert('Error ' + xhr.status + " " + xhr.responseText, 1, -1);
            }
        }
    };
    const data = JSON.stringify({Id: pipelineId});
    xhr.send(data);

}

function createPipelineRequest(pipelineId = null) {
    const token = readToken();
    const name = document.getElementById('pipelineTitle').value;
    const order = parseInt(document.getElementById('pipelineOrder').value);


    const xhr = new XMLHttpRequest();
    if (pipelineId) {
        xhr.open('POST', url+ '/biomedapi/projects/pipelines/update', true);
    } else {
        xhr.open('POST', url+ '/biomedapi/projects/pipelines/create', true);
    }
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Request successful
                xalert('Pipeline created/updated successfully',0,-1);
                setTimeout(function() {
                    location.reload();
                }, 1000);
                
            } else {
                // Request failed
                xalert('Error '+xhr.status+" "+xhr.responseText,1,-1);
                
            }
        }
    };
    let rawdata = {
        ProjectId: parseInt(projectId),
        Name: name,
        Description:"Just a Placeholder",
        Order: order
    };
    if (pipelineId) {
        rawdata.Id = pipelineId;
    }   
    
    const data = JSON.stringify(rawdata);
    xhr.send(data);
}


function removeModalPopup() {
    document.getElementById('pipelineModal').remove();
    pipelineIdCache = null;
}
const urlParams = new URLSearchParams(window.location.search);
const projectId = urlParams.get('projectId');

function displayLeads(query = null) {
    
    if( projectId == null || projectId == undefined ){
        xalert('Error: Missing Project ID Please check URL', 1, -1);
    };
    const pipelineContainer = document.getElementById('pipelineContainer');
    pipelineContainer.innerHTML = '';
    clearCache();
    getProjectById(projectId,function(error, project) {
        if (error) {
            xalert('Error ' + error, 1, -1);
            // Handle the error here
        } else {
            document.getElementById('projectName').textContent = project.Name;
            projectCache= project;
            pipelines = project.Pipelines;
            console.log(project);
            pipelines.sort((a, b) => a.Order - b.Order);

            pipelineCache = pipelines;
            //Create Null Pipeline
            const nullpipelineElement = document.createElement('div');
                nullpipelineElement.classList.add('col', 'm-0', 'p-0', 'px-1', 'py-2', 'd-none');
                nullpipelineElement.style.minWidth = '256px';
                nullpipelineElement.id = 'nullPipelineParent';
                nullpipelineElement.innerHTML = `
                <div class="m-0 p-0 row" id="nullPipeline">
                
                    <h6 class="col-11 p-0 m-0 mb-1 py-auto fw-bold auto-fit py-1">Unassigned</h6>
                    
                </div>

                    
                `;
                pipelineContainer.appendChild(nullpipelineElement);


            pipelines.forEach(pipeline => {
                const pipelineElement = document.createElement('div');
                pipelineElement.classList.add('col', 'm-0', 'p-0', 'px-1', 'py-2');
                pipelineElement.style.minWidth = '280px';
                pipelineElement.style.maxWidth = '350px';
                pipeline.PipelineName = pipeline.Name;
                pipelineElement.innerHTML = `
                <div class="m-0 p-0 row" id="${pipeline.Id}">
                
                    <h6 class="p-0 m-0 py-auto fw-bold auto-fit py-1">${pipeline.PipelineName}</h6>
                    
                    <div class="btn-group m-0 p-0 d-grid justify-content-sm-end ms-auto col-3 dropstart mb-1">
                            <button class="btn btn-secondary btn-sm rounded m-0 p-0 ms-auto auto-fit" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fi fi-rr-menu-dots-vertical"></i>
                            </button>
                            <ul class="dropdown-menu">
                                <li><h6 class="dropdown-header">Quick Action</h6></li>
                                <li><a class="dropdown-item" onclick="editpipeline(${pipeline.Id})">Edit Pipeline</a></li>
                                <li><a class="dropdown-item text-danger" onclick="deletepipeline(${pipeline.Id})">Delete Pipeline</a></li>
                            </ul>
                    </div>
                    <div class="m-0 p-1 d-flex flex-nowrap justify-content-evenly"> 
                        <span class="badge rounded-pill bg-danger mt-1"><i class="fi fi-rr-ban"></i> Dropped:<p class="m-0 p-0 d-inline" id="abandon${pipeline.Id}">0</p></span>
                        <span class="badge rounded-pill bg-warning mt-1"><i class="fi fi-rr-triangle-warning"></i> Inactive:<p class="m-0 p-0 d-inline" id="warn${pipeline.Id}">0</p></span>
                        <span class="badge rounded-pill bg-success mt-1"><i class="fi fi-rr-signal-bars-good"></i> Active:<p class="m-0 p-0 d-inline" id="ok${pipeline.Id}">0</p></span>
                    </div>
                </div>

                    
                `;
                pipelineContainer.appendChild(pipelineElement);

                let leadsContainer = pipelineElement;
                
                getUniqueLeads(pipeline.Activities).forEach(lead => {
                    
                    const leadElement = document.createElement('div');
                    leadElement.classList.add('p-0');
                    console.log(lead);

                    getUserById(async function(error, user){
                        if (error) {
                            xalert('Error ' + error , 1, -1);
                            // Handle the error here
                        }
                        if (user == null || user == undefined) {
                            xalert('Error ' + error , 1, -1);
                            // Handle the error here
                        }
                        var mainuser = user;
                        var color = await getColor(user.Id);
                        console.log(color);
                        var leadLink = './project-activity.html?activityid='+lead.Id;
                    console.log(mainuser);
                    const thirtyDaysAgo = new Date();
                    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

                    const threeMonths = new Date();
                    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 90);
                    var badge = "";
                    if(!(lead.CRMPipelineId == null || lead.CRMPipelineId == undefined)){
                        
                        if (lead.LastUpdated < thirtyDaysAgo) {
                            document.getElementById('warn'+lead.CRMPipelineId).textContent = parseInt(document.getElementById('warn'+lead.CRMPipelineId).textContent) + 1;
                            badge =  `<span class="badge rounded-pill bg-warning d-inline p-1 px-2 me-1"><i class="fi fi-rr-triangle-warning"></i></span>`;
                        }else
                        if (lead.LastUpdated < threeMonths) {
                            document.getElementById('abandon'+lead.CRMPipelineId).textContent = parseInt(document.getElementById('abandon '+lead.CRMPipelineId).textContent) + 1;
                            
                            badge =  `<span class="badge rounded-pill bg-danger d-inline p-1 px-2 me-1"><i class="fi fi-rr-ban"></i></span>`;
                        }
                        else{
                            document.getElementById('ok'+lead.CRMPipelineId).textContent = parseInt(document.getElementById('ok'+lead.CRMPipelineId).textContent) + 1;
                            badge =  `<span class="badge rounded-pill bg-success d-inline p-1 px-2 me-1"><i class="fi fi-rr-signal-bars-good"></i></span>`;
                        }
                    }
                    
                    leadElement.innerHTML = `
                        <div class="m-0 p-2 my-0 border bg-white"><!-- Single Lead-->
                            <div class="m-0 p-0 row"> 
                                <p class="m-0 p-0 py-0 fw-bold auto-fit col-9">${badge}${ lead.Name}</p>
                                
                                <div class="btn-group m-0 p-0 d-grid justify-content-sm-end ms-auto col-3 dropstart">
                                    <button class="btn btn-secondary btn-sm rounded m-0 p-0 ms-auto auto-fit" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fi fi-rr-menu-dots-vertical"></i>
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li><h6 class="dropdown-header">Quick Action</h6></li>
                                        <li><a class="dropdown-item d-none" href="#" onclick="openModal()">Create event from this lead</a></li>
                                        <li><a class="dropdown-item" href="${leadLink}">Edit this lead</a></li>
                                        <li><hr class="dropdown-divider d-none"></li>
                                        <li><h6 class="dropdown-header d-none ">Change Status to...</h6></li>
                                        <li><a class="dropdown-item d-none" href="#">Sales Plan</a></li>
                                        <li><a class="dropdown-item d-none" href="#">Initiate</a></li>
                                        <li><a class="dropdown-item d-none" href="#">Following Up</a></li>
                                        <li><a class="dropdown-item d-none" href="#">Qualified</a></li>
                                        <li><a class="dropdown-item d-none" href="#">Confirmed Order</a></li>
                                        <li><a class="dropdown-item d-none" href="#">Proposition</a></li>
                                        <li><a class="dropdown-item d-none" href="#">PO Issued</a></li>
                                        <li><hr class="dropdown-divider d-none"></li>
                                        <li><a class="dropdown-item text-danger d-none" href="#" >Delete this lead</a></li>
                                    </ul>
                                </div>

                            </div>
                            <p class="m-0 py-1 fw-normal">${lead.Description}</p>
                            <p class="m-0 py-1 fw-normal">Created: ${timeFriendly(lead.Creation)}</p>
                            <p class="m-0 py-1 fw-normal"><span class="badge py-1 m-1 align-middle text-wrap" style="background-color: ${color.color.code}; color: ${color.textColor};">${mainuser.FirstName+" "+mainuser.LastName+"("+mainuser.Position+")"}</span></p>
                            <p class="m-0 py-0 d-none"><i class="fi fi-rr-circle-star text-warning"></i><i class="fi fi-rr-circle-star text-warning"></i><i class="fi fi-rr-circle-star text-secondary"></i></p>
                        </div>
                    `;
                    
                    

                    if(leadsContainer == null || leadsContainer == undefined){
                        leadsContainer = document.getElementById('nullPipeline');
                        document.getElementById('nullPipelineParent').classList.remove('d-none');
                    }
                    leadsContainer.appendChild(leadElement);


                        
                    },lead.MainUserId);
                    
                    



                });
            });


        }
        
        /*getLeads(function(error, leads) { //Will change to get Activities
            if (error) {
                xalert('Error ' + error , 1, -1);
                // Handle the error here
            } else {

                
                getUniqueLeads(leads).forEach(lead => {
                    
                    let leadsContainer = document.getElementById(lead.CRMPipelineId);
                    const leadElement = document.createElement('div');
                    leadElement.classList.add('p-0');
                    console.log(lead);
                    var MainContact = null;
                    if (lead.MainCustomerId != null && lead.MainCustomerId != undefined) {
                        getContactById(lead.MainCustomerId,function(error, contact) {
                            if (error) {
                                xalert('Error ' + error, 1, -1);
                                // Handle the error here
                            } else {
                                MainContact = contact;
                                if (MainContact.Name == null || MainContact.Name == undefined) {
                                    MainContact = {Name: "", Position: "-"};
                                }
                                if (MainContact.Position == null || MainContact.Position == undefined) {
                                    MainContact = { Name:MainContact.Name, Position: "-"};
                                }
                                getUserById(async function(error, user){
                                    if (error) {
                                        xalert('Error ' + error , 1, -1);
                                        // Handle the error here
                                    }
                                    if (user == null || user == undefined) {
                                        xalert('Error ' + error , 1, -1);
                                        // Handle the error here
                                    }
                                    var mainuser = user;
                                    var color = await getColor(user.Id);
                                    console.log(color);
                                    var leadLink = 'crm-detail.html?leadid='+lead.Id;
                                console.log(mainuser);
                                const thirtyDaysAgo = new Date();
                                thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

                                const threeMonths = new Date();
                                thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 90);
                                var badge = "";
                                if(!(lead.CRMPipelineId == null || lead.CRMPipelineId == undefined)){
                                    
                                    if (lead.LastUpdated < thirtyDaysAgo) {
                                        document.getElementById('warn'+lead.CRMPipelineId).textContent = parseInt(document.getElementById('warn'+lead.CRMPipelineId).textContent) + 1;
                                        badge =  `<span class="badge rounded-pill bg-warning d-inline p-1 px-2 me-1"><i class="fi fi-rr-triangle-warning"></i></span>`;
                                    }else
                                    if (lead.LastUpdated < threeMonths) {
                                        document.getElementById('abandon'+lead.CRMPipelineId).textContent = parseInt(document.getElementById('abandon '+lead.CRMPipelineId).textContent) + 1;
                                        
                                        badge =  `<span class="badge rounded-pill bg-danger d-inline p-1 px-2 me-1"><i class="fi fi-rr-ban"></i></span>`;
                                    }
                                    else{
                                        document.getElementById('ok'+lead.CRMPipelineId).textContent = parseInt(document.getElementById('ok'+lead.CRMPipelineId).textContent) + 1;
                                        badge =  `<span class="badge rounded-pill bg-success d-inline p-1 px-2 me-1"><i class="fi fi-rr-signal-bars-good"></i></span>`;
                                    }
                                }
                                document.getElementById('tAchieved').textContent = parseInt(document.getElementById('tAchieved').textContent) + parseInt(lead.AchivedRevenue);

                                document.getElementById('tExpected').textContent = parseInt(document.getElementById('tExpected').textContent) + parseInt(lead.ExpectedRevenue);
                                document.getElementById('AERatio').style.width = (parseInt(document.getElementById('tAchieved').textContent) / parseInt(document.getElementById('tExpected').textContent) * 100) + "%";
                                document.getElementById('AERatio').textContent = Math.round((parseInt(document.getElementById('tAchieved').textContent) / parseInt(document.getElementById('tExpected').textContent) * 100)) + "%";

                                leadElement.innerHTML = `
                                    <div class="m-0 p-2 my-0 border bg-white"><!-- Single Lead-->
                                        <div class="m-0 p-0 row"> 
                                            <p class="m-0 p-0 py-0 fw-bold auto-fit col-9">${badge}${ lead.LeadName}</p>
                                            
                                            <div class="btn-group m-0 p-0 d-grid justify-content-sm-end ms-auto col-3 dropstart">
                                                <button class="btn btn-secondary btn-sm rounded m-0 p-0 ms-auto auto-fit" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="fi fi-rr-menu-dots-vertical"></i>
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><h6 class="dropdown-header">Quick Action</h6></li>
                                                    <li><a class="dropdown-item d-none" href="#" onclick="openModal()">Create event from this lead</a></li>
                                                    <li><a class="dropdown-item" href="${leadLink}">Edit this lead</a></li>
                                                    <li><hr class="dropdown-divider d-none"></li>
                                                    <li><h6 class="dropdown-header d-none ">Change Status to...</h6></li>
                                                    <li><a class="dropdown-item d-none" href="#">Sales Plan</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Initiate</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Following Up</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Qualified</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Confirmed Order</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Proposition</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">PO Issued</a></li>
                                                    <li><hr class="dropdown-divider d-none"></li>
                                                    <li><a class="dropdown-item text-danger d-none" href="#" >Delete this lead</a></li>
                                                </ul>
                                            </div>
            
                                        </div>
                                        <p class="m-0 py-1 fw-normal">Expect: ${lead.ExpectedRevenue} THB</p>
                                        <p class="m-0 py-1 fw-normal">Achived: ${lead.AchivedRevenue} THB</p>
                                        <p class="m-0 py-1 fw-normal">${"Main Customer:" +" "+MainContact.Name+"("+MainContact.Position+")"}</p>
                                        <p class="m-0 py-1 fw-normal">Due Date: ${timeFriendly(lead.Expected)}</p>
                                        <p class="m-0 py-1 fw-normal"><span class="badge py-1 m-1 align-middle text-wrap" style="background-color: ${color.color.code}; color: ${color.textColor};">${mainuser.FirstName+" "+mainuser.LastName+"("+mainuser.Position+")"}</span></p>
                                        <p class="m-0 py-0 d-none"><i class="fi fi-rr-circle-star text-warning"></i><i class="fi fi-rr-circle-star text-warning"></i><i class="fi fi-rr-circle-star text-secondary"></i></p>
                                    </div>
                                `;
                                
                                

                                if(leadsContainer == null || leadsContainer == undefined){
                                    leadsContainer = document.getElementById('nullPipeline');
                                    document.getElementById('nullPipelineParent').classList.remove('d-none');
                                }
                                leadsContainer.appendChild(leadElement);
            
            
                                   
                                },lead.MainUserId);

                            }
                        });
                    }else{
                        MainContact = {Name: " ", Position: "-"};
                        xalert('Error Missing MainContact for Lead:'+lead.Id, 1, -1);
                    }
                    
    
                });
            }
            
        },query);*/
    
    
    
    },true);



}


const usersQuerySelecter = document.getElementById('usersQuerySelecter');
const contactsQuerySelecter = document.getElementById('contactsQuerySelecter');
window.onload = function() {

    /* For Filter
    getUsers(function(error, users) {
        if (error) {
            xalert('Error ' + error, 1, -1);
            // Handle the error here
        } else {
            
            users.forEach(user => {

                var userElement = document.createElement('option');
                userElement.value = user.Id;
                userElement.textContent = user.FirstName + " " + user.LastName;
                if (user.Position !== null && user.Position !== undefined) {
                    userElement.setAttribute("data-subtext", `${user.Position}`);
                  }
                usersQuerySelecter.appendChild(userElement);
                $(usersQuerySelecter).selectpicker('refresh');
            });
        }
    },false );

    getContacts(function(error, contacts) {

        if (error) {
            xalert('Error ' + error, 1, -1);
            // Handle the error here
        } else {
            
            contacts.forEach(contact => {

                var contactElement = document.createElement('option');
                contactElement.value = contact.Id;
                contactElement.textContent = contact.Name;
                if (contact.Position !== null && contact.Position !== undefined) {
                    contactElement.setAttribute("data-subtext", `${contact.Position}`);
                  }
                  contactsQuerySelecter.appendChild(contactElement);
                $(contactsQuerySelecter).selectpicker('refresh');
            });
        }
    },false);*/

    if(urlParams.has('projectId')){
        displayLeads();
    }
    else{
        xalert('Error: Missing Project ID Please check URL', 1, -1);
    }



};



function createLeadPopup() {
    // Create the modal element
    const modal = document.createElement('div');
    modal.id = 'leadModal';
    
    modal.classList.add('modal', 'fade');
    modal.setAttribute('tabindex', '-1');
    modal.setAttribute('role', 'dialog');

    // Create the modal dialog element
    const modalDialog = document.createElement('div');
    modalDialog.classList.add('modal-dialog');
    modal.appendChild(modalDialog);

    // Create the modal content element
    const modalContent = document.createElement('div');
    modalContent.classList.add('modal-content');
    modalDialog.appendChild(modalContent);

    // Create the modal header element
    const modalHeader = document.createElement('div');
    modalHeader.classList.add('modal-header');
    modalContent.appendChild(modalHeader);

    // Create the modal title element
    const modalTitle = document.createElement('h5');
    modalTitle.classList.add('modal-title');
    modalTitle.textContent = 'Create Lead';
    modalHeader.appendChild(modalTitle);

    // Create the close button element
    const closeButton = document.createElement('button');
    closeButton.setAttribute('type', 'button');
    closeButton.classList.add('btn-close');
    closeButton.setAttribute('data-bs-dismiss', 'modal');
    closeButton.setAttribute('aria-label', 'Close');
    closeButton.addEventListener('click', removeLeadPopup );
    modalHeader.appendChild(closeButton);

    // Create the modal body element
    const modalBody = document.createElement('div');
    modalBody.classList.add('modal-body');
    modalContent.appendChild(modalBody);

    // Create the text input element for LeadName
    const leadNameInputGroup = document.createElement('div');
    leadNameInputGroup.classList.add('input-group', 'input-group-sm', 'mb-3');
    modalBody.appendChild(leadNameInputGroup);

    const leadNameInputGroupText = document.createElement('span');
    leadNameInputGroupText.classList.add('input-group-text');
    leadNameInputGroupText.style.width = '100px';
    leadNameInputGroupText.style.minWidth = 'fit-content';
    leadNameInputGroupText.textContent = 'Activity Name';
    leadNameInputGroup.appendChild(leadNameInputGroupText);

    const leadNameInput = document.createElement('input');
    leadNameInput.setAttribute('type', 'text');
    leadNameInput.classList.add('form-control');
    leadNameInput.setAttribute('aria-label', 'Sizing example input');
    leadNameInput.setAttribute('aria-describedby', 'inputGroup-sizing-sm');
    leadNameInput.id = 'leadName';
    leadNameInputGroup.appendChild(leadNameInput);

    // Create the dropdown selection element
    const pipelineDropdown = document.createElement('select');
    pipelineDropdown.classList.add('form-select', 'mb-3');
    pipelineDropdown.setAttribute('aria-label', 'Select Pipeline');
    pipelineDropdown.id = 'pipelineDropdown';
    modalBody.appendChild(pipelineDropdown);

    // Add options to the dropdown from pipelineCache
    pipelineCache.forEach(pipeline => {
        const option = document.createElement('option');
        option.value = pipeline.Id;
        option.textContent = pipeline.PipelineName;
        pipelineDropdown.appendChild(option);
    });

    // Create the button element
    const createLeadButton = document.createElement('button');
    createLeadButton.textContent = 'Create Lead';
    createLeadButton.classList.add('btn', 'btn-primary');
    createLeadButton.setAttribute('data-bs-dismiss', 'modal');
    createLeadButton.setAttribute('aria-label', 'Close');
    createLeadButton.addEventListener('click', createLead);
    modalBody.appendChild(createLeadButton);

    // Append the modal to the document body
    document.body.appendChild(modal);
    var leadModal = new bootstrap.Modal("#leadModal", {focus: true});
    leadModal.show();
}

function createLead(){
    createLeadRequest();
    removeLeadPopup();
}

function createLeadRequest() {
    const token = readToken();
    const leadName = document.getElementById('leadName').value;
    const pipelineId = document.getElementById('pipelineDropdown').value;

    const xhr = new XMLHttpRequest();
    xhr.open('POST', url + '/biomedapi/projects/activities/create', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Request successful
                xalert('Lead created successfully', 0, -1);
                setTimeout(() => {
                    const leadId = xhr.responseText;
                    window.location.href = `./project-activity.html?activityid=${leadId}`;
                }, 2000);
            } else {
                // Request failed
                xalert('Error ' + xhr.status + " " + xhr.responseText, 1, -1);
            }
        }
    };
    let rawdata = {
        Name: leadName,
        Description: "Just a Placeholder",
        PipelineId: pipelineId
    };
    
    const data = JSON.stringify(rawdata);
    xhr.send(data);
}

function removeLeadPopup() {
    document.getElementById('leadModal').remove();
}

function clearRadioSelection(e) {
    const parentElement = e.parentElement;
    const radioButtons = parentElement.querySelectorAll('input[type="radio"]');
    radioButtons.forEach(radioButton => {
        radioButton.checked = false;
    });
}


function getQuarterDateRange(quarter, year) {


    if (quarter === 0) {
        const quarterStartMonths = [5, 8, 11, 2]; // May, August, November, February
        const quarterEndMonths = [7, 10, 1, 4]; // July, October, January, April

        const quarterStartMonth = quarterStartMonths[0];
        const quarterEndMonth = quarterEndMonths[3];

        const startDate = new Date(`20${year}-${quarterStartMonth}-01`);
        const endDate = new Date(`20${year + 1}-${quarterEndMonth}-${getDaysInMonth(quarterEndMonth, year + 1)}`);
        console.log(startDate, endDate);
        return {
            startDate,
            endDate
        };
    }
    const quarterStartMonths = [5, 8, 11, 2]; // May, August, November, February
    const quarterEndMonths = [7, 10, 1, 4]; // July, October, December, March
    if (quarter < 1 || quarter > 4) {
        throw new Error('Invalid quarter');
    }

    if (year < 0 || year > 99) {
        throw new Error('Invalid year');
    }

    const quarterStartMonth = quarterStartMonths[quarter - 1];
    const quarterEndMonth = quarterEndMonths[quarter - 1];

    const startDate = new Date(`20${year}-${quarterStartMonth}-01`);
    const endDate = new Date(`20${year}-${quarterEndMonth}-${getDaysInMonth(quarterEndMonth, year)}`);

    console.log(startDate, endDate);
    return {
        startDate,
        endDate
    };
}

function getDaysInMonth(month, year) {
    return new Date(year, month, 0).getDate();
}

function querysearch(){

    const expectedYearRadios = document.querySelectorAll('input[id^="ExpectedFY"]');
    const updatedYearRadios = document.querySelectorAll('input[id^="UpdateFY"]');
    const createYearRadios = document.querySelectorAll('input[id^="CreationFY"]');

    let expectedYear = '';
    let updatedYear = '';
    let createYear = '';

    expectedYearRadios.forEach(radio => {
        if (radio.checked) {
            expectedYear = radio.id.slice(-2);
        }
    });

    updatedYearRadios.forEach(radio => {
        if (radio.checked) {
            updatedYear = radio.id.slice(-2);
        }
    });

    createYearRadios.forEach(radio => {
        if (radio.checked) {
            createYear = radio.id.slice(-2);
        }
    });

    if (expectedYear === '') {
        expectedYear = new Date().getFullYear().toString().slice(-2);
    }

    if (updatedYear === '') {
        updatedYear = new Date().getFullYear().toString().slice(-2);
    }

    if (createYear === '') {
        createYear = new Date().getFullYear().toString().slice(-2);
    }

    console.log('Expected Year:', expectedYear);
    console.log('Updated Year:', updatedYear);
    console.log('Create Year:', createYear);

    const selectedUpdateQuarter = document.querySelector('input[id^="UpdateQuarter"]:checked');
    const selectedCreationQuarter = document.querySelector('input[id^="CreationQuarter"]:checked');
    const selectedExpectedQuarter = document.querySelector('input[id^="ExpectedQuarter"]:checked');

    let updateQuarterLabelText = '';
    let creationQuarterLabelText = '';
    let expectedQuarterLabelText = '';

    if (selectedUpdateQuarter) {
        const updateQuarterLabel = document.querySelector(`label[for="${selectedUpdateQuarter.id}"]`);
        updateQuarterLabelText = updateQuarterLabel.textContent;
    } else {
        updateQuarterLabelText = 'Q0';
    }

    if (selectedCreationQuarter) {
        const creationQuarterLabel = document.querySelector(`label[for="${selectedCreationQuarter.id}"]`);
        creationQuarterLabelText = creationQuarterLabel.textContent;
    } else {
        creationQuarterLabelText = 'Q0';
    }

    if (selectedExpectedQuarter) {
        const expectedQuarterLabel = document.querySelector(`label[for="${selectedExpectedQuarter.id}"]`);
        expectedQuarterLabelText = expectedQuarterLabel.textContent;
    } else {
        expectedQuarterLabelText = 'Q0';
    }

    console.log('Selected Update Quarter:', updateQuarterLabelText);
    console.log('Selected Creation Quarter:', creationQuarterLabelText);
    console.log('Selected Expected Quarter:', expectedQuarterLabelText);
    var CreationRange = getQuarterDateRange(parseInt(creationQuarterLabelText.slice(-1)), parseInt(createYear));
    var UpdateRange = getQuarterDateRange(parseInt(updateQuarterLabelText.slice(-1)), parseInt(updatedYear));
    var ExpectedRange = getQuarterDateRange(parseInt(expectedQuarterLabelText.slice(-1)), parseInt(expectedYear));
    var ContactIDs = getIDFromSelection(contactsQuerySelecter);
    var UserIDs = getIDFromSelection(usersQuerySelecter);
    var queryText= document.getElementById('crmQuery').value;
    if (ContactIDs.length === 0) {
        ContactIDs = null;
    }

    if (UserIDs.length === 0) {
        UserIDs = null;
    }
    if (queryText === "") {
        queryText = null;
    }
    var query = {
        StartDate: timeFormater(CreationRange.startDate),
        EndDate: timeFormater(CreationRange.endDate),
        UpdateStart: timeFormater(UpdateRange.startDate),
        UpdateEnd: timeFormater(UpdateRange.endDate),
        ExpectedStart: timeFormater(ExpectedRange.startDate),
        ExpectedEnd: timeFormater(ExpectedRange.endDate),
        ContactIDs: ContactIDs,
        UserIDs: UserIDs,
        Title: queryText,
        DeepSearch: true
    };
    if (expectedYearRadios.length === 0 && !selectedExpectedQuarter) {
        query.ExpectedStart = null;
        query.ExpectedEnd = null;
    }
    
    if (updatedYearRadios.length === 0 && !selectedUpdateQuarter) {
        query.UpdateStart = null;
        query.UpdateEnd = null;
    } 
    
    if (createYearRadios.length === 0 && !selectedCreationQuarter) {
        query.StartDate = null;
        query.EndDate = null;
    } 

    console.log(query);
    displayLeads(query);

    // Rest of the code...
    
}