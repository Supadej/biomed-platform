const urlParams = new URLSearchParams(window.location.search);
const id = urlParams.get('id');

function usersModal() {

    var multiSelectModal = new bootstrap.Modal("#multiSelectModal", {focus: true});
    multiSelectModal.show();
}
window.onload = function() {

    if (!id) {
        xalert("No id please check your url",1,null);
        return;
    
    }
    getGroupMembers(id, function(error, response) {

        if (error) {
            console.error('Failed to fetch group:', error);
            xalert("Failed to fetch group",1,null);
            return;
        }

                    

        const modalUsersList = document.getElementById('modalUsersList');
        document.getElementById('groupName').value = response.GroupName;
        const select = document.getElementById('usersSelecter');
        getUsers((error, users) => {
            if (error) {
                console.error('Failed to fetch users:', error);
                return;
            }
    
            //And main responsible user
            const primaryBadge = document.createElement('span');
            primaryBadge.classList.add('badge', 'bg-info', 'text-dark', 'py-1', 'm-1', 'align-middle', 'text-wrap');
            const Muser = users.find(Muser => Muser.Id === response.GroupUsers);
            if (Muser) {
                primaryBadge.innerHTML = `<strong><i class="fi fi-rr-chess-king align-middle mx-1"></i>Primary: </strong>${Muser.FirstName} ${Muser.LastName} (${Muser.Position})`;
            }
            mainuserid = response.MainUserId;
            modalUsersList.appendChild(primaryBadge);
    
    
            users.forEach(user => {
                if (user.Id !== response.MainUserId) {
                const option = document.createElement('option');
                option.value = user.Id;
                option.textContent = `${user.FirstName} ${user.LastName}`;
                option.setAttribute('data-subtext', `${user.Position}`);
                select.appendChild(option);
                }
            });
            
            
            $(select).on('changed.bs.select', function (e, clickedIndex, isSelected, previousValue) {
            
                const selectedOptions = Array.from(e.target.selectedOptions);
                modalUsersList.innerHTML = '';
                modalUsersList.appendChild(primaryBadge);
                selectedOptions.forEach(option => {
                    const badge = document.createElement('span');
                    badge.classList.add('badge', 'biomed-bg-accent', 'text-dark', 'py-1', 'm-1', 'align-middle', 'text-wrap');
                    badge.innerHTML = option.getAttribute('data-subtext') ? `${option.textContent} (${option.getAttribute('data-subtext')})` : option.textContent;
                    modalUsersList.appendChild(badge);
                });
                document.getElementById("mainUsersList").innerHTML = modalUsersList.innerHTML;
            });
            
            
            document.getElementById("mainUsersList").innerHTML = modalUsersList.innerHTML;
            // Refresh the selectpicker to update the options
    
            $(select).selectpicker('refresh');
        }, false);
        
        const userIds = response.GroupUsers.map(user => user.UserId);
        const selectValues = userIds.map(String);
        $(select).selectpicker('val', selectValues);
    
    });
    

}


function saveGroup()
{
    const data = {
        groupName: document.getElementById('groupName').value,
        id: id,
        userIDs: Array.from(document.getElementById('usersSelecter').selectedOptions).map(option => parseInt(option.value))
    };

    updateGroup(data, function(error, response) {
        if (error) {
            console.error('Failed to update group:', error);
            xalert("Failed to update group",1,null);
            return;
        }
        // Handle successful update
        console.log('Group updated successfully:', response);
        xalert("Group updated successfully",0,null);
    });

}

function updateGroup(data, callback) {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url+ '/biomedapi/groups/update');
    xhr.setRequestHeader('Authorization', `Bearer ${readToken()}`);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onload = function() {
        if (xhr.status === 200) {
            callback(null, xhr.responseText);
        } else {
            callback('Failed to update group', null);
        }
    };
    xhr.onerror = function() {
        callback('Failed to send request', null);
    };
    xhr.send(JSON.stringify(data));
}