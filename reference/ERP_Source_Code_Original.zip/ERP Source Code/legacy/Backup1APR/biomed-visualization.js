const pivot = new WebDataRocks({
    width: "100%",
    height: "100%",
    container: "#pivotContainer",
    toolbar: true, // Enable the toolbar
    beforetoolbarcreated: customizeToolbar // Customize the toolbar
});

function customizeToolbar(toolbar) {
    // Get all tabs from the toolbar
    let tabs = toolbar.getTabs();
    
    // Filter out the Connect, Open, Save, and Export tabs by their IDs
    toolbar.getTabs = function() {
        tabs = tabs.filter(tab => 
            tab.id !== "wdr-tab-connect" && 
            tab.id !== "wdr-tab-open" && 
            tab.id !== "wdr-tab-save" && 
            tab.id !== "wdr-tab-export"
        );

    // Add custom tabs for Pivot Leads, Pivot Events, and Pivot HelpDesk
    tabs.push(
        {
            id: "wdr-tab-pivotleads", // Unique ID for Pivot Leads tab
            title: "Leads", // Title displayed on the tab
            handler: pivotLeadsHandler, // Function to run when the tab is clicked
            icon: `<i class="fi fi-rr-list"></i>` // Bootstrap Icon for list (e.g., leads)
        }/*,
        {
            id: "wdr-tab-pivotevents", // Unique ID for Pivot Events tab
            title: "Events", // Title displayed on the tab
            handler: pivotEventsHandler, // Function to run when the tab is clicked
            icon: `<i class="fi fi-rr-calendar-day"></i>` // Bootstrap Icon for calendar/event
        },
        {
            id: "wdr-tab-pivothelpdesk", // Unique ID for Pivot HelpDesk tab
            title: "Tickets", // Title displayed on the tab
            handler: pivotHelpDeskHandler, // Function to run when the tab is clicked
            icon: `<i class="fi fi-rr-wrench-alt"></i>` // Bootstrap Icon for headset/support
        }*/ 
    );
        return tabs;
    };
}
// Handler functions for each custom tab
function pivotLeadsHandler() {
    console.log("Switching to Pivot Leads...");
    PivotLeads(); // Call the existing PivotLeads function
}

function pivotEventsHandler() {
    console.log("Switching to Pivot Events...");
    PivotEvents(); // Call the new PivotEvents function
}

function pivotHelpDeskHandler() {
    console.log("Switching to Pivot HelpDesk...");
    PivotHelpDesk(); // Call the new PivotHelpDesk function
}


async function LeadProcessing(leads) {
    
    let leadsProcessed = [];
        for (const lead of leads) {
        let leadProcessed = {
            Id: lead.Id,
            Name: lead.LeadName+"("+lead.Id+")",
            AchivedRevenue: lead.AchivedRevenue,
            Budget: lead.Budget,
            CRMPipelineId: lead.CRMPipelineId,
            Creation: lead.Creation,
            Expected: lead.Expected,
            ExpectedRevenue: lead.ExpectedRevenue,
            isCollected: lead.isCollected ===true? true:false,
            isPO: lead.isPO ===true? true:false,
            NumberOfUsers: lead.LeadUsers.length+1,
            
        }
        let user = await promiseUserById(lead.MainUserId);
        leadProcessed.MainUser = user.FirstName + " " + user.LastName + "(" + user.Position + ")";
        leadProcessed.MainCustomer = (await promiseContactById(lead.MainCustomerId)).Name;
        leadProcessed.SaleArea = (await promiseSaleAreaById(lead.SaleAreaId)).Name;
        leadProcessed.Product = (await promiseProductById(lead.ProductId)).Name;
        leadProcessed.LastLogDate = lead.Logs.length > 0 ? lead.Logs[lead.Logs.length - 1].DateTime : lead.Creation;
        leadProcessed.TotalDuration =  Math.floor((new Date(leadProcessed.LastLogDate) - new Date(lead.Creation)) / (1000 * 60 * 60 * 24)), // number of days from creation to lastUpdated
        leadProcessed.Pipeline = (await promiseCRMPipelineById(lead.CRMPipelineId)).PipelineName;
        leadsProcessed.push(leadProcessed);
    }


    console.log("Processed",leadsProcessed);
    return leadsProcessed;
}

async function getPivotLeadsData() {
    return new Promise((resolve) => {
        getLeads((err,data) => {
            if (err) {
                console.error("Failed to fetch leads:", err);
                xalert("Failed to fetch leads:" + err, 1, null);
                reject(err);
                return;
            }
            resolve(data);
        });
    });
}

async function PivotLeads(){
    try {
        let data = await getPivotLeadsData();
        let processedData = await LeadProcessing(data);
        pivot.updateData({ data: processedData });
        pivot.setReport({
            dataSource: {
                data: processedData
            },
            slice: {
                rows: [
                    { uniqueName: "Product" },
                    { uniqueName: "SaleArea" }
                ],
                columns: [
                    { uniqueName: "[Measures]" },
                    { uniqueName: "Expected.Year" },
                    { uniqueName: "Expected.Month" }
                ],
                measures: [
                    {
                        uniqueName: "AchivedRevenue",
                        aggregation: "sum"
                    }
                ],
                reportFilters: [
                    { uniqueName: "Pipeline" }
                ]
            }
        });
        console.log(processedData);
    } catch (error) {
        console.error("Error processing leads:", error);
    }

}

//Default Load
(async () => {
    await PivotLeads();
})();

// --- Dynamic Chart.js Integration Based on Pivot Slice ---
// Once the report is complete, retrieve both the report configuration and pivot data to build the chart dynamically.
/*pivot.on("reportcomplete", function() {
    console.log("Report complete");
    try {
        const report = pivot.getReport(); // Synchronous call
        console.log("Report:", report);
        if (!report) {
            console.error("No report returned");
            return;
        }
        pivot.getData({ type: "json" }, function(data) {
            console.log("Pivot data:", data);
            if (!data || !data.data) {
                console.error("No data returned from getData");
                return;
            }
            var chartData = processPivotData(data, report);
            console.log("Chart data:", chartData);
            if (chartData.labels.length === 0) {
                console.warn("No chart data generated");
            }
            createChartJSChart(chartData);
        }, function(error) {
            console.error("getData failed:", error);
        });
    } catch (error) {
        console.error("Error in reportcomplete:", error);
    }
});*/

// Dynamically process pivot data into a Chart.js-compatible format using the current pivot slice.
function processPivotData(data, report) {
    var arr = data.data;
    if (!arr || arr.length === 0) {
        console.warn("No data to process");
        return { labels: [], datasets: [] };
    }

    // Extract column fields from the report that contain "Year" or "Month"
    const columnFields = report.slice.columns || [];
    const yearFields = columnFields.filter(field => field.uniqueName.toLowerCase().includes("year"));
    const monthFields = columnFields.filter(field => field.uniqueName.toLowerCase().includes("month"));

    // Build labels based on the column order in the report
    let labels = [];
    const columnKeys = []; // To track the keys (c0, c1, etc.) for each column

    if (yearFields.length > 0 || monthFields.length > 0) {
        // Determine the order of columns based on their position in slice.columns
        let columnIndex = 0;
        columnFields.forEach(field => {
            if (field.uniqueName.toLowerCase().includes("year") || field.uniqueName.toLowerCase().includes("month")) {
                const key = `c${columnIndex}`;
                columnKeys.push(key);
                columnIndex++;
            }
        });

        // Extract unique values for each column key, maintaining order from the report
        labels = columnKeys.map(key => {
            const values = [...new Set(arr.filter(row => row[key]).map(row => row[key]))];
            return values.length > 0 ? values : [];
        }).flat().sort((a, b) => {
            // Define month names and their corresponding numerical order (1–12)
            const monthNumbers = {
                "january": 1, "february": 2, "march": 3, "april": 4, "may": 5, "june": 6,
                "july": 7, "august": 8, "september": 9, "october": 10, "november": 11, "december": 12
            };

            // Convert to lowercase for case-insensitive comparison
            const aLower = a.toLowerCase();
            const bLower = b.toLowerCase();

            // Check if values are months (case-insensitive match against month names)
            const aIsMonth = Object.keys(monthNumbers).some(month => month === aLower);
            const bIsMonth = Object.keys(monthNumbers).some(month => month === bLower);

            // Check if values are years (numeric, 4 digits)
            const aIsYear = /^\d{4}$/.test(a);
            const bIsYear = /^\d{4}$/.test(b);

            // Sort logic: prioritize months (by numerical order) before years (numerically)
            if (aIsMonth && bIsMonth) {
                return monthNumbers[aLower] - monthNumbers[bLower]; // Sort months by numerical order (1–12)
            } else if (aIsYear && bIsYear) {
                return parseInt(a) - parseInt(b); // Sort years numerically
            } else if (aIsMonth && !bIsMonth) {
                return -1; // Months come before years
            } else if (!aIsMonth && bIsMonth) {
                return 1; // Years come after months
            } else {
                // If neither is a month or year, sort alphabetically as fallback
                return a.localeCompare(b);
            }
        });
    }
    else{
        // Determine the order of columns based on their position in slice.columns
        let columnIndex = 0;
        columnFields.forEach(field => {
            const key = `c${columnIndex}`;
            columnKeys.push(key);
            columnIndex++;
        });

        // Extract unique values for each column key, maintaining order from the report
        labels = columnKeys.map(key => {
            const values = [...new Set(arr.filter(row => row[key]).map(row => row[key]))];
            return values.length > 0 ? values : [];
        }).flat();
    }

    // If no labels are found, use a fallback (shouldn't happen with valid data)
    if (labels.length === 0) {
        labels = [...new Set(arr.filter(row => row.c0).map(row => row.c0))].sort();
    }
    console.log("Chart labels (ordered):", labels);

    // Extract unique row values (e.g., "MabTech", "T-Spot.TB", "test35") for datasets
    const rowValues = [...new Set(arr.filter(row => row.r0).map(row => row.r0))];
    console.log("Row values:", rowValues);

    // Get measure info from report
    const measureFields = report.slice.measures || [];
    if (measureFields.length === 0) {
        console.warn("No measures defined in report");
        return { labels, datasets: [] };
    }
    const measureName = aggregationLabel(measureFields[0]); // e.g., "Sum of AchivedRevenue"

    // Build datasets
    const colors = [
        'rgba(75, 192, 192, 0.6)',  // MabTech
        'rgba(255, 99, 132, 0.6)',  // T-Spot.TB
        'rgba(54, 162, 235, 0.6)',  // test35
        'rgba(255, 206, 86, 0.6)',
        'rgba(153, 102, 255, 0.6)'
    ];

    const datasets = rowValues.map((product, idx) => {
        const data = labels.map(label => {
            // Determine which column key (c0, c1, etc.) matches the label
            let value = 0;
            for (let i = 0; i < columnKeys.length; i++) {
                const key = columnKeys[i];
                const row = arr.find(r => 
                    r.r0 === product && 
                    r[key] === label
                );
                if (row) {
                    value = row.v0 || 0;
                    break;
                }
            }
            return value; // Default to 0 if no data
        });
        return {
            label: product,
            data: data,
            backgroundColor: colors[idx % colors.length],
            borderColor: colors[idx % colors.length].replace("0.6", "1"),
            borderWidth: 1
        };
    });

    return {
        labels: labels,
        datasets: datasets
    };
}


// Helper function to generate a label for a measure.
function aggregationLabel(measure) {
    if (measure.aggregation) {
        return measure.aggregation.charAt(0).toUpperCase() + measure.aggregation.slice(1) + " of " + measure.uniqueName;
    }
    return measure.uniqueName;
}


// In biomed-visualization.js
function createChartJSChart(chartData, report, chartType = 'bar') {
    var ctx = document.getElementById("chartCanvas").getContext("2d");
    if (window.myChart instanceof Chart) {
        window.myChart.destroy();
    }

    // Dynamically generate chart title based on slice and filters
    const rows = (report.slice.rows || []).map(row => row.uniqueName).join(", ");
    const columns = (report.slice.columns || []).map(col => col.uniqueName).join(", ");
    const measures = (report.slice.measures || []).map(measure => measure.uniqueName).join(", ");
    const reportFilters = report.slice.reportFilters || [];

    // Handle filters, default to "All" if undefined or no filter
    const filters = reportFilters.length > 0 
        ? reportFilters.map(filter => {
            const filterValue = filter.filter ? JSON.stringify(filter.filter) : "All";
            return `${filter.uniqueName}=${filterValue}`;
        }).join(", ") 
        : "All";

    const title = `Dynamic Chart - Rows: ${rows || 'None'}, Columns: ${columns || 'None'}, Measures: ${measures || 'None'}, Filters: ${filters}`;

    let options = {
        responsive: true,
        plugins: {
            legend: { position: 'top' },
            title: { display: true, text: title },
            datalabels: {
                anchor: 'end',
                align: 'end',
                formatter: (value) => value !== 0 ? value.toLocaleString() : '',
                font: { weight: 'bold', size: 12 },
                color: 'black'
            }
        },
        scales: {}
    };

    // Adjust options based on chart type (bar, line, pie only)
    switch (chartType.toLowerCase()) {
        case 'bar':
            options.scales = {
                x: { stacked: false, title: { display: true, text: 'Time Period' } },
                y: {
                    beginAtZero: true,
                    title: { display: true, text: 'Revenue' },
                    ticks: { callback: (value) => value.toLocaleString() }
                }
            };
            break;
        case 'line':
            options.scales = {
                x: { title: { display: true, text: 'Time Period' } },
                y: {
                    beginAtZero: true,
                    title: { display: true, text: 'Revenue' },
                    ticks: { callback: (value) => value.toLocaleString() }
                }
            };
            break;
        case 'pie':
            delete options.scales;
            options.aspectRatio = 1; // Ensure 1:1 aspect ratio for circular pie
            options.plugins.datalabels = {
                anchor: 'center',
                align: 'center',
                formatter: (value) => value.toLocaleString(),
                font: { weight: 'bold', size: 12 },
                color: 'white'
            };
            // Ensure distinct colors for pie segments
            if (chartData.datasets && chartData.datasets.length > 0) {
                chartData.datasets[0].backgroundColor = [
                    'rgba(75, 192, 192, 0.6)',   // Teal (e.g., MabTech)
                    'rgba(255, 99, 132, 0.6)',   // Pink (e.g., T-Spot.TB)
                    'rgba(54, 162, 235, 0.6)',   // Blue (e.g., test35)
                    'rgba(255, 206, 86, 0.6)',   // Yellow
                    'rgba(153, 102, 255, 0.6)'    // Purple
                ];
                chartData.datasets[0].borderColor = chartData.datasets[0].backgroundColor.map(color => color.replace("0.6", "1"));
            }
            break;
        default:
            console.warn(`Unsupported chart type: ${chartType}. Using 'bar' as default.`);
            chartType = 'bar';
            options.scales = {
                x: { stacked: false, title: { display: true, text: 'Time Period' } },
                y: {
                    beginAtZero: true,
                    title: { display: true, text: 'Revenue' },
                    ticks: { callback: (value) => value.toLocaleString() }
                }
            };
    }

    window.myChart = new Chart(ctx, {
        type: chartType.toLowerCase(),
        data: chartData,
        plugins: [ChartDataLabels],
        options: options
    });
}


function updateChart(chartType = 'bar') {
    const report = pivot.getReport();
    console.log("Report updated:", report);

    pivot.getData({ type: "json" }, function(data) {
        console.log("Updated pivot data:", data);
        var chartData = processPivotData(data, report);
        console.log("Updated chart data:", chartData);
        createChartJSChart(chartData, report, chartType);
    }, function(error) {
        console.error("getData failed on update:", error);
    });
}

pivot.on("update", function() {
    console.log("Pivot table updated (e.g., filter changed)");
    updateChart(); // Use default 'bar' or pass a specific chartType if needed
});

pivot.on("reportcomplete", function() {
    console.log("Report complete");
    const report = pivot.getReport();
    console.log("Report:", report);

    const reportFilters = report.slice.reportFilters || [];
    if (reportFilters.length > 0) {
        console.log("Current Report Filters:", reportFilters.map(filter => ({
            uniqueName: filter.uniqueName,
            filter: filter.filter || "All"
        })));
    } else {
        console.log("No report filters applied or all filters set to 'All'.");
    }

    pivot.getData({ type: "json" }, function(data) {
        console.log("Pivot data:", data);
        var chartData = processPivotData(data, report);
        console.log("Chart data:", chartData);
        createChartJSChart(chartData, report); // Use default 'bar' for initial load
    }, function(error) {
        console.error("getData failed:", error);
    });
});





function changeChartType(chartType) {
    console.log("Changing chart type to:", chartType);
    updateChart(chartType); // Update the chart with the new type
}




//TO BE Implemented

// New function for Pivot Events
async function PivotEvents() {
    try {
        let data = await getPivotEventsData(); // New function to fetch Events data
        let processedData = await EventProcessing(data); // New function to process Events data
        pivot.updateData({ data: processedData });
        pivot.setReport({
            dataSource: {
                data: processedData
            },
            slice: {
                rows: [
                    { uniqueName: "EventName" }, // Example field for events
                    { uniqueName: "Location" } // Example field for events
                ],
                columns: [
                    { uniqueName: "[Measures]" },
                    { uniqueName: "EventDate.Year" }, // Example date field
                    { uniqueName: "EventDate.Month" }
                ],
                measures: [
                    {
                        uniqueName: "Attendance", // Example measure for events
                        aggregation: "sum"
                    }
                ],
                reportFilters: [
                    { uniqueName: "EventType" } // Example filter for events
                ]
            }
        });
        console.log("Processed Events Data:", processedData);
        updateChart(); // Update the chart with the new data
    } catch (error) {
        console.error("Error processing Pivot Events:", error);
        alert("Error processing Pivot Events: " + error);
    }
}

// New function for Pivot HelpDesk
async function PivotHelpDesk() {
    try {
        let data = await getPivotHelpDeskData(); // New function to fetch HelpDesk data
        let processedData = await HelpDeskProcessing(data); // New function to process HelpDesk data
        pivot.updateData({ data: processedData });
        pivot.setReport({
            dataSource: {
                data: processedData
            },
            slice: {
                rows: [
                    { uniqueName: "IssueType" }, // Example field for helpdesk issues
                    { uniqueName: "Priority" } // Example field for helpdesk
                ],
                columns: [
                    { uniqueName: "[Measures]" },
                    { uniqueName: "CreatedDate.Year" }, // Example date field
                    { uniqueName: "CreatedDate.Month" }
                ],
                measures: [
                    {
                        uniqueName: "TicketCount", // Example measure for helpdesk
                        aggregation: "sum"
                    }
                ],
                reportFilters: [
                    { uniqueName: "Department" } // Example filter for helpdesk
                ]
            }
        });
        console.log("Processed HelpDesk Data:", processedData);
        updateChart(); // Update the chart with the new data
    } catch (error) {
        console.error("Error processing Pivot HelpDesk:", error);
        alert("Error processing Pivot HelpDesk: " + error);
    }
}

// New function to fetch Pivot Events data
async function getPivotEventsData() {
    return new Promise((resolve, reject) => {
        getEvents((err, data) => { // Replace with your actual Events API call
            if (err) {
                console.error("Failed to fetch events:", err);
                xalert("Failed to fetch events: " + err, 1, null);
                reject(err);
                return;
            }
            resolve(data);
        });
    });
}

// New function to fetch Pivot HelpDesk data
async function getPivotHelpDeskData() {
    return new Promise((resolve, reject) => {
        getTickets((err, data) => { // Replace with your actual HelpDesk API call
            if (err) {
                console.error("Failed to fetch helpdesk data:", err);
                xalert("Failed to fetch helpdesk data: " + err, 1, null);
                reject(err);
                return;
            }
            resolve(data);
        });
    });
}

// Placeholder for EventProcessing (implement based on your data structure)
async function EventProcessing(events) {
    let processedEvents = [];
    for (const event of events) {
        let processedEvent = {
            EventName: event.Name || "Unknown Event",
            Location: event.Location || "Unknown Location",
            EventDate: event.Date || new Date(),
            Attendance: event.Attendance || 0,
            EventType: event.Type || "Unknown"
        };
        processedEvents.push(processedEvent);
    }
    console.log("Processed Events:", processedEvents);
    console.log("Raw Events:", events);
    return processedEvents;
}

// Placeholder for HelpDeskProcessing (implement based on your data structure)
async function HelpDeskProcessing(tickets) {
    let processedTickets = [];
    for (const ticket of tickets) {
        let processedTicket = {
            IssueType: ticket.Issue || "Unknown Issue",
            Priority: ticket.Priority || "Low",
            CreatedDate: ticket.Created || new Date(),
            TicketCount: 1, // Assuming each ticket counts as 1 for aggregation
            Department: ticket.Department || "Unknown"
        };
        processedTickets.push(processedTicket);
    }
    console.log("Processed HelpDesk Tickets:", processedTickets);
    return processedTickets;
}