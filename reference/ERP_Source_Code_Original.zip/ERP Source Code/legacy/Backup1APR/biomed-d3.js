const urlParams = new URLSearchParams(window.location.search);
const id = urlParams.get('id');
const type = urlParams.get('type');


var filtered = false;

let processedNodeData = JSON.parse(sessionStorage.getItem('processedNodeData'));
if (processedNodeData) {
  console.log("Using cached data");
  if (!id || isNaN(parseInt(id)) || !["Users", "Contacts", "Events", "Leads", "Activities", "Tickets"].includes(type.charAt(0).toUpperCase() + type.slice(1).toLowerCase())) {
    initialization(processedNodeData);
    console.log("All Mode");
  } else {
    let filteredData = Filter(processedNodeData, type.charAt(0).toUpperCase() + type.slice(1).toLowerCase(), parseInt(id));
    filtered = true;
    initialization(filteredData);
    console.log("Filtered Mode");
  }
}else{
  console.log("Requesting data from server");
  const xhr = new XMLHttpRequest();
  const token = readToken();
  xhr.open("GET", url+"/biomedapi/visualization", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", `Bearer ${token}`);
  xhr.onreadystatechange = function () {
      if (xhr.readyState === 4 && xhr.status === 200) {
          const response = JSON.parse(xhr.responseText);
          // Process the response data here
          console.log(response);
          let processedNodeData = preprocessing(response);
          console.log("Node Processing",processedNodeData);
          sessionStorage.setItem('processedNodeData', JSON.stringify(processedNodeData));
          if (!id || isNaN(parseInt(id)) || !["Users", "Contacts", "Events", "Leads", "Activities", "Tickets"].includes(type.charAt(0).toUpperCase() + type.slice(1).toLowerCase())) {
              initialization(processedNodeData);
              console.log("All Mode");
          }else{
              let filteredData = Filter(processedNodeData, type.charAt(0).toUpperCase() + type.slice(1).toLowerCase(), parseInt(id));
              filtered = true;
              initialization(filteredData);
  
              console.log("Filtered Mode");
          }
          
          
      }
  };
  xhr.send();
}



function Filter(data, filterType, filterId) {
    // mapping plural to singular node type
    const singularMap = {
      "Users": "User",
      "Contacts": "Contact",
      "Events": "Event",
      "Leads": "Lead",
      "Activities": "Activity",
      "Tickets": "Ticket"
    };
  
    const startType = singularMap[filterType];
    const startIdType = filterId.toString() + "-" + startType;
  
    // Build a lookup map of nodes keyed by "id-type"
    const nodesMap = {};
    data.nodes.forEach(node => {
      node.idType = node.id.toString() + "-" + node.type;
      nodesMap[node.idType] = node;
    });
  
    // Mark the start node
    if (nodesMap[startIdType]) {
      nodesMap[startIdType].isStart = true;
    }
  
    // Build an undirected adjacency list from all links
    const adjacency = {};
    data.links.forEach(link => {
      const originIdType = link.origin.id.toString() + "-" + link.origin.type;
      const destIdType = link.destination.id.toString() + "-" + link.destination.type;
      if (!adjacency[originIdType]) adjacency[originIdType] = [];
      if (!adjacency[destIdType]) adjacency[destIdType] = [];
      adjacency[originIdType].push(destIdType);
      adjacency[destIdType].push(originIdType);
    });
  
    // Perform a BFS starting at the selected node.
    // When expanding, if a neighbor is of type "User" or "Contact" (and it isn’t the start node),
    // add it to the visited set but do not enqueue it for further expansion.
    const visited = new Set();
    const queue = [];
    visited.add(startIdType);
    queue.push(startIdType);
  
    while (queue.length) {
      const current = queue.shift();
      if (adjacency[current]) {
        adjacency[current].forEach(neighbor => {
          if (!visited.has(neighbor)) {
            visited.add(neighbor);
            const neighborType = nodesMap[neighbor].type;
            // If the neighbor is a User or Contact and isn't the starting node, do not expand from it.
            if (neighbor !== startIdType && (neighborType === "User" || neighborType === "Contact")) {
              // Do not enqueue this neighbor.
            } else {
              queue.push(neighbor);
            }
          }
        });
      }
    }
  
    // Filter nodes to only those in the visited set
    const resultNodes = [];
    visited.forEach(idType => {
      if (nodesMap[idType]) resultNodes.push(nodesMap[idType]);
    });
  
    // Filter links to include only those connecting two visited nodes
    const resultLinks = data.links.filter(link => {
      const originIdType = link.origin.id.toString() + "-" + link.origin.type;
      const destIdType = link.destination.id.toString() + "-" + link.destination.type;
      return visited.has(originIdType) && visited.has(destIdType);
    });
  
    return { nodes: resultNodes, links: resultLinks };
  }
  
  
  

function preprocessing(data) {
    const nodes = [];
    const links = [];
  
    // Process node arrays
    if (data.Users) {
      data.Users.forEach(user => {
        nodes.push({
          id: user.Id.toString(),
          type: "User",
          name: "User: "+user.FirstName + (user.LastName ? " " + user.LastName : "")+ (user.Position ? " (" + user.Position + ")" : "")
        });
      });
    }
    
    if (data.Events) {
      data.Events.forEach(event => {
        nodes.push({
          id: event.Id.toString(),
          type: "Event",
          name: "Event: "+event.Title
        });
      });
    }
    
    if (data.Leads) {
      data.Leads.forEach(lead => {
        nodes.push({
          id: lead.Id.toString(),
          type: "Lead",
          name: "Lead: "+lead.LeadName
        });
      });
    }
    
    if (data.Activities) {
      data.Activities.forEach(activity => {
        nodes.push({
          id: activity.Id.toString(),
          type: "Activity",
          name: "Activity: "+activity.Name
        });
      });
    }
    
    if (data.Tickets) {
      data.Tickets.forEach(ticket => {
        nodes.push({
          id: ticket.Id.toString(),
          type: "Ticket",
          name: "Ticket: "+ticket.Title
        });
      });
    }
    
    if (data.Contacts) {
      data.Contacts.forEach(contact => {
        nodes.push({
          id: contact.Id.toString(),
          type: "Contact",
          name: "Contact: "+contact.Name
        });
      });
    }
    
    // For Leads: MainUserId and MainCustomerId
  if (data.Leads) {
    data.Leads.forEach(lead => {
      if (lead.MainUserId) {
        links.push({
          origin: { id: lead.Id.toString(), type: "Lead" },
          destination: { id: lead.MainUserId.toString(), type: "User" }
        });
      }
      if (lead.MainCustomerId) {
        links.push({
          origin: { id: lead.Id.toString(), type: "Lead" },
          destination: { id: lead.MainCustomerId.toString(), type: "Contact" }
        });
      }
    });
  }
  
  // For Tickets: ContactId, AssignedToUserId, CreatedByUserId
  if (data.Tickets) {
    data.Tickets.forEach(ticket => {
      if (ticket.ContactId) {
        links.push({
          origin: { id: ticket.Id.toString(), type: "Ticket" },
          destination: { id: ticket.ContactId.toString(), type: "Contact" }
        });
      }
      if (ticket.AssignedToUserId) {
        links.push({
          origin: { id: ticket.Id.toString(), type: "Ticket" },
          destination: { id: ticket.AssignedToUserId.toString(), type: "User" }
        });
      }
      if (ticket.CreatedByUserId) {
        links.push({
          origin: { id: ticket.Id.toString(), type: "Ticket" },
          destination: { id: ticket.CreatedByUserId.toString(), type: "User" }
        });
      }
    });
  }
  
  // For Events: MainUserID and MainContactID
  if (data.Events) {
    data.Events.forEach(event => {
      if (event.MainUserID) {
        links.push({
          origin: { id: event.Id.toString(), type: "Event" },
          destination: { id: event.MainUserID.toString(), type: "User" }
        });
      }
      if (event.MainContactID) {
        links.push({
          origin: { id: event.Id.toString(), type: "Event" },
          destination: { id: event.MainContactID.toString(), type: "Contact" }
        });
      }
    });
  }
  
  // For Activities: MainUserId
  if (data.Activities) {
    data.Activities.forEach(activity => {
      if (activity.MainUserId) {
        links.push({
          origin: { id: activity.Id.toString(), type: "Activity" },
          destination: { id: activity.MainUserId.toString(), type: "User" }
        });
      }
    });
  }
  
  // Mapping from property names to node types for additional relationships
  const propTypeMapping = {
    LeadId: "Lead",
    UserId: "User",
    EventId: "Event",
    ActivityId: "Activity",
    TicketId: "Ticket",
    HelpdeskTicketId: "Ticket",
    ContactId: "Contact"
  };

  // The keys that we used to create nodes
  const nodeKeys = ["Users", "Events", "Leads", "Activities", "Tickets", "Contacts"];
  
  // Process remaining arrays as link definitions (e.g. LogBinders, LeadUsers, etc.)
  Object.keys(data).forEach(key => {
    if (!nodeKeys.includes(key)) {
      data[key].forEach(item => {
        const itemKeys = Object.keys(item);
        // Only create a link if there are at least 2 properties
        if (itemKeys.length >= 2) {
          // Use the first key as origin and the second as destination
          const originKey = itemKeys[0];
          const destKey = itemKeys[1];
          if (propTypeMapping[originKey] && propTypeMapping[destKey]) {
            links.push({
              origin: {
                id: item[originKey].toString(),
                type: propTypeMapping[originKey]
              },
              destination: {
                id: item[destKey].toString(),
                type: propTypeMapping[destKey]
              }
            });
          }
        }
      });
    }
  });
  
  return { nodes, links };
  }
  

function initialization(data){

    const nodes = data.nodes;
    const links = data.links;

    

    // Process data
    nodes.forEach(node => {
        node.idType = `${node.id}-${node.type}`;
        node.degree = 0;
    });

    const processedLinks = links.map(link => ({
      
        source: `${link.origin.id}-${link.origin.type}`,
        target: `${link.destination.id}-${link.destination.type}`
    }));
    processedLinks.forEach(link => {
      // Assuming link.source and link.target refer to node objects
      link.source.degree = (link.source.degree || 0) + 1;
      link.target.degree = (link.target.degree || 0) + 1;
    });

    // Define scales
    const colorScale = d3.scaleOrdinal()
        .domain(["User", "Event", "Lead", "Activity", "Ticket", "Contact"])
        .range(["#FFD700", "#A9DFBF", "#F9AFAF", "#F7DC6F", "#D2B4DE", "#FFB6A7"]);

    const totalNodes = nodes.length;

    // Set some tuning constants:
    const minScale = 0.3;         // Don't scale below this value to keep nodes visible
    const constant = 3;  
    const scaleFactor = Math.max(minScale, constant /Math.pow(totalNodes, 0.25));
    console.log("Total Nodes",totalNodes);
    console.log("Scale Factor",scaleFactor);
    const showLabel = totalNodes<100?true:false;
    // Suppose you define base radii for each type:

    const smallsize =  (10*scaleFactor).toFixed(1);
    console.log("Small Size",smallsize);
    const mediumsize = (15*scaleFactor).toFixed(1);
    console.log("Medium Size",mediumsize);
    const largesize = (20*scaleFactor).toFixed(1);
    console.log("Large Size",largesize);
    const getRadius = type => {
      switch (type) {
        case "User":
          //console.log("User",type);
          return smallsize;
        case "Contact":
          //console.log("Contact",type);
          return smallsize;
        case "Event":
          //console.log("Event",type);
          return smallsize;
        case "Activity":
          //console.log("Activity",type);
          return mediumsize;
        case "Ticket":
          //console.log("Ticket",type);
          return mediumsize;
        case "Lead":
          //console.log("Lead",type);
          return largesize;
        default:
          //console.log("Unknown Type",type);
          return smallsize;
      }
    };
        
    /*const getRadius = type => {
        switch (type) {
            case "User":
            case "Contact":
                return 5;
            case "Event":
            case "Activity":
            case "Ticket":
                return 10;
            case "Lead":
                return 15;
            default:
                return 5;
        }
    };*/
    const getDistance = type => {
      switch (type) {
          case "User":
          case "Contact":
              return 100;
          case "Event":
          case "Activity":
          case "Ticket":
              return 600;
          case "Lead":
              return 1000;
          default:
              return 100;
      }
  };

    // SVG setup
    const width = 19000;
    const height = 10800;
    const svg = d3.select("#d3Display").attr("width", width).attr("height", height);
    const container = document.getElementById("svg-container");
    container.scrollLeft = (container.scrollWidth - container.clientWidth) / 2;
    container.scrollTop = (container.scrollHeight - container.clientHeight) / 2;

    
   /* // Force simulation
    const simulation = d3.forceSimulation(nodes)
        .force("link", d3.forceLink(processedLinks).id(d => d.idType).distance(link => {
          // Retrieve radius values based on node type
          const sourceRadius = getDistance(link.source.type);
          const targetRadius = getDistance(link.target.type);
          // For example, use the sum of the radii multiplied by a scaling factor:
          return (Math.min(sourceRadius, targetRadius)) * (filtered === true?1.5:1);
        })
        )
        .force("charge", d3.forceManyBody().strength(filtered === true? -10:-100))
        .force("center", d3.forceCenter(width / 2, height / 2))
        .force("collide", d3.forceCollide().radius(d => getRadius(d.type) + 10)); // Add collision with a small padding
  */
      // Then, set link force using a distance function that increases with node degree:
    const simulation = d3.forceSimulation(nodes)
    .force("link", d3.forceLink(processedLinks)
        .id(d => d.idType)
        .distance(link => {
            
            return constant*150*scaleFactor.toFixed(1);
        })
        .strength(0.5)  // very low strength so it doesn't override the collision force
    )
    .force("charge", d3.forceManyBody().strength(-5))
    .force("center", d3.forceCenter(width / 2, height / 2))
    .force("collide", d3.forceCollide().radius(d => getRadius(d.type) + 15));

    // Render links
    const link = svg.append("g")
        .selectAll("line")
        .data(processedLinks)
        .enter().append("line")
        .attr("stroke", "#D3D3D3")
        .attr("stroke-width", showLabel===true? 1:0.1);

/*
    // Render nodes
    const node = svg.append("g")
        .selectAll("circle")
        .data(nodes)
        .enter().append("circle")
        .attr("r", d => getRadius(d.type)*(filtered === true?2:1))
        .attr("fill", d => colorScale(d.type))
        .attr("stroke", d => d.isStart ? "#808080" : "none")
        .attr("stroke-width", d => d.isStart ? 2 : 0)
        .on("dblclick", (event, d) => {
            let targetUrl = "";
            // Build the URL based on the node type.
            switch (d.type) {
              case "Event":
                targetUrl = "./event.html?id=" + d.id;
                break;
              case "Lead":
                targetUrl ="./crm-detail.html?leadid=" + d.id;
                break;
              case "Ticket":
                targetUrl = "./helpdesk-detail.html?leadid=" + d.id;
                break;
              case "Activity":
                targetUrl =  "./project-activity.html?activityid=" + d.id;
                break;
              default:
                // For other types, you might not want to open a link.
                return;
            }
            window.open(targetUrl, "_blank");
          });

    // Render labels
    const label = svg.append("g")
        .selectAll("text")
        .data(nodes)
        .enter().append("text")
        .text(d => d.name)
        .attr("dx", d => getRadius(d.type) + 0)
        .attr("dy", ".35em")
        .attr("fill", "#333")
        .style("font-size", filtered === true?"12px":"8px");

    // Update positions
    simulation.on("tick", () => {
        // Update links
        link
            .attr("x1", d => d.source.x)
            .attr("y1", d => d.source.y)
            .attr("x2", d => d.target.x)
            .attr("y2", d => d.target.y);
    
        // Constrain nodes to the svg area
        node
            .attr("cx", d => {
                // Ensure the node stays within the bounds considering its radius
                d.x = Math.max(getRadius(d.type), Math.min(width - getRadius(d.type), d.x));
                return d.x;
            })
            .attr("cy", d => {
                d.y = Math.max(getRadius(d.type), Math.min(height - getRadius(d.type), d.y));
                return d.y;
            });
    
        // Update labels accordingly
        label
            .attr("x", d => d.x + getRadius(d.type) + 2)
            .attr("y", d => d.y);
    });
    
    

    // Drag behavior
    const drag = d3.drag()
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended);

    node.call(drag);
*/
// Replace your current node and label rendering with this:

// Create a group for each node that will contain both the circle and its label.
const nodeGroup = svg.append("g")
    .selectAll("g")
    .data(nodes)
    .enter().append("g")
    .attr("class", "nodeGroup")
    .on("dblclick", (event, d) => {
        let targetUrl = "";
        // Build the URL based on the node type.
        switch (d.type) {
            case "Event":
                targetUrl = "./event.html?id=" + d.id;
                break;
            case "Lead":
                targetUrl = "./crm-detail.html?leadid=" + d.id;
                break;
            case "Ticket":
                targetUrl = "./helpdesk-detail.html?leadid=" + d.id;
                break;
            case "Activity":
                targetUrl = "./project-activity.html?activityid=" + d.id;
                break;
            default:
                return;
        }
        window.open(targetUrl, "_blank");
    })
    .on("mouseover", function(event, d) {
        // Show label on hover
        d3.select(this).select("text").style("opacity", 1);
    })
    .on("mouseout", function(event, d) {
        // Hide label when not hovered
        d3.select(this).select("text").style("opacity", showLabel ===true? 0.2:0);
    });

// Append circle to each node group
// After you have your nodes array:

nodeGroup.append("circle")
    .attr("r", d => getRadius(d.type))
    .attr("fill", d => colorScale(d.type))
    .attr("stroke", d => d.isStart ? "#808080" : "none")
    .attr("stroke-width", d => d.isStart ? 2 : 0);

// Append text label to each node group, hidden by default
nodeGroup.append("text")
    .text(d => d.name)
    .attr("dx", d => getRadius(d.type)+5)
    .attr("dy", ".35em")
    .attr("fill", "#333")
    .style("font-size", filtered === true ? "12px" : "8px")
    .style("opacity", showLabel ===true? 0.2:0)
    .style("pointer-events", "none"); // initially hidden

// Update positions in simulation tick: update the group transform.
simulation.on("tick", () => {
    // Update link positions
    link
        .attr("x1", d => d.source.x)
        .attr("y1", d => d.source.y)
        .attr("x2", d => d.target.x)
        .attr("y2", d => d.target.y);

    // Constrain node positions and update node groups
    nodeGroup.each(d => {
            // Clamp x and y so nodes remain within the SVG area.
            const r = getRadius(d.type);
            d.x = Math.max(r, Math.min(width - r, d.x));
            d.y = Math.max(r, Math.min(height - r, d.y));
        })
        .attr("transform", d => `translate(${d.x}, ${d.y})`);
});

// Also, update the drag behavior to work with the node groups:
nodeGroup.call(d3.drag()
    .on("start", dragstarted)
    .on("drag", dragged)
    .on("end", dragended));

    function dragstarted(event, d) {
        if (!event.active) simulation.alphaTarget(0.15).restart();
        d.fx = d.x;
        d.fy = d.y;
    }

    function dragged(event, d) {
        d.fx = event.x;
        d.fy = event.y;
    }

    function dragended(event, d) {
        if (!event.active) simulation.alphaTarget(0);
        d.fx = null;
        d.fy = null;
    }

}