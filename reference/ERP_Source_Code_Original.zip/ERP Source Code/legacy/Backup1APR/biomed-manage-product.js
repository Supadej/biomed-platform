const urlParams = new URLSearchParams(window.location.search);
const id = urlParams.get('id');

function usersModal() {

    var multiSelectModal = new bootstrap.Modal("#multiSelectModal", {focus: true});
    multiSelectModal.show();
}
window.onload = function() {

    if (!id) {
        xalert("No id please check your url",1,null);
        return;
    }
    
    // Make a request to biomedapi/products/{id} with XHR and token
    getProductById(id, function(error, product) {
        if (error) {
            console.error('Failed to retrieve product:', error);
            xalert("Failed to retrieve product", 1, null);
            return;
        }
        document.getElementById('productName').value = product.Name;
        document.getElementById('productDescription').value = product.Description;
        // Do something with the product data
        getSaleAreas(function(error, saleAreas) {
            if(error) {
                console.error('Failed to retrieve sale areas:', error);
                xalert("Failed to retrieve sale areas", 1, null);
                return;
            }
            const saleAreasBox = document.getElementById('SaleAreaList');
            saleAreas.forEach(function(saleArea) {
                console.log(saleArea);
                const saleAreaBox = document.createElement('div');
                saleAreaBox.style = "min-height:280px;";
                saleAreaBox.classList.add('m-0','my-2','p-0','row');
                saleAreaBox.innerHTML = `<div class="m-0 p-0 col-1 py-auto px-auto border rounded-start-2 bg-light" style="max-width: 40px;">
                                                <h4 class="m-0 p-1 px-2 align-middle text-rotate-270-big text-center text-nowrap border rounded bg-light-subtle" style="width: fit-content;height: fit-content;">${saleArea.Name}</h4>
                                            </div>
                                            <div class="m-0 p-0 py-2 overflow-x-scroll d-flex flex-nowrap col border-top border-bottom w-100" id="areaBox${saleArea.Id}">
                                                
                                                
                                            </div>
                                    
                                            <div class="m-0 p-0 col-1 py-auto px-auto border bg-light rounded-end-2 text-center align-middle py-auto" style="max-width: 40px;">
                                                <span class="p-0 m-1 fs-3 my-auto" onclick="createNewTarget(${saleArea.Id},'${saleArea.Name}')">
                                                &#10010;
                                                </span>
                                        </div>
                                        `;
                saleAreasBox.appendChild(saleAreaBox);
                var query = {
                    ProductIDs: [id],
                    SaleAreaIDs: [saleArea.Id]
                }
                getTargets(function(error, targets){
                    if(error){
                        console.error('Failed to retrieve targets:', error);
                        xalert("Failed to retrieve targets", 1, null);
                        return;
                    }
                    console.log(targets);
                    targets.forEach(function(target){
                        createNewTarget(saleArea.Id,saleArea.Name,target.Id,target);
                    });
                },query);


                

            });

        },true);
    });
}


function saveGroup()
{
    const data = {
        Name: document.getElementById('productName').value,
        id: id,
        Description: document.getElementById('productDescription').value
    };

    updateProduct(data, function(error, response) {
        if (error) {
            console.error('Failed to update product:', error);
            xalert("Failed to update product",1,null);
            return;
        }
        // Handle successful update
        console.log('product updated successfully:', response);
        xalert("product updated successfully",0,null);
    });

}

function updateProduct(data, callback) {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url+ '/biomedapi/products/update');
    xhr.setRequestHeader('Authorization', `Bearer ${readToken()}`);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onload = function() {
        if (xhr.status === 200) {
            callback(null, xhr.responseText);
        } else {
            callback('Failed to update product', null);
        }
    };
    xhr.onerror = function() {
        callback('Failed to send request', null);
    };
    xhr.send(JSON.stringify(data));
}

function deleteProduct() {
    const confirmation = confirm("Are you sure you want to delete this product?");
    if (confirmation) {
        const xhr = new XMLHttpRequest();
        xhr.open('POST', url + '/biomedapi/products/delete');
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.setRequestHeader('Authorization', `Bearer ${readToken()}`);
        xhr.onload = function() {
            if (xhr.status === 200) {
                xalert("Product deleted successfully", 0, null);
            } else {
                xalert("Failed to delete product", 1, null);
            }
        };
        xhr.onerror = function() {
            xalert("Failed to send request", 1, null);
        };
        xhr.send(JSON.stringify({id: id}));
    }
}
let internalCounter = 0;
function createNewTarget(boxId, saleAreaName, id = "New",target= null){
    internalCounter++;
    const areaBox = document.getElementById('areaBox'+boxId);
    
    const newTarget = document.createElement('div');
    newTarget.id = "miniBox"+internalCounter;
    newTarget.classList.add('m-0','p-0','border','flex-shrink-0','mx-2');
    newTarget.style = "max-width: 430px;";
    newTarget.targetId = id;
    newTarget.innerHTML = `
        <h6 class="m-2 p-0">${saleAreaName} #${id} <span class="float-end m-0 p-0 mx-2 text-danger" onclick="deleteTargetRequest('${id}',${internalCounter})">&#10006;</span><span class="float-end m-0 p-0 mx-2 text-success" onclick="createNewTargetRequest('${id}','${internalCounter}',${boxId},'${saleAreaName}')">&#10004;</span></h6>
        <div class="input-group input-group-sm m-2 p-0 w-auto">
            <span class="input-group-text" style="width: 120px;" id="inputGroup-sizing-sm">Target Note</span>
            <input type="text" class="form-control" aria-label="Target Note" aria-describedby="inputGroup-sizing-sm" id="note${internalCounter}">
        </div>
        <div class="input-group input-group-sm my-0 mx-2 p-0 w-auto">
            <span style="width: 120px" class="input-group-text my-2">Start Date</span>
            <input type="datetime-local" id="targetStartDate${internalCounter}" class="form-control my-2" style="min-width: fit-content;" aria-label="StartDate" aria-describedby="modalStartDate"/>
            <span style="width: 120px" class="input-group-text my-2" >End Date</span>
            <input type="datetime-local" id="targetEndDate${internalCounter}" class="form-control my-2" style="min-width: fit-content;" aria-label="EndDate" aria-describedby="modalEndDate"/>
        </div>
        <div class="input-group input-group-sm m-2 w-auto" id="QuarterYear${internalCounter}">
            <span style="min-width: fit-content; width: 120px" class="input-group-text" id="">Auto Date</span>
            <input type="radio" class="btn-check" internalValue="Q1" name="CreationQuarter" id="${internalCounter}CreationQuarter1" autocomplete="off">
            <label class="btn btn-outline-secondary" for="${internalCounter}CreationQuarter1" onclick="ChangeQ(1,${internalCounter})">Q1</label>
            <input type="radio" class="btn-check" internalValue="Q2" name="CreationQuarter" id="${internalCounter}CreationQuarter2" autocomplete="off">
            <label class="btn btn-outline-secondary" for="${internalCounter}CreationQuarter2" onclick="ChangeQ(2,${internalCounter})">Q2</label>
            <input type="radio" class="btn-check" internalValue="Q3" name="CreationQuarter" id="${internalCounter}CreationQuarter3" autocomplete="off">
            <label class="btn btn-outline-secondary" for="${internalCounter}CreationQuarter3" onclick="ChangeQ(3,${internalCounter})">Q3</label>
            <input type="radio" class="btn-check" internalValue="Q4" name="CreationQuarter" id="${internalCounter}CreationQuarter4" autocomplete="off">
            <label class="btn btn-outline-secondary" for="${internalCounter}CreationQuarter4" onclick="ChangeQ(4,${internalCounter})">Q4</label>
            <span style="width: 20px" class="input-group-text p-0 m-0 btn btn-secondary" onclick="clearRadioSelection(this,${internalCounter})" id=""><p class="m-0 p-0 text-rotate-270 fw-bold">Clear</p></span>

            <input type="radio" class="btn-check" internalValue="24" name="CreationFY" id="${internalCounter}CreationFY24" autocomplete="off">
            <label class="btn btn-outline-secondary" for="${internalCounter}CreationFY24" onclick="ChangeY('24',${internalCounter})">Y24</label>
            <input type="radio" class="btn-check" internalValue="25" name="CreationFY" id="${internalCounter}CreationFY25" autocomplete="off">
            <label class="btn btn-outline-secondary" for="${internalCounter}CreationFY25" onclick="ChangeY('25',${internalCounter})">Y25</label>
            <input type="radio" class="btn-check" internalValue="26" name="CreationFY" id="${internalCounter}CreationFY26" autocomplete="off">
            <label class="btn btn-outline-secondary" for="${internalCounter}CreationFY26" onclick="ChangeY('26',${internalCounter})">Y26</label>
        </div>
        <div class="input-group input-group-sm m-2 p-0 w-auto">
            <span class="input-group-text" style="width: 120px;" id="inputGroup-sizing-sm">Target</span>
            <input type="number" class="form-control" aria-label="Target" aria-describedby="inputGroup-sizing-sm" id="targetValue${internalCounter}">
        </div>
    `;

    areaBox.insertBefore(newTarget, areaBox.firstChild);
    const note = document.getElementById('note'+internalCounter);
    const startDate = document.getElementById('targetStartDate'+internalCounter);
    const endDate = document.getElementById('targetEndDate'+internalCounter);
    const targetValue = document.getElementById('targetValue'+internalCounter);
    if(target == null){
        note.value = "";
        startDate.value = timeFuck(new Date().toISOString().split("T")[0] + "T00:00");
        endDate.value = timeFuck( new Date().toISOString().split("T")[0] + "T23:59");
        targetValue.value = 0;
    }else{
        note.value = target.Name;
        startDate.value = timeFuck(target.StartDate);
        endDate.value = timeFuck(target.EndDate);
        targetValue.value = target.TargetValue;
    
    }


}

function ChangeQ (q, internalCounter){

    const startDate = document.getElementById('targetStartDate'+internalCounter);
    const endDate = document.getElementById('targetEndDate'+internalCounter);


    const quarterYearElement = document.getElementById('QuarterYear' + internalCounter);
    const selectedQuarter = quarterYearElement.querySelector('input[name="CreationQuarter"]:checked');
    const selectedFY = quarterYearElement.querySelector('input[name="CreationFY"]:checked');
    let quarterValue = selectedQuarter ? selectedQuarter.getAttribute('internalValue') : null;
    let fyValue = selectedFY ? selectedFY.getAttribute('internalValue') : null;

    if (!selectedQuarter) {
        const defaultQuarter = document.getElementById(internalCounter+'CreationQuarter'+q);
        defaultQuarter.checked = true;
        quarterValue = 'Q'+q;
    }
    if (!selectedFY) {
        const defaultFY = document.getElementById(internalCounter+'CreationFY25');
        defaultFY.checked = true;
        fyValue = '25';
    }

    const dateRange =  getQuarterDateRange(q, fyValue);
    startDate.value = timeFuck(dateRange.startDate);
    endDate.value = timeFuck(new Date(dateRange.endDate).getTime()/* + (23 * 60 * 60 * 1000) + (59 * 60 * 1000)*/);
    console.log("StartDate", startDate.value);
    console.log("EndDate",endDate.value);
    console.log('Selected quarter:', q);
    console.log('Selected FY:', fyValue);

}

function ChangeY(y, internalCounter) {
    const startDate = document.getElementById('targetStartDate'+internalCounter);
    const endDate = document.getElementById('targetEndDate'+internalCounter);


    const quarterYearElement = document.getElementById('QuarterYear' + internalCounter);
    const selectedQuarter = quarterYearElement.querySelector('input[name="CreationQuarter"]:checked');
    const selectedFY = quarterYearElement.querySelector('input[name="CreationFY"]:checked');
    let quarterValue = selectedQuarter ? selectedQuarter.getAttribute('internalValue') : null;
    let fyValue = selectedFY ? selectedFY.getAttribute('internalValue') : null;

    if (!selectedQuarter) {
        const defaultQuarter = document.getElementById(internalCounter+'CreationQuarter1');
        defaultQuarter.checked = true;
        quarterValue = 'Q1';
    }
    if (!selectedFY) {
        const defaultFY = document.getElementById(internalCounter+'CreationFY25');
        defaultFY.checked = true;
        fyValue = y;
    }

    const dateRange =  getQuarterDateRange(parseInt(quarterValue.replace('Q', '')), y);
    startDate.value = timeFuck(dateRange.startDate);
    endDate.value = timeFuck(new Date(dateRange.endDate).getTime()/* + (23 * 60 * 60 * 1000) + (59 * 60 * 1000)*/);
    console.log("StartDate", startDate.value);
    console.log("EndDate",endDate.value);

    console.log('Selected quarter:', quarterValue);
    console.log('Selected FY:', y);
}

function clearRadioSelection(e,internalCounter) {
    const parentElement = e.parentElement;
    const radioButtons = parentElement.querySelectorAll('input[type="radio"]');
    radioButtons.forEach(radioButton => {
        radioButton.checked = false;
    });
    const startDate = document.getElementById('targetStartDate'+internalCounter);
    const endDate = document.getElementById('targetEndDate'+internalCounter);
    const today = new Date();
    startDate.value = timeFuck(today);
    endDate.value = timeFuck(today);

}

function createNewTargetRequest(targetId,internalCounter, saleAreaId,saleAreaName){
    const startDate = document.getElementById('targetStartDate'+internalCounter).value;
    const endDate = document.getElementById('targetEndDate'+internalCounter).value;
    const targetValue = document.getElementById('targetValue'+internalCounter).value;
    const note = document.getElementById('note'+internalCounter).value;
    const xhr = new XMLHttpRequest();
    if(targetId == "New"||targetId == null||targetId == ""||targetId==undefined){//Create New
        var data = {
            Name:note,
            StartDate: timeFormater(startDate),
            EndDate: timeFormater(endDate),
            TargetValue: targetValue,
            ProductId:id,
            SaleAreaId: saleAreaId
        }
        xhr.open('POST', url + '/biomedapi/targets/create');
    }else{//Update
        var data = {
            Name:note,
            StartDate: timeFormater(startDate),
            EndDate: timeFormater(endDate),
            TargetValue: targetValue,
            Id: targetId
        }
        xhr.open('POST', url + '/biomedapi/targets/update');
    }
    
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', `Bearer ${readToken()}`);
    xhr.onload = function() {
        if (xhr.status === 200) {
            // Handle successful creation
            console.log('target created successfully:', xhr.responseText);
            var miniBox = document.getElementById('miniBox'+internalCounter);
            miniBox.remove();
            response= JSON.parse(xhr.responseText);
            createNewTarget(saleAreaId, saleAreaName, response.Id,response);
            xalert("Target created/update successfully",0,1000);

        } else {
            // Handle error
            console.error('Failed to create target:', xhr.responseText);
            xalert("Failed to create target", 1, null);
        }
    };
    xhr.onerror = function() {
        callback('Failed to send request', null);
    };
    xhr.send(JSON.stringify(data));

}
function deleteTargetRequest(requestId,internalCounter){
    if(requestId == "New"||requestId == null||requestId == ""||requestId==undefined){
        var miniBox = document.getElementById('miniBox'+internalCounter);
        miniBox.remove();
    }else{
        if (confirm("Are you sure you want to delete the target with id: " + requestId + "?")) {
            const xhr = new XMLHttpRequest();
            xhr.open('POST', url + '/biomedapi/targets/delete');
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.setRequestHeader('Authorization', `Bearer ${readToken()}`);
            xhr.onload = function() {
                if (xhr.status === 200) {
                    // Handle successful deletion
                    console.log('Target deleted successfully:', xhr.responseText);
                    var miniBox = document.getElementById('miniBox'+internalCounter);
                    miniBox.remove();
                    xalert("Target deleted successfully", 0, 1000);
                } else {
                    // Handle error
                    console.error('Failed to delete target:', xhr.responseText);
                    xalert("Failed to delete target", 1, null);
                }
            };
            xhr.onerror = function() {
                callback('Failed to send request', null);
            };
            xhr.send(JSON.stringify({ Id: requestId }));
            
        } 
    }
}