const urlParams = new URLSearchParams(window.location.search);
const id = urlParams.get('id');

function usersModal() {

    var multiSelectModal = new bootstrap.Modal("#multiSelectModal", {focus: true});
    multiSelectModal.show();
}
window.onload = function() {

    if (!id) {
        xalert("No id please check your url",1,null);
        return;
    }
    
    // Make a request to biomedapi/products/{id} with XHR and token
    getSaleAreaById(id, function(error, product) {
        if (error) {
            console.error('Failed to retrieve product:', error);
            xalert("Failed to retrieve product", 1, null);
            return;
        }
        document.getElementById('productName').value = product.Name;
        document.getElementById('productDescription').value = product.Description;
        // Do something with the product data
    });

}


function saveGroup()
{
    const data = {
        Name: document.getElementById('productName').value,
        id: id,
        Description: document.getElementById('productDescription').value
    };

    updateProduct(data, function(error, response) {
        if (error) {
            console.error('Failed to update area:', error);
            xalert("Failed to update area",1,null);
            return;
        }
        // Handle successful update
        console.log('area updated successfully:', response);
        xalert("area updated successfully",0,null);
    });

}

function updateProduct(data, callback) {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url+ '/biomedapi/saleareas/update');
    xhr.setRequestHeader('Authorization', `Bearer ${readToken()}`);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onload = function() {
        if (xhr.status === 200) {
            callback(null, xhr.responseText);
        } else {
            callback('Failed to update area', null);
        }
    };
    xhr.onerror = function() {
        callback('Failed to send request', null);
    };
    xhr.send(JSON.stringify(data));
}

function deleteProduct() {
    const confirmation = confirm("Are you sure you want to delete this product?");
    if (confirmation) {
        const xhr = new XMLHttpRequest();
        xhr.open('POST', url + '/biomedapi/saleareas/delete');
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.setRequestHeader('Authorization', `Bearer ${readToken()}`);
        xhr.onload = function() {
            if (xhr.status === 200) {
                xalert("Area deleted successfully", 0, null);
            } else {
                xalert("Failed to delete area", 1, null);
            }
        };
        xhr.onerror = function() {
            xalert("Failed to send request", 1, null);
        };
        xhr.send(JSON.stringify({id: id}));
    }
}