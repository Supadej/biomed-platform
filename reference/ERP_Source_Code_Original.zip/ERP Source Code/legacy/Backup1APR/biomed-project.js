var pipelineCache = [];
var pipelineIdCache = null;

function editpipeline(pipelineId) {
    createProjectModal(pipelineId);
}

function deletepipeline(pipelineId) {

    createProjectModal(pipelineId,true);

}

function createProjectModal(pipelineId = null, deletePipeline = false) {
    // Create the modal element
    pipelineIdCache = pipelineId;
    const modal = document.createElement('div');
    modal.id = 'pipelineModal';
    
    modal.classList.add('modal', 'fade');
    modal.setAttribute('tabindex', '-1');
    modal.setAttribute('role', 'dialog');

    // Create the modal dialog element
    const modalDialog = document.createElement('div');
    modalDialog.classList.add('modal-dialog');
    modal.appendChild(modalDialog);

    // Create the modal content element
    const modalContent = document.createElement('div');
    modalContent.classList.add('modal-content');
    modalDialog.appendChild(modalContent);

    // Create the modal header element
    const modalHeader = document.createElement('div');
    modalHeader.classList.add('modal-header');
    modalContent.appendChild(modalHeader);

    // Create the modal title element
    const modalTitle = document.createElement('h5');
    modalTitle.classList.add('modal-title');
    modalTitle.textContent = 'Add Project';
    if (pipelineId) {
        modalTitle.textContent = 'Edit Project';
    }
    if (deletePipeline) {
        modalTitle.textContent = 'Are you sure you want to delete this project (Please make sure that you delete all contents in this project)?';
    }
    modalHeader.appendChild(modalTitle);

    // Create the close button element
    const closeButton = document.createElement('button');
    closeButton.setAttribute('type', 'button');
    closeButton.classList.add('btn-close');
    closeButton.setAttribute('data-bs-dismiss', 'modal');
    closeButton.setAttribute('aria-label', 'Close');
    closeButton.addEventListener('click', removeModalPopup );
    modalHeader.appendChild(closeButton);

    // Create the modal body element
    const modalBody = document.createElement('div');
    modalBody.classList.add('modal-body');
    modalContent.appendChild(modalBody);

    // Create the text input element
    const inputGroup = document.createElement('div');
    inputGroup.classList.add('input-group', 'input-group-sm', 'mb-3');
    modalBody.appendChild(inputGroup);

    const inputGroupText = document.createElement('span');
    inputGroupText.classList.add('input-group-text');
    inputGroupText.style.width = '60px';
    inputGroupText.textContent = 'Title';
    inputGroup.appendChild(inputGroupText);

    const input = document.createElement('input');
    input.setAttribute('type', 'text');
    input.classList.add('form-control');
    input.setAttribute('aria-label', 'Sizing example input');
    input.setAttribute('aria-describedby', 'inputGroup-sizing-sm');
    input.id = 'pipelineTitle';
    if (pipelineId) {
        const pipeline = pipelineCache.find(pipeline => pipeline.Id === pipelineId);
        input.value = pipeline.Name;
        //input2.value = pipeline.Order;
    }
    if (deletePipeline) {
        input.readOnly = true;
    }
    inputGroup.appendChild(input);

    // Create the input group element
    const inputGroup2 = document.createElement('div');
    inputGroup2.classList.add('input-group', 'input-group-sm', 'mb-3');
    modalBody.appendChild(inputGroup2);

    const inputGroup2Text = document.createElement('span');
    inputGroup2Text.classList.add('input-group-text');
    inputGroup2Text.style.width = '100px';
    inputGroup2Text.textContent = 'Description';
    inputGroup2.appendChild(inputGroup2Text);

    const addButton = document.createElement('button');
    addButton.textContent = 'Add';

    const input2 = document.createElement('input');
    input2.setAttribute('type', 'text');
    input2.classList.add('form-control');
    input2.setAttribute('aria-label', 'Sizing example input');
    input2.setAttribute('aria-describedby', 'inputGroup-sizing-sm');
    input2.id = 'pipelineOrder';
    if (pipelineId) {
        const pipeline = pipelineCache.find(pipeline => pipeline.Id === pipelineId);
        input2.value = pipeline.Description;
        addButton.textContent = 'Update';
    }
    if (deletePipeline) {
        input2.readOnly = true;
        addButton.textContent = 'Delete';
        addButton.classList.add('btn', 'btn-danger');
        addButton.addEventListener('click', function() {
            deletePipelineRequest(pipelineId);
            removeModalPopup();
        });
    }else{
        addButton.classList.add('btn', 'btn-primary');
        addButton.setAttribute('data-bs-dismiss', 'modal');
        addButton.setAttribute('aria-label', 'Close');
        addButton.addEventListener('click', createCRMPipeline);
    }
    inputGroup2.appendChild(input2);
    
    modalBody.appendChild(addButton);

    // Append the modal to the document body

    document.body.appendChild(modal);
    var crmModal = new bootstrap.Modal("#pipelineModal", {focus: true});
    crmModal.show();
}


function createCRMPipeline(){
    createPipelineRequest(pipelineIdCache);
    removeModalPopup();
}


function deletePipelineRequest(pipelineId) {
    const token = readToken();
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url + '/biomedapi/projects/delete', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Request successful
                xalert('Pipeline deleted successfully', 0, -1);
                setTimeout(function() {
                    location.reload();
                }, 2000);
            } else {
                // Request failed
                xalert('Error ' + xhr.status + " " + xhr.responseText, 1, -1);
            }
        }
    };
    const data = JSON.stringify({Id: pipelineId});
    xhr.send(data);

}

function createPipelineRequest(pipelineId = null) {
    const token = readToken();
    const name = document.getElementById('pipelineTitle').value;
    const order = document.getElementById('pipelineOrder').value;


    const xhr = new XMLHttpRequest();
    if (pipelineId) {
        xhr.open('POST', url+ '/biomedapi/projects/update', true);
    } else {
        xhr.open('POST', url+ '/biomedapi/projects/create', true);
    }
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Request successful
                xalert('Pipeline created/updated successfully',0,-1);
                setTimeout(function() {
                    location.reload();
                }, 2000);
                
            } else {
                // Request failed
                xalert('Error '+xhr.status+" "+xhr.responseText,1,-1);
                
            }
        }
    };
    let rawdata = {
        Name: name,
        Description: order
    };
    if (pipelineId) {
        rawdata.Id = pipelineId;
    }   
    
    const data = JSON.stringify(rawdata);
    console.log(data);
    xhr.send(data);
}


function removeModalPopup() {
    document.getElementById('pipelineModal').remove();
    pipelineIdCache = null;
}

window.onload = function() {
    getProjects((err, projects) => {
        if (err) {
            xalert('Error ' + err, 1, -1);
            return;
        }
        pipelineCache = projects;
        const container = document.getElementById('projectContainer');
        projects.forEach(project => {
            const card = document.createElement('div');
            card.classList.add('card', 'm-3');
            card.style.width = '300px';

            const cardBody = document.createElement('div');
            cardBody.classList.add('card-body');
            card.appendChild(cardBody);

            const cardTitle = document.createElement('h5');
            cardTitle.classList.add('card-title');
            cardTitle.textContent = project.Name;
            cardBody.appendChild(cardTitle);

            const cardText = document.createElement('p');
            cardText.classList.add('card-text','mb-5');
            cardText.textContent = project.Description;
            cardBody.appendChild(cardText);


            const cardLink = document.createElement('a');
            cardLink.classList.add('btn', 'btn-primary' ,"bottom-0" ,"start-0","m-1");
            cardLink.href = './project-overview.html?projectId=' + project.Id;
            cardLink.textContent = 'View';

            const editButton = document.createElement('button');
            editButton.classList.add('btn', 'btn-primary' ,"bottom-0" ,"start-0","m-1");
            editButton.textContent = 'Edit';
            editButton.addEventListener('click', function() {
                editpipeline(project.Id);
            });

            const deleteButton = document.createElement('button');
            deleteButton.classList.add('btn', 'btn-danger', 'bottom-0', 'start-0', 'm-1');
            deleteButton.textContent = 'Delete';
            deleteButton.addEventListener('click', function() {
                deletepipeline(project.Id);
            });

            

            const cardFooter = document.createElement('div');
            cardFooter.classList.add("m-0","p-2");
            cardFooter.classList.add('card-footer');
            
            
            cardFooter.appendChild(cardLink);
            cardFooter.appendChild(editButton);
            cardFooter.appendChild(deleteButton);
            card.appendChild(cardFooter);

            container.appendChild(card);

        });

    },true);
};