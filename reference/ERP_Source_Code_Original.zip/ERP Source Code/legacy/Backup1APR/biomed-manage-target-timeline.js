google.charts.load("current", {packages:["timeline"]});
var container = document.getElementById('targetTimeline');
google.charts.setOnLoadCallback(drawChart);

var charter;
function drawChart() {
var chart = new google.visualization.Timeline(container);
charter = chart;
var dataTable = new google.visualization.DataTable();
dataTable.addColumn({ type: 'string', id: 'Area' });
dataTable.addColumn({ type: 'string', id: 'Title' });
dataTable.addColumn({ type: 'string', role: 'tooltip' });
dataTable.addColumn({ type: 'date', id: 'Start' });
dataTable.addColumn({ type: 'date', id: 'End' });

// Get the targets for the product assume that id is the product id (from other script)
var queryProduct = {ProductIDs: [id]};
getTargets((err, targets) => {
    if (err) {
        console.log(err);
        xalert('Error Failed to get targets',1,-1);
        return;
    }
    Promise.all(targets.map((target) => {
        return getSaleAreaById(target.SaleAreaID)
            .then((saleArea) => {
                dataTable.addRows([[saleArea.Name,"["+target.Name+"]"+target.TargetValue,`<div class="m-0 p-2"> <h6>${saleArea.Name}</h6> <p class="m-0 my-1 p-0 text-nowrap">${target.TargetValue} THB</p> <p class="m-0 my-1 p-0 text-nowrap">Start ${timeFriendly(target.StartDate)}</p> <p class="m-0 my-1 p-0 text-nowrap">End ${timeFriendly(target.EndDate)}</p> </div>`,new Date(timeFormater(target.StartDate)),new Date(timeFormater(target.EndDate))]]);
            })
            .catch((err) => {
                console.log(err);
                xalert('Error Failed to get sale area',1,-1);
            });
    })).then(() => {
        var options = {
            timeline: { colorByRowLabel: true }
        };
        
        if (dataTable.getNumberOfRows() == 0) {
            dataTable.addRows([["No Targets","No Targets","This is just a placeholder",new Date(new Date().getFullYear(), 0, 1),new Date(new Date().getFullYear(), 11, 31)]]);
        }
        chart.draw(dataTable, options);
    });


},queryProduct);



}

function reloadTimeline(){
    charter.clearChart();
    drawChart();
}