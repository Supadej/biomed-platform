import json
import re

# Initialize an empty dictionary to store the colors
colors = {}

# Open the colorsList.txt file
with open('Y:\\Biomed2.0\\web\\colorsList.txt', 'r') as f:
    # Initialize the current color category
    color_category = None

    # Iterate over each line in the file
    for line in f:
        # If the line contains "Color Names", it's a new color category
        if "Color Names" in line:
            color_category = line.split(" ")[0].lower()
            colors[color_category] = []
        # If the line contains a hex code, it's a color
        elif re.search(r'#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})', line):
            color_name, color_code = line.strip().split(' #')
            if color_category is not None:
                colors[color_category].append({'name': color_name, 'code': '#' + color_code})

# Write the colors dictionary to a new JSON file
with open('colors.json', 'w') as f:
    json.dump(colors, f, indent=4)