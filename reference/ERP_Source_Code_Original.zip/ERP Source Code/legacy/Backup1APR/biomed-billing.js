var billingTable = $("#billingTable");
var billingModal = new bootstrap.Modal(document.getElementById("billingModal"));
var billingModalCache = document.getElementById("billingModal");
var currentBilling = null;
var billingName = document.getElementById("billingName");
var billingEmail = document.getElementById("billingEmail");
var billingAddress = document.getElementById("billingAddress");
var billingPhone = document.getElementById("billingPhone");
var billingPosition = document.getElementById("billingTaxID");
var masterBillings = [];
const mainContactSelect = document.getElementById("mainContactsSelecter");

billingModalCache.addEventListener('hidden.bs.modal', function () {
    clearModal();
    console.log('Modal closed');
});

function clearModal() {
    billingName.value = '';
    billingEmail.value = '';
    billingAddress.value = '';
    billingPhone.value = "";
    billingPosition.value = "";
    currentBilling = null;
    console.log('Modal cleared');
}

function deleteBilling() {
    var billingId = currentBilling.Id;
    var xhr = new XMLHttpRequest();
    var urlx = url+'/biomedapi/billinginformations/delete';
    var method = 'POST';

    xhr.open(method, urlx, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', 'Bearer ' + readToken());

    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                console.log('Billing deleted successfully');
                xalert('Billing deleted successfully', 0, 5000);
                billingTable.bootstrapTable('remove', {field: 'id', values: [billingId]});
                masterBillings = masterBillings.filter(function(billing) {
                    return billing.Id !== billingId;
                });
            } else {
                console.error('Error deleting billing:', xhr.responseText);
                xalert('Error deleting billing', 1, -1);
            }
        }
    };

    xhr.send(JSON.stringify({id: billingId}));
    clearModal();
    billingModal.hide();
}

function callBilling() {
    billingTable.bootstrapTable('hideColumn', 'id');
    getBillings((err, billings) => {
        if (err) {
            console.error(err);
            xalert("Error loading billings", 1, -1);
            return;
        }
        console.log(billings);
        masterBillings = billings;

        

        var transformedBillings = billings.map(function(billing) {
            return {
                id: billing.Id || null,
                ContactName: billing.ContactId || null,
                Name: billing.Name || null,
                Email: billing.Email || null,
                Address: billing.Address || null,
                Phone: billing.Phone || null,
                TaxID: billing.TaxID || null
            };
        });
        billingTable.bootstrapTable('load', transformedBillings);
        console.log(transformedBillings);
    }, true);


    mainContactSelect.innerHTML = "";
    getContacts((err, contacts) => {
        if (err) {
          console.error("Failed to fetch users:", err);
          xalert("Failed to fetch users:" + err, 1, null);
          return;
        }
        
        contacts.forEach((contact) => {
          const mainOption = document.createElement("option");
          mainOption.value = contact.Id;
          mainOption.textContent = contact.Name;
          if (contact.Position !== null && contact.Position !== undefined) {
            mainOption.setAttribute("data-subtext", `${contact.Position}`);
          }
          mainContactSelect.appendChild(mainOption);
        });
        
        $(mainContactSelect).selectpicker('refresh');
    });


}

var ContactsDummy = [];
getContacts((err, contacts) => {
    if (err) {
        console.error("Failed to fetch users:", err);
        xalert("Failed to fetch users:" + err, 1, null);
        return;
    }
    ContactsDummy =  contacts;
    
}, false);


function contactParse(value, row, index) {
    var contact = ContactsDummy.find(function(c) {
        return c.Id === value;
    });
    return contact ? contact.Name : '';


}


function operateBillingFormatter(value, row, index) {
    return [
        '<a class="edit text-primary link link-underline link-underline-opacity-0" href="javascript:void(0)" title="Edit">',
        '<i class="fi fi-rr-edit"></i>',
        '</a>  '
    ].join('');
}

function editBilling(e, value, row, index) {
    console.log('You click edit icon, row: ', row);

    var foundBilling = masterBillings.find(function(billing) {
        return billing.Id === row.id;
    });

    if (foundBilling) {
        billingName.value = foundBilling.Name || '';
        billingEmail.value = foundBilling.Email || '';
        billingAddress.value = foundBilling.Address || '';
        billingPhone.value = foundBilling.Phone || '';
        billingPosition.value = foundBilling.TaxID || '';
        
        currentBilling = foundBilling;
        currentBilling.index = index;
        billingModal.show();
    } else {
        console.log('Billing not found');
    }
}

var operateBillingEvents = {
    'click .edit': editBilling
};

function tableBillingButtons() {
    return {
        btnUsersAdd: {
            text: 'Add new billing',
            icon: 'fi-rr-add',
            event: function () {
                billingModal.show();
            },
            attributes: {
                title: 'Add new billing'
            }
        }
    };
}

function addBilling() {
    var billing = {

        contactID: parseInt(mainContactSelect.value) || null,
        ContactName : parseInt(mainContactSelect.value) || null,
        Name: billingName.value || null,
        Email: billingEmail.value || null,
        Address: billingAddress.value || null,
        Phone: billingPhone.value || null,
        TaxID: billingPosition.value || null
    };

    if (currentBilling !== null) {
        billing.Id = currentBilling.Id;
        billing.id = currentBilling.Id;
        billing.index = currentBilling.index;
    }
    

    addBillingRequest(billing);
    billingModal.hide();
}

function addBillingRequest(billing) {
    var xhr = new XMLHttpRequest();
    var urlx = billing.Id ? '/biomedapi/billinginformations/update' : '/biomedapi/billinginformations/create';
    var method = 'POST';

    xhr.open(method, url + urlx, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', 'Bearer ' + readToken());

    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                console.log('Billing added/updated successfully');
                xalert('Billing added/updated successfully', 0, 5000);
                if (billing.Id) {
                    billingTable.bootstrapTable('updateRow', {index: billing.index, row: billing});
                } else {
                    billing.id = parseInt(xhr.responseText);
                    billing.Id = parseInt(xhr.responseText);
                    billingTable.bootstrapTable('append', billing);
                    masterBillings.push(billing);
                }
                getBillings((err, billings) => {
                    if (err) {
                        console.error(err);
                        xalert("Error loading billings", 1, -1);
                        return;
                    }
                    console.log("Force Update Billing", billings);
                }, true);
            } else {
                console.error('Error adding/updating billing:', xhr.responseText);
                xalert('Error adding/updating billing', 1, -1);
            }
        }
    };

    xhr.send(JSON.stringify(billing));
}

