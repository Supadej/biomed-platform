var pipelineCache = [];
var pipelineIdCache = null;
let leadCache = [];

var creationslider = document.getElementById('creationslider');
var updateslider = document.getElementById('updateslider');
var expectedslider = document.getElementById('expectedslider');

function QFormater(value) {
    console.log("input",value,"output",Translator[value]);
    return Translator[value];
};

function QReverser(date) {
    const QnYear = getQuarterAndYearByDate(date);
    const StringQnYear = QnYear.quarter + " " + QnYear.year;
    const index = Translator.indexOf(StringQnYear);
    return index;
}

noUiSlider.create(creationslider, {
    start: [0, Translator.length - 1],
    tooltips: [
        { to: function(value) { return  QFormater(parseInt(value)); } },
        { to: function(value) { return  QFormater(parseInt(value)); } }
    ],
    behaviour: 'tap-drag',
    connect: true,
    step: 1,
    range: {
        'min': 0,
        'max': Translator.length - 1
    }
});


noUiSlider.create(updateslider, {
    start: [0, Translator.length - 1],
    tooltips: [
        { to: function(value) { return  QFormater(parseInt(value)); } },
        { to: function(value) { return  QFormater(parseInt(value)); } }
    ],
    behaviour: 'tap-drag',
    connect: true,
    step: 1,
    range: {
        'min': 0,
        'max': Translator.length - 1
    }
});


noUiSlider.create(expectedslider, {
    start: [QReverser(new Date()), QReverser(new Date())],
    tooltips: [
        { to: function(value) { return  QFormater(parseInt(value)); } },
        { to: function(value) { return  QFormater(parseInt(value)); } }
    ],
    behaviour: 'tap-drag',
    connect: true,
    step: 1,
    range: {
        'min': 0,
        'max': Translator.length - 1
    }
});

function editpipeline(pipelineId) {
    createModalPopup(pipelineId);
}

function deletepipeline(pipelineId) {

    createModalPopup(pipelineId,true);

}

function getUniqueLeads(leads) {
    const uniqueLeads = leads.reduce((acc, lead) => {
        if (!acc.some(existingLead => existingLead.Id === lead.Id)) {
            acc.push(lead);
        }
        return acc;
    }, []);
    return uniqueLeads;
}

async function targetDisplay(saleId = null, productId = null,start = null, end = null) {

    const myuser = await promiseMyUser();
    console.log("MyUserOwn",myuser);
    const saleAreaIDs = saleId == null? myuser.SaleAreaUsers.map(saleAreaUser => saleAreaUser.SaleAreaId):saleId;
    const productIDs = productId == null? myuser.ProductUsers.map(productUser => productUser.ProductId):productId;
    console.log("SaleAreaIDs",saleAreaIDs,"ProductIDs",productIDs);
    var startDate = new Date();
    startDate.setMonth(startDate.getMonth() - 4);
    var endDate = new Date();
    endDate.setMonth(endDate.getMonth() + 4);
    console.log("Target Start Date",start,"Target End Date",end);
    var query = {
        SaleAreaIDs: saleAreaIDs, 
        ProductIDs: productIDs, 
        ExpectedStart:start == null?null:timeFormater(start), 
        ExpectedEnd:end == null?null:timeFormater(end), 
        DeepSearch: true};
    console.log("Target Query",query);



    const targetsContainer = document.getElementById('targetsContainer');
    targetsContainer.innerHTML = '';
    const targets = await promiseTargets(query);
    
    const sortedTargets = await processTargets(targets);
    console.log("Sorted Ready Targets",sortedTargets);
    targetsContainer.innerHTML = '';

    for (const target of sortedTargets) {
        console.log("Leads", target.Leads);

        const uniqueLeads = getUniqueLeads(target.Leads);
        console.log("Unique Leads", uniqueLeads);
        const sumLeads = target.Leads.reduce((total, lead) => total + lead.ExpectedRevenue, 0);
        console.log("Sum of Leads Expected Revenue:", sumLeads);
        const sumAchieved = target.Leads.reduce((total, lead) => total + lead.AchivedRevenue, 0);
        console.log("Sum of Leads Achieved Revenue:", sumAchieved);
        const countLeads = target.Leads.length;
        console.log("Count of Leads:", countLeads);

        const div = document.createElement('div');
        div.classList.add('p-1', 'm-1', 'biomed-bordercard', 'flex-shrink-0');
        div.style.borderColor = target.Color.color.code;
        div.style.backgroundColor = 'rgb(255, 255, 255)';

        const h6 = document.createElement('h6');
        h6.classList.add('m-0', 'p-0', 'fw-bold');
        h6.textContent = `${target.Product.Name}-${target.SaleArea.Name} (${target.Name})`;
        div.appendChild(h6);

        const table = document.createElement('table');
        table.classList.add('m-0', 'p-0');

        const rows = [
            { label: 'Target', value: `${AutoComma(target.TargetValue)} THB` },
            { label: 'Expected', value: `${AutoComma(sumLeads)} THB` },
            { label: 'Achieved', value: `${sumAchieved === 0 ? sumAchieved + ' THB (0%)' : AutoComma(sumAchieved) + ' THB (' + Math.round(sumAchieved / target.TargetValue * 100) + '%)'}` },
            { label: 'Date', value: `${formatDateOnly(target.StartDate)} - ${formatDateOnly(target.EndDate)}` },
            { label: 'Remaining', value: getRemainingDays(target.EndDate) },
            { label: 'Count', value: `${countLeads} Leads` }
        ];

        rows.forEach(row => {
            const tr = document.createElement('tr');
            tr.classList.add('m-0', 'p-0', 'bt-sm');

            const thLabel = document.createElement('th');
            thLabel.classList.add('m-0', 'p-0', 'fw-normal');
            thLabel.textContent = row.label;
            tr.appendChild(thLabel);

            const thValue = document.createElement('th');
            thValue.classList.add('fw-bold', 'm-0', 'p-0', 'px-2', 'ms-2');
            thValue.textContent = row.value;
            tr.appendChild(thValue);

            table.appendChild(tr);
        });

        div.appendChild(table);
        div.order = target.order;

        const children = targetsContainer.children;
        let inserted = false;

        if (children.length === 0) {
            targetsContainer.appendChild(div);
            inserted = true;
        } else {
            for (let i = children.length - 1; i >= 0; i--) {
                const child = children[i];
                if (div.order < child.order) {
                    targetsContainer.insertBefore(div, child.nextSibling);
                    inserted = true;
                    break;
                }
            }
        }

        if (!inserted) {
            targetsContainer.insertBefore(div, targetsContainer.firstChild);
        }
    }
    const summaryDiv = document.createElement('div');
    summaryDiv.classList.add('p-1', 'm-1', 'biomed-bordercard', 'flex-shrink-0');
    summaryDiv.style.borderColor = '#000';
    summaryDiv.style.backgroundColor = 'rgb(255, 255, 255)';

    const totalTargets = sortedTargets.reduce((total, target) => total + target.TargetValue, 0);
    const totalExpected = sortedTargets.reduce((total, target) => total + target.Leads.reduce((sum, lead) => sum + lead.ExpectedRevenue, 0), 0);
    const totalAchieved = sortedTargets.reduce((total, target) => total + target.Leads.reduce((sum, lead) => sum + lead.AchivedRevenue, 0), 0);
    const targetsCount = sortedTargets.length;
    const totalLeads = sortedTargets.reduce((total, target) => total + target.Leads.length, 0);
    const achievementPercentage = totalAchieved === 0 ? 0 : Math.round((totalAchieved / totalTargets) * 100);

    const summaryTable = document.createElement('table');
    summaryTable.classList.add('m-0', 'p-0');

    const summaryRows = [
        { label: 'Total Targets', value: AutoComma(totalTargets) + ' THB' },
        { label: 'Total Expected', value: AutoComma(totalExpected) + ' THB' },
        { label: 'Total Achieved', value: AutoComma(totalAchieved) + ' THB (' + achievementPercentage + '%)' },
        { label: 'Targets Count', value: targetsCount + ' Targets' },
        { label: 'Total Leads', value: totalLeads + ' Leads' },
        { label: 'Total Products', value: new Set(sortedTargets.map(target => target.Product.Id)).size + ' Products' },
        { label: 'Total Sale Areas', value: new Set(sortedTargets.map(target => target.SaleArea.Id)).size + ' Sale Areas' }
    ];
    const summaryHeader = document.createElement('h6');
    summaryHeader.classList.add('m-0', 'p-0', 'fw-bold');
    summaryHeader.textContent = 'Targets Summarize';
    summaryDiv.appendChild(summaryHeader);
    summaryRows.forEach(row => {
        const tr = document.createElement('tr');
        tr.classList.add('m-0', 'p-0', 'bt-sm');

        const thLabel = document.createElement('th');
        thLabel.classList.add('m-0', 'p-0', 'fw-normal');
        thLabel.textContent = row.label;
        tr.appendChild(thLabel);

        const thValue = document.createElement('th');
        thValue.classList.add('fw-bold', 'm-0', 'p-0', 'px-2', 'ms-2');
        thValue.textContent = row.value;
        tr.appendChild(thValue);

        summaryTable.appendChild(tr);
    });

    summaryDiv.appendChild(summaryTable);
    targetsContainer.insertBefore(summaryDiv, targetsContainer.firstChild);

    /*
    myUserRequest(function(error, myuser) {
        if (error) {
            xalert('Error ' + error, 1, -1);
            // Handle the error here
            return;
        } 
        console.log("MyUserOwn",myuser);
        const saleAreaIDs = saleId == null? myuser.SaleAreaUsers.map(saleAreaUser => saleAreaUser.SaleAreaId):saleId;
        const productIDs = productId == null? myuser.ProductUsers.map(productUser => productUser.ProductId):productId;
        console.log("SaleAreaIDs",saleAreaIDs,"ProductIDs",productIDs);
        var startDate = new Date();
        startDate.setMonth(startDate.getMonth() - 4);
        var endDate = new Date();
        endDate.setMonth(endDate.getMonth() + 4);


        console.log("Target Start Date",start,"Target End Date",end);
        var query = {
            SaleAreaIDs: saleAreaIDs, 
            ProductIDs: productIDs, 
            ExpectedStart:start == null?null:timeFormater(start), 
            ExpectedEnd:end == null?null:timeFormater(end), 
            DeepSearch: true};
        console.log("Target Query",query);

        



        const targetsContainer = document.getElementById('targetsContainer');
        targetsContainer.innerHTML = '';
        //const totalTargets = await promiseTargets(query);
        getTargets(function(error, targets) {
            if (error) {
                xalert('Error while getting target ' + error, 1, -1);
                xalert('start'+start+'end'+end, 1, -1);
                // Handle the error here
                return;
            } 
            console.log("Targets",targets);

            const sortedTargets = targets.sort((a, b) => new Date(b.EndDate).getTime() - new Date(a.EndDate).getTime());
            sortedTargets.forEach((target, index) => {
                target.order = index + 1;
            });
            console.log("Sorted Targets",sortedTargets);

            //query processing
            const totalQuery = {};
            sortedTargets.forEach(target => {
                if (!totalQuery.SaleAreaIDs) {
                    totalQuery.SaleAreaIDs = [];
                }
                if (!totalQuery.ProductIDs) {
                    totalQuery.ProductIDs = [];
                }
                if (!totalQuery.SaleAreaIDs.includes(target.SaleAreaID)) {
                    totalQuery.SaleAreaIDs.push(target.SaleAreaID);
                }
                if (!totalQuery.ProductIDs.includes(target.ProductID)) {
                    totalQuery.ProductIDs.push(target.ProductID);
                }

            });
            const minStartDate = sortedTargets.reduce((min, target) => new Date(target.StartDate) < min ? new Date(target.StartDate) : min, new Date(sortedTargets[0].StartDate));
            const maxEndDate = sortedTargets.reduce((max, target) => new Date(target.EndDate) > max ? new Date(target.EndDate) : max, new Date(sortedTargets[0].EndDate));

            console.log("Min Start Date:", minStartDate);
            console.log("Max End Date:", maxEndDate);
            totalQuery.ExpectedStart = timeFormater(minStartDate);
            totalQuery.ExpectedEnd = timeFormater(maxEndDate);
            totalQuery.DeepSearch = true;
            console.log("Total Query",totalQuery);


            getLeads(function(error, leads) {
                if (error) {
                    xalert('Error while get lead' + error, 1, -1);
                    console.log("Error",error);
                }
                console.log("Leads",leads);

                sortedTargets.forEach(async (target) => {



                });


            },totalQuery);


            sortedTargets.forEach(async (target) => {
                console.log("Target Time Start",new Date(target.StartDate).getTime(),"Target Time End",new Date(target.EndDate).getTime());
                const color = await getColor(target.ProductID);
                console.log("Color",color);
                

                getProductById(target.ProductID,function(error, product) {
                    if (error) {
                        xalert('Error while get product ' + error, 1, -1);
                        // Handle the error here
                        return;
                    }
                    console.log("Product",product);
                    getSaleAreaById(target.SaleAreaID)
                        .then(saleArea => {//tobe fixed here this will loop query to server, will be switch to local query by using get min expectedstart and max expectedend with list of SaleAreaIDs and ProductIDs then use local query to get leads
                            const query = {
                                SaleAreaIDs: [saleArea.Id],
                                ProductIDs: [product.Id],
                                ExpectedStart: timeFormater(target.StartDate),
                                ExpectedEnd: timeFormater(target.EndDate),
                                DeepSearch: true
                            };
                            getLeads(function(error, leads) {
                                if (error) {
                                    xalert('Error while get lead' + error, 1, -1);
                                    // Handle the error here
                                    return;
                                }
                                console.log("Leads",leads);
                                
                                const uniqueLeads = getUniqueLeads(leads);
                                console.log("Unique Leads",uniqueLeads);
                                const sumLeads = leads.reduce((total, lead) => total + lead.ExpectedRevenue, 0);
                                console.log("Sum of Leads Expected Revenue:", sumLeads);
                                const sumAchieved = leads.reduce((total, lead) => total + lead.AchivedRevenue, 0);
                                console.log("Sum of Leads Achieved Revenue:", sumAchieved);
                                const countLeads = leads.length;
                                console.log("Count of Leads:", countLeads);

                                const SaleArea = saleArea;
                                console.log("SaleArea",saleArea);
                                // Continue with the rest of the code
                                
                                const div = document.createElement('div');
                                div.classList.add('p-1', 'm-1', 'biomed-bordercard','flex-shrink-0');
                               
                                console.log("Color-border",color.color.code);
                                div.style.borderColor = color.color.code;
                                div.style.backgroundColor = 'rgb(255, 255, 255)';

                                const h6 = document.createElement('h6');
                                h6.classList.add('m-0', 'p-0', 'fw-bold');
                                h6.textContent = product.Name+'-'+SaleArea.Name+' ('+target.Name+')';
                                div.appendChild(h6);

                                const table = document.createElement('table');
                                table.classList.add('m-0', 'p-0');

                                const tr1 = document.createElement('tr');
                                tr1.classList.add('m-0', 'p-0', 'bt-sm');

                                const th1 = document.createElement('th');
                                th1.classList.add('m-0', 'p-0', 'fw-normal');
                                th1.textContent = 'Target';
                                tr1.appendChild(th1);

                                const th2 = document.createElement('th');
                                th2.classList.add('fw-bold', 'm-0','px-2', 'p-0', 'ms-2');
                                th2.textContent = AutoComma(target.TargetValue)+' THB';
                                tr1.appendChild(th2);

                                table.appendChild(tr1);

                                const tr2 = document.createElement('tr');
                                tr2.classList.add('m-0', 'p-0', 'bt-sm');

                                const th3 = document.createElement('th');
                                th3.classList.add('m-0', 'p-0', 'fw-normal');
                                th3.textContent = 'Expected';
                                tr2.appendChild(th3);

                                const th4 = document.createElement('th');
                                th4.classList.add('fw-bold', 'm-0','px-2', 'p-0', 'ms-2');
                                th4.textContent = AutoComma(sumLeads)+' THB';
                                tr2.appendChild(th4);

                                table.appendChild(tr2);

                                const tr3 = document.createElement('tr');
                                tr3.classList.add('m-0', 'p-0', 'bt-sm');

                                const th5 = document.createElement('th');
                                th5.classList.add('m-0', 'p-0', 'fw-normal');
                                th5.textContent = 'Achieved';
                                tr3.appendChild(th5);

                                const th6 = document.createElement('th');
                                th6.classList.add('fw-bold', 'm-0', 'p-0','px-2', 'ms-2');
                                th6.textContent = sumAchieved === 0 ? sumAchieved+' THB (0%)' : AutoComma(sumAchieved)+' THB ('+Math.round(sumAchieved/target.TargetValue*100)+'%)';

                                const achievementPercentage = Math.round(sumAchieved/target.TargetValue*100);

                                if (achievementPercentage < 80) {
                                    th6.textContent += ' 😢';
                                } else if (achievementPercentage >= 80 && achievementPercentage <= 89) {
                                    th6.textContent += ' 😊';
                                } else if (achievementPercentage >= 90 && achievementPercentage <= 99) {
                                    th6.textContent += ' 😍';
                                } else {
                                    th6.textContent += ' 😎';
                                }
                                tr3.appendChild(th6);

                                table.appendChild(tr3);

                                const tr4 = document.createElement('tr');
                                tr4.classList.add('m-0', 'p-0', 'bt-sm');

                                const th7 = document.createElement('th');
                                th7.classList.add('m-0', 'p-0', 'fw-normal');
                                th7.textContent = 'Date';
                                tr4.appendChild(th7);

                                const th8 = document.createElement('th');
                                th8.classList.add('fw-bold', 'm-0', 'p-0','px-2', 'ms-2');
                                th8.textContent = formatDateOnly(target.StartDate)+ " - "+ formatDateOnly(target.EndDate) ;

                                tr4.appendChild(th8);

                                table.appendChild(tr4);

                                const tr5 = document.createElement('tr');
                                tr5.classList.add('m-0', 'p-0', 'bt-sm');

                                const th9 = document.createElement('th');
                                th9.classList.add('m-0', 'p-0', 'fw-normal');
                                th9.textContent = 'Ramaining';
                                tr5.appendChild(th9);

                                const th10 = document.createElement('th');
                                th10.classList.add('fw-bold', 'm-0', 'p-0','px-2', 'ms-2');
                                th10.textContent =getRemainingDays(target.EndDate);
                                tr5.appendChild(th10);

                                table.appendChild(tr5);

                                const tr6 = document.createElement('tr');
                                tr6.classList.add('m-0', 'p-0', 'bt-sm');

                                const th11 = document.createElement('th');
                                th11.classList.add('m-0', 'p-0', 'fw-normal');
                                th11.textContent = 'Count';
                                tr6.appendChild(th11);

                                const th12 = document.createElement('th');
                                th12.classList.add('fw-bold', 'm-0', 'p-0','px-2', 'ms-2');
                                th12.textContent = countLeads+' Leads';
                                tr6.appendChild(th12);

                                table.appendChild(tr6);

                                div.appendChild(table);

                                div.order = target.order;




                                const children = targetsContainer.children;
                                let inserted = false;

                                if (children.length === 0) {
                                    targetsContainer.appendChild(div);
                                    inserted = true;
                                } else {
                                    for (let i = children.length - 1; i >= 0; i--) {
                                        const child = children[i];
                                        if (div.order < child.order) {
                                            targetsContainer.insertBefore(div, child.nextSibling);
                                            inserted = true;
                                            break;
                                        }
                                    }
                                }

                                if (!inserted) {
                                    targetsContainer.insertBefore(div, targetsContainer.firstChild);
                                }
                                //targetsContainer.appendChild(div);
                                


                            } ,query);
                        })
                        .catch(error => {
                            xalert('Error error while get SaleArea' + error, 1, -1);
                            // Handle the error here
                        });

                });


            });
        } ,query);
    },true);
    */

}



function createModalPopup(pipelineId = null, deletePipeline = false) {
    // Create the modal element
    pipelineIdCache = pipelineId;
    const modal = document.createElement('div');
    modal.id = 'pipelineModal';
    
    modal.classList.add('modal', 'fade');
    modal.setAttribute('tabindex', '-1');
    modal.setAttribute('role', 'dialog');

    // Create the modal dialog element
    const modalDialog = document.createElement('div');
    modalDialog.classList.add('modal-dialog');
    modal.appendChild(modalDialog);

    // Create the modal content element
    const modalContent = document.createElement('div');
    modalContent.classList.add('modal-content');
    modalDialog.appendChild(modalContent);

    // Create the modal header element
    const modalHeader = document.createElement('div');
    modalHeader.classList.add('modal-header');
    modalContent.appendChild(modalHeader);

    // Create the modal title element
    const modalTitle = document.createElement('h5');
    modalTitle.classList.add('modal-title');
    modalTitle.textContent = 'Add Pipeline';
    if (pipelineId) {
        modalTitle.textContent = 'Edit Pipeline';
    }
    if (deletePipeline) {
        modalTitle.textContent = 'Are you sure you want to delete this pipeline?';
    }
    modalHeader.appendChild(modalTitle);

    // Create the close button element
    const closeButton = document.createElement('button');
    closeButton.setAttribute('type', 'button');
    closeButton.classList.add('btn-close');
    closeButton.setAttribute('data-bs-dismiss', 'modal');
    closeButton.setAttribute('aria-label', 'Close');
    closeButton.addEventListener('click', removeModalPopup );
    modalHeader.appendChild(closeButton);

    // Create the modal body element
    const modalBody = document.createElement('div');
    modalBody.classList.add('modal-body');
    modalContent.appendChild(modalBody);

    // Create the text input element
    const inputGroup = document.createElement('div');
    inputGroup.classList.add('input-group', 'input-group-sm', 'mb-3');
    modalBody.appendChild(inputGroup);

    const inputGroupText = document.createElement('span');
    inputGroupText.classList.add('input-group-text');
    inputGroupText.style.width = '60px';
    inputGroupText.textContent = 'Title';
    inputGroup.appendChild(inputGroupText);

    const input = document.createElement('input');
    input.setAttribute('type', 'text');
    input.classList.add('form-control');
    input.setAttribute('aria-label', 'Sizing example input');
    input.setAttribute('aria-describedby', 'inputGroup-sizing-sm');
    input.id = 'pipelineTitle';
    if (pipelineId) {
        const pipeline = pipelineCache.find(pipeline => pipeline.Id === pipelineId);
        input.value = pipeline.PipelineName;
        //input2.value = pipeline.Order;
    }
    if (deletePipeline) {
        input.readOnly = true;
    }
    inputGroup.appendChild(input);

    // Create the input group element
    const inputGroup2 = document.createElement('div');
    inputGroup2.classList.add('input-group', 'input-group-sm', 'mb-3');
    modalBody.appendChild(inputGroup2);

    // Create the input group text element
    const inputGroupText2 = document.createElement('span');
    inputGroupText2.classList.add('input-group-text');
    inputGroupText2.style.width = '60px';
    inputGroupText2.textContent = 'Order';
    inputGroup2.appendChild(inputGroupText2);

    // Create the input element
    const input2 = document.createElement('input');
    input2.setAttribute('type', 'number');
    input2.classList.add('form-control');
    input2.setAttribute('aria-label', 'Sizing example input');
    input2.setAttribute('aria-describedby', 'inputGroup-sizing-sm');
    input2.value = 0;
    if (pipelineId) {
        const pipeline = pipelineCache.find(pipeline => pipeline.Id === pipelineId);
        //input.value = pipeline.PipelineName;
        input2.value = pipeline.Order;
    }
    if (deletePipeline) {
        input2.readOnly = true;
    }
    input2.id = 'pipelineOrder';
    inputGroup2.appendChild(input2);

    // Create the button element
    const addButton = document.createElement('button');
    addButton.textContent = 'Add';
    if (pipelineId) {
        addButton.textContent = 'Update';
    }
    if (deletePipeline) {
        addButton.textContent = 'Delete';
        addButton.setAttribute('data-bs-dismiss', 'modal');
        addButton.setAttribute('aria-label', 'Close');
        addButton.classList.add('btn', 'btn-danger');
        addButton.addEventListener('click', function() {
            deletePipelineRequest(pipelineId);
            removeModalPopup();
        });
    }else{
        addButton.classList.add('btn', 'btn-primary');
        addButton.setAttribute('data-bs-dismiss', 'modal');
        addButton.setAttribute('aria-label', 'Close');
        addButton.addEventListener('click', createCRMPipeline);
    }
    modalBody.appendChild(addButton);

    // Append the modal to the document body

    document.body.appendChild(modal);
    var crmModal = new bootstrap.Modal("#pipelineModal", {focus: true});

    /*var wtfisthis = bootstrap.Modal.getInstance(document.getElementById('pipelineModal'));
    wtfisthis.addEventListener('hidden.bs.modal', function (event) {

        wtfisthis.dispose();
    });*/

    

    crmModal.show();
}

function createCRMPipeline(){
    createPipelineRequest(pipelineIdCache);
    removeModalPopup();
}

function deletePipelineRequest(pipelineId) {
    const token = readToken();
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url + '/biomedapi/crm/pipelines/delete', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Request successful
                xalert('Pipeline deleted successfully', 0, -1);
                setTimeout(function() {
                    location.reload();
                }, 2000);
            } else {
                // Request failed
                xalert('Error ' + xhr.status + " " + xhr.responseText, 1, -1);
            }
        }
    };
    const data = JSON.stringify({Id: pipelineId});
    xhr.send(data);

}

function createPipelineRequest(pipelineId = null) {
    const token = readToken();
    const name = document.getElementById('pipelineTitle').value;
    const order = parseInt(document.getElementById('pipelineOrder').value);


    const xhr = new XMLHttpRequest();
    if (pipelineId) {
        xhr.open('POST', url+ '/biomedapi/crm/pipelines/update', true);
    } else {
        xhr.open('POST', url+ '/biomedapi/crm/pipelines/create', true);
    }
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Request successful
                xalert('Pipeline created/updated successfully',0,-1);
                setTimeout(function() {
                    location.reload();
                }, 2000);
                
            } else {
                // Request failed
                xalert('Error '+xhr.status+" "+xhr.responseText,1,-1);
                
            }
        }
    };
    let rawdata = {
        PipelineName: name,
        Order: order
    };
    if (pipelineId) {
        rawdata.Id = pipelineId;
    }   
    
    const data = JSON.stringify(rawdata);
    xhr.send(data);
}


function removeModalPopup() {
    document.getElementById('pipelineModal').remove();
    pipelineIdCache = null;
}


function displayLeads(query = null) {
    
    const pipelineContainer = document.getElementById('pipelineContainer');
    pipelineContainer.innerHTML = '';

    getPipelines(function(error, pipelines) {
        if (error) {
            xalert('Error while getting pipelines' + error, 1, -1);
            // Handle the error here
        } else {


            pipelineCache = pipelines;
            //Create Null Pipeline
            const nullpipelineElement = document.createElement('div');
                nullpipelineElement.classList.add('col', 'm-0', 'p-0', 'px-1', 'py-2', 'd-none');
                nullpipelineElement.style.minWidth = '256px';
                nullpipelineElement.id = 'nullPipelineParent';
                nullpipelineElement.innerHTML = `
                <div class="m-0 p-0 row" id="nullPipeline">
                
                    <h6 class="col-11 p-0 m-0 mb-1 py-auto fw-bold auto-fit py-1">Unassigned</h6>
                    
                </div>

                    
                `;
                pipelineContainer.appendChild(nullpipelineElement);


            pipelines.forEach(pipeline => {
                const pipelineElement = document.createElement('div');
                pipelineElement.classList.add('col', 'm-0', 'p-0', 'px-1', 'py-2');
                pipelineElement.style.minWidth = '280px';
                pipelineElement.innerHTML = `
                <div class="m-0 p-0 row" id="${pipeline.Id}">
                
                    <h6 class="p-0 m-0 py-auto fw-bold auto-fit py-1">${pipeline.PipelineName}</h6>
                    
                    <div class="btn-group m-0 p-0 d-grid justify-content-sm-end ms-auto col-3 dropstart mb-1">
                            <button class="btn btn-secondary btn-sm rounded m-0 p-0 ms-auto auto-fit" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fi fi-rr-menu-dots-vertical"></i>
                            </button>
                            <ul class="dropdown-menu">
                                <li><h6 class="dropdown-header">Quick Action</h6></li>
                                <li><a class="dropdown-item" onclick="editpipeline(${pipeline.Id})">Edit Pipeline</a></li>
                                <li><a class="dropdown-item text-danger" onclick="deletepipeline(${pipeline.Id})">Delete Pipeline</a></li>
                            </ul>
                    </div>
                    <div class="m-0 p-1 d-flex flex-nowrap justify-content-evenly"> 
                        <span class="badge rounded-pill bg-danger mt-1"><i class="fi fi-rr-ban"></i> Dropped:<p class="m-0 p-0 d-inline" id="abandon${pipeline.Id}">0</p></span>
                        <span class="badge rounded-pill bg-warning mt-1"><i class="fi fi-rr-triangle-warning"></i> Inactive:<p class="m-0 p-0 d-inline" id="warn${pipeline.Id}">0</p></span>
                        <span class="badge rounded-pill bg-success mt-1"><i class="fi fi-rr-signal-bars-good"></i> Active:<p class="m-0 p-0 d-inline" id="ok${pipeline.Id}">0</p></span>
                    </div>
                </div>

                    
                `;
                pipelineContainer.appendChild(pipelineElement);
            });
        }
        getLeads(function(error, leads) {
            if (error) {
                xalert('Error while getting lead' + error , 1, -1);
                // Handle the error here
            } else {
                loadLeads(getUniqueLeads(leads));
                getUniqueLeads(leads).forEach(lead => {
                    
                    let leadsContainer = document.getElementById(lead.CRMPipelineId);
                    const leadElement = document.createElement('div');
                    leadElement.classList.add('p-0');
                    console.log(lead);
                    var MainContact = null;
                    if (lead.MainCustomerId != null && lead.MainCustomerId != undefined) {
                        getContactById(lead.MainCustomerId,async function(error, contact) {
                            if (error) {
                                xalert('Error ' + error, 1, -1);
                                // Handle the error here
                            } else {
                                MainContact = contact;
                                if (MainContact.Name == null || MainContact.Name == undefined) {
                                    MainContact = {Name: "", Position: "-"};
                                }
                                if (MainContact.Position == null || MainContact.Position == undefined) {
                                    MainContact = { Name:MainContact.Name, Position: "-"};
                                }
                                getUserById(async function(error, user){
                                    if (error) {
                                        xalert('Error ' + error , 1, -1);
                                        // Handle the error here
                                    }
                                    if (user == null || user == undefined) {
                                        xalert('Error ' + error , 1, -1);
                                        // Handle the error here
                                    }
                                    var mainuser = user;
                                    var color = await getColor(user.Id);
                                    console.log(color);
                                    var leadLink = 'crm-detail.html?leadid='+lead.Id;
                                console.log(mainuser);
                                const thirtyDaysAgo = new Date();
                                thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

                                const threeMonths = new Date();
                                thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 90);
                                var badge = "";
                                if(!(lead.CRMPipelineId == null || lead.CRMPipelineId == undefined)){
                                    
                                    if (lead.LastUpdated < thirtyDaysAgo) {
                                        document.getElementById('warn'+lead.CRMPipelineId).textContent = parseInt(document.getElementById('warn'+lead.CRMPipelineId).textContent) + 1;
                                        badge =  `<span class="badge rounded-pill bg-warning d-inline p-1 px-2 me-1"><i class="fi fi-rr-triangle-warning"></i></span>`;
                                    }else
                                    if (lead.LastUpdated < threeMonths) {
                                        document.getElementById('abandon'+lead.CRMPipelineId).textContent = parseInt(document.getElementById('abandon '+lead.CRMPipelineId).textContent) + 1;
                                        
                                        badge =  `<span class="badge rounded-pill bg-danger d-inline p-1 px-2 me-1"><i class="fi fi-rr-ban"></i></span>`;
                                    }
                                    else{
                                        document.getElementById('ok'+lead.CRMPipelineId).textContent = parseInt(document.getElementById('ok'+lead.CRMPipelineId).textContent) + 1;
                                        badge =  `<span class="badge rounded-pill bg-success d-inline p-1 px-2 me-1"><i class="fi fi-rr-signal-bars-good"></i></span>`;
                                    }
                                }
                                document.getElementById('tAchieved').textContent = parseInt(document.getElementById('tAchieved').textContent) + parseInt(lead.AchivedRevenue);

                                document.getElementById('tExpected').textContent = parseInt(document.getElementById('tExpected').textContent) + parseInt(lead.ExpectedRevenue);
                                document.getElementById('AERatio').style.width = (parseInt(document.getElementById('tAchieved').textContent) / parseInt(document.getElementById('tExpected').textContent) * 100) + "%";
                                document.getElementById('AERatio').textContent = Math.round((parseInt(document.getElementById('tAchieved').textContent) / parseInt(document.getElementById('tExpected').textContent) * 100)) + "%";
                                
                                var isValidProductID = true;
                                var isValidSaleAreaID = true;
                                if (lead.ProductId == null || lead.ProductId == undefined) {
                                    var Productcolor = {color: {code: "#FFFFFF"},textColor: "#000000"};
                                    lead.ProductId = 1;
                                    isValidProductID = false;
                                }else{
                                    var  Productcolor = await getColor(lead.ProductId);

                                }
                                if(lead.SaleAreaId == null || lead.SaleAreaId == undefined){
                                    lead.SaleAreaId = 1;
                                    isValidSaleAreaID = false;
                                
                                }

                                const product = await new Promise((resolve, reject) => {
                                    getProductById(lead.ProductId, function(error, product) {
                                        if (error) {
                                            //xalert('Error ' + error, 1, -1);
                                            //reject(error);
                                            resolve({Name: "Unassigned"});
                                        } else {
                                            resolve(product);
                                        }
                                    });
                                });
                                console.log("Product",product);

                                const saleArea = await new Promise((resolve, reject) => {
                                    getSaleAreaById(lead.SaleAreaId)
                                        .then(saleArea => {
                                            resolve(saleArea);
                                        })
                                        .catch(error => {
                                            resolve({Name: "Unassigned"});
                                            //xalert('Error ' + error, 1, -1);
                                            //reject(error);
                                        });
                                });
                                console.log("SaleArea",saleArea);
                                leadElement.innerHTML = `
                                    <div class="m-0 p-2 my-0 biomed-bordercard bg-white" style="border-color:${Productcolor.color.code};"><!-- Single Lead-->
                                        <div class="m-0 p-0 row"> 
                                            <p class="m-0 p-0 py-0 fw-bold auto-fit col-9">${badge}${ lead.LeadName}</p>
                                            
                                            <div class="btn-group m-0 p-0 d-grid justify-content-sm-end ms-auto col-3 dropstart">
                                                <button class="btn btn-secondary btn-sm rounded m-0 p-0 ms-auto auto-fit" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="fi fi-rr-menu-dots-vertical"></i>
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><h6 class="dropdown-header">Quick Action</h6></li>
                                                    <li><a class="dropdown-item d-none" href="#" onclick="openModal()">Create event from this lead</a></li>
                                                    <li><a class="dropdown-item" href="${leadLink}">Edit this lead</a></li>
                                                    <li><hr class="dropdown-divider d-none"></li>
                                                    <li><h6 class="dropdown-header d-none ">Change Status to...</h6></li>
                                                    <li><a class="dropdown-item d-none" href="#">Sales Plan</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Initiate</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Following Up</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Qualified</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Confirmed Order</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Proposition</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">PO Issued</a></li>
                                                    <li><hr class="dropdown-divider d-none"></li>
                                                    <li><a class="dropdown-item text-danger d-none" href="#" >Delete this lead</a></li>
                                                </ul>
                                            </div>
            
                                        </div>
                                        <p class="m-0 py-1 fw-normal">Product: ${isValidProductID? product.Name:"Unassigned"}</p>
                                        <p class="m-0 py-1 fw-normal">Sale Area: ${isValidSaleAreaID? saleArea.Name:"Unassigned"}</p>
                                        <p class="m-0 py-1 fw-normal">Expect: ${AutoComma(lead.ExpectedRevenue)} THB</p>
                                        <p class="m-0 py-1 fw-normal">Achieved: ${ AutoComma(lead.AchivedRevenue)} THB</p>
                                        <p class="m-0 py-1 fw-normal">${"Main Customer:" +" "+MainContact.Name+"("+MainContact.Position+")"}</p>
                                        <p class="m-0 py-1 fw-normal">Due Date: ${formatDateOnly(lead.Expected)}</p>
                                        <p class="m-0 py-1 fw-normal"><span class="badge py-1 m-1 align-middle text-wrap" style="background-color: ${color.color.code}; color: ${color.textColor};">${mainuser.FirstName+" "+mainuser.LastName+"("+mainuser.Position+")"}</span></p>
                                        <p class="m-0 py-0 d-none"><i class="fi fi-rr-circle-star text-warning"></i><i class="fi fi-rr-circle-star text-warning"></i><i class="fi fi-rr-circle-star text-secondary"></i></p>
                                    </div>
                                `;
                                if(leadsContainer == null || leadsContainer == undefined){
                                    leadsContainer = document.getElementById('nullPipeline');
                                    document.getElementById('nullPipelineParent').classList.remove('d-none');
                                }
                                leadsContainer.appendChild(leadElement);

                                /*
                                getProductById(lead.ProductId,function(error, product) {
                                    if (error) {
                                        xalert('Error ' + error, 1, -1);
                                        // Handle the error here
                                    }

                                    console.log(product);
                                    getSaleAreaById(lead.SaleAreaId)
                                        .then(saleArea => {
                                            // Handle success
                                            console.log(saleArea);
                                            leadElement.innerHTML = `
                                    <div class="m-0 p-2 my-0 biomed-bordercard bg-white" style="border-color:${Productcolor.color.code};"><!-- Single Lead-->
                                        <div class="m-0 p-0 row"> 
                                            <p class="m-0 p-0 py-0 fw-bold auto-fit col-9">${badge}${ lead.LeadName}</p>
                                            
                                            <div class="btn-group m-0 p-0 d-grid justify-content-sm-end ms-auto col-3 dropstart">
                                                <button class="btn btn-secondary btn-sm rounded m-0 p-0 ms-auto auto-fit" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="fi fi-rr-menu-dots-vertical"></i>
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><h6 class="dropdown-header">Quick Action</h6></li>
                                                    <li><a class="dropdown-item d-none" href="#" onclick="openModal()">Create event from this lead</a></li>
                                                    <li><a class="dropdown-item" href="${leadLink}">Edit this lead</a></li>
                                                    <li><hr class="dropdown-divider d-none"></li>
                                                    <li><h6 class="dropdown-header d-none ">Change Status to...</h6></li>
                                                    <li><a class="dropdown-item d-none" href="#">Sales Plan</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Initiate</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Following Up</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Qualified</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Confirmed Order</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Proposition</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">PO Issued</a></li>
                                                    <li><hr class="dropdown-divider d-none"></li>
                                                    <li><a class="dropdown-item text-danger d-none" href="#" >Delete this lead</a></li>
                                                </ul>
                                            </div>
            
                                        </div>
                                        <p class="m-0 py-1 fw-normal">Product: ${isValidProductID? product.Name:"Unassigned"}</p>
                                        <p class="m-0 py-1 fw-normal">Sale Area: ${isValidSaleAreaID? saleArea.Name:"Unassigned"}</p>
                                        <p class="m-0 py-1 fw-normal">Expect: ${AutoComma(lead.ExpectedRevenue)} THB</p>
                                        <p class="m-0 py-1 fw-normal">Achieved: ${ AutoComma(lead.AchivedRevenue)} THB</p>
                                        <p class="m-0 py-1 fw-normal">${"Main Customer:" +" "+MainContact.Name+"("+MainContact.Position+")"}</p>
                                        <p class="m-0 py-1 fw-normal">Due Date: ${formatDateOnly(lead.Expected)}</p>
                                        <p class="m-0 py-1 fw-normal"><span class="badge py-1 m-1 align-middle text-wrap" style="background-color: ${color.color.code}; color: ${color.textColor};">${mainuser.FirstName+" "+mainuser.LastName+"("+mainuser.Position+")"}</span></p>
                                        <p class="m-0 py-0 d-none"><i class="fi fi-rr-circle-star text-warning"></i><i class="fi fi-rr-circle-star text-warning"></i><i class="fi fi-rr-circle-star text-secondary"></i></p>
                                    </div>
                                `;
                                
                                

                                if(leadsContainer == null || leadsContainer == undefined){
                                    leadsContainer = document.getElementById('nullPipeline');
                                    document.getElementById('nullPipelineParent').classList.remove('d-none');
                                }
                                leadsContainer.appendChild(leadElement);
                                        })
                                        .catch(error => {
                                            // Handle error
                                            xalert('Error ' + error, 1, -1);
                                        });
                                });
                                */

                                
                                   
                                },lead.MainUserId);

                            }
                        });
                    }else{
                        MainContact = {Name: " ", Position: "-"};
                        xalert('Error Missing MainContact for Lead:'+lead.Id, 1, -1);
                    }
                    
    
                });
            }
            
        },query);
    
    
    
    },true);



}


const usersQuerySelecter = document.getElementById('usersQuerySelecter');
const contactsQuerySelecter = document.getElementById('contactsQuerySelecter');
const productsQuerySelecter = document.getElementById('productQuerySelecter');
const AreaQuerySelecter = document.getElementById('AreaQuerySelecter');
window.onload = function() {
    myUserRequest(function(error, myuser) {
        if (error) {
            xalert('Error ' + error, 1, -1);
            // Handle the error here
            return;
        }
        console.log("MyUserOwn",myuser);
        getUsers(function(error, users) {
            if (error) {
                xalert('Error ' + error, 1, -1);
                // Handle the error here
            } else {
                
                users.forEach(user => {

                    var userElement = document.createElement('option');
                    userElement.value = user.Id;
                    userElement.textContent = user.FirstName + " " + user.LastName;
                    if (user.Position !== null && user.Position !== undefined) {
                        userElement.setAttribute("data-subtext", `${user.Position}`);
                    }
                    usersQuerySelecter.appendChild(userElement);
                    $(usersQuerySelecter).selectpicker('refresh');
                });
            }
            getContacts(function(error, contacts) {

                if (error) {
                    xalert('Error ' + error, 1, -1);
                    // Handle the error here
                } else {
                    
                    contacts.forEach(contact => {
    
                        var contactElement = document.createElement('option');
                        contactElement.value = contact.Id;
                        contactElement.textContent = contact.Name;
                        if (contact.Position !== null && contact.Position !== undefined) {
                            contactElement.setAttribute("data-subtext", `${contact.Position}`);
                        }
                        contactsQuerySelecter.appendChild(contactElement);
                        $(contactsQuerySelecter).selectpicker('refresh');
                    });
                }
                getProducts(function(error, products) {
                    if (error) {
                        xalert('Error ' + error, 1, -1);
                        // Handle the error here
                    } else {
                        console.log("Products",products);

                        var hasPermission = false;
                        if (myuser.Permissions.some(perm => perm.Type === 'lead_manage'&&(perm.Value ==='Allow'||perm.Value === 3))){
                            hasPermission = true;
                        }
                        
                        products.forEach(product => {
                            if (myuser.ProductUsers.some(item => item.ProductId === product.Id)||hasPermission===true) {
                                const productElement = document.createElement('option');
                                productElement.value = product.Id;
                                productElement.textContent = product.Name;
                                productsQuerySelecter.appendChild(productElement);
                                $(productsQuerySelecter).selectpicker('refresh');
                            }
                        }

                        );
                    }
                    getSaleAreas(function(error, saleAreas) {
                        if (error) {
                            xalert('Error ' + error, 1, -1);
                            // Handle the error here
                        } else {
                            console.log("Areas", saleAreas);

                            var hasPermission = false;
                            if (myuser.Permissions.some(perm => perm.Type === 'lead_manage'&&(perm.Value ==='Allow'||perm.Value === 3))){
                                hasPermission = true;
                            }
                            saleAreas.forEach(saleArea => {
                                if (myuser.SaleAreaUsers.some(item => item.SaleAreaId === saleArea.Id)||hasPermission===true) {
                                    const saleAreaElement = document.createElement('option');
                                    saleAreaElement.value = saleArea.Id;
                                    saleAreaElement.textContent = saleArea.Name;
                                    AreaQuerySelecter.appendChild(saleAreaElement);
                                    $(AreaQuerySelecter).selectpicker('refresh');
                                }
                            }
                            );
                        }
            
                        /*
                        displayLeads();
                        targetDisplay();*/
                        querysearch();//everything will be in here

                    } ,false);//end of getSaleAreas
                } ,false);//end of getProducts
            },false); //end of getContacts
        },false );//end of getUsers

        

        

        


    });

};



function createLeadPopup() {
    // Create the modal element
    const modal = document.createElement('div');
    modal.id = 'leadModal';
    
    modal.classList.add('modal', 'fade');
    modal.setAttribute('tabindex', '-1');
    modal.setAttribute('role', 'dialog');

    // Create the modal dialog element
    const modalDialog = document.createElement('div');
    modalDialog.classList.add('modal-dialog');
    modal.appendChild(modalDialog);

    // Create the modal content element
    const modalContent = document.createElement('div');
    modalContent.classList.add('modal-content');
    modalDialog.appendChild(modalContent);

    // Create the modal header element
    const modalHeader = document.createElement('div');
    modalHeader.classList.add('modal-header');
    modalContent.appendChild(modalHeader);

    // Create the modal title element
    const modalTitle = document.createElement('h5');
    modalTitle.classList.add('modal-title');
    modalTitle.textContent = 'Create Lead';
    modalHeader.appendChild(modalTitle);

    // Create the close button element
    const closeButton = document.createElement('button');
    closeButton.setAttribute('type', 'button');
    closeButton.classList.add('btn-close');
    closeButton.setAttribute('data-bs-dismiss', 'modal');
    closeButton.setAttribute('aria-label', 'Close');
    closeButton.addEventListener('click', removeLeadPopup );
    modalHeader.appendChild(closeButton);

    // Create the modal body element
    const modalBody = document.createElement('div');
    modalBody.classList.add('modal-body');
    modalContent.appendChild(modalBody);

    // Create the text input element for LeadName
    const leadNameInputGroup = document.createElement('div');
    leadNameInputGroup.classList.add('input-group', 'input-group-sm', 'mb-3');
    modalBody.appendChild(leadNameInputGroup);

    const leadNameInputGroupText = document.createElement('span');
    leadNameInputGroupText.classList.add('input-group-text');
    leadNameInputGroupText.style.width = '100px';
    leadNameInputGroupText.textContent = 'Lead Name';
    leadNameInputGroup.appendChild(leadNameInputGroupText);

    const leadNameInput = document.createElement('input');
    leadNameInput.setAttribute('type', 'text');
    leadNameInput.classList.add('form-control');
    leadNameInput.setAttribute('aria-label', 'Sizing example input');
    leadNameInput.setAttribute('aria-describedby', 'inputGroup-sizing-sm');
    leadNameInput.id = 'leadName';
    leadNameInputGroup.appendChild(leadNameInput);

    // Create the dropdown selection element
    const pipelineDropdown = document.createElement('select');
    pipelineDropdown.classList.add('form-select', 'mb-3');
    pipelineDropdown.setAttribute('aria-label', 'Select Pipeline');
    pipelineDropdown.id = 'pipelineDropdown';
    modalBody.appendChild(pipelineDropdown);

    // Add options to the dropdown from pipelineCache
    pipelineCache.forEach(pipeline => {
        const option = document.createElement('option');
        option.value = pipeline.Id;
        option.textContent = pipeline.PipelineName;
        pipelineDropdown.appendChild(option);
    });

    // Create the button element
    const createLeadButton = document.createElement('button');
    createLeadButton.textContent = 'Create Lead';
    createLeadButton.classList.add('btn', 'btn-primary');
    createLeadButton.setAttribute('data-bs-dismiss', 'modal');
    createLeadButton.setAttribute('aria-label', 'Close');
    createLeadButton.addEventListener('click', createLead);
    modalBody.appendChild(createLeadButton);

    // Append the modal to the document body
    document.body.appendChild(modal);
    var leadModal = new bootstrap.Modal("#leadModal", {focus: true});
    leadModal.show();
}

function createLead(){
    createLeadRequest();
    removeLeadPopup();
}

function createLeadRequest() {
    const token = readToken();
    const leadName = document.getElementById('leadName').value;
    const pipelineId = document.getElementById('pipelineDropdown').value;

    const xhr = new XMLHttpRequest();
    xhr.open('POST', url + '/biomedapi/leads/create', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Request successful
                xalert('Lead created successfully', 0, -1);
                setTimeout(() => {
                    const leadId = xhr.responseText;
                    window.location.href = `crm-detail.html?leadid=${leadId}`;
                }, 2000);
            } else {
                // Request failed
                xalert('Error ' + xhr.status + " " + xhr.responseText, 1, -1);
            }
        }
    };
    let rawdata = {
        LeadName: leadName,
        PipelineId: pipelineId
    };
    
    const data = JSON.stringify(rawdata);
    xhr.send(data);
}

function removeLeadPopup() {
    document.getElementById('leadModal').remove();
}

function clearRadioSelection(e) {
    const parentElement = e.parentElement;
    const radioButtons = parentElement.querySelectorAll('input[type="radio"]');
    radioButtons.forEach(radioButton => {
        radioButton.checked = false;
    });
}




function querysearch(){

    const expectedYearRadios = document.querySelectorAll('input[id^="ExpectedFY"]');
    const updatedYearRadios = document.querySelectorAll('input[id^="UpdateFY"]');
    const createYearRadios = document.querySelectorAll('input[id^="CreationFY"]');

    
    let expectedYear = '';
    let updatedYear = '';
    let createYear = '';

    expectedYearRadios.forEach(radio => {
        if (radio.checked) {
            expectedYear = radio.id.slice(-2);
        }
    });

    updatedYearRadios.forEach(radio => {
        if (radio.checked) {
            updatedYear = radio.id.slice(-2);
        }
    });

    createYearRadios.forEach(radio => {
        if (radio.checked) {
            createYear = radio.id.slice(-2);
        }
    });


    const selectedUpdateQuarter = document.querySelector('input[id^="UpdateQuarter"]:checked');
    const selectedCreationQuarter = document.querySelector('input[id^="CreationQuarter"]:checked');
    const selectedExpectedQuarter = document.querySelector('input[id^="ExpectedQuarter"]:checked');

    let updateQuarterLabelText = '';
    let creationQuarterLabelText = '';
    let expectedQuarterLabelText = '';

    if (selectedUpdateQuarter) {
        const updateQuarterLabel = document.querySelector(`label[for="${selectedUpdateQuarter.id}"]`);
        updateQuarterLabelText = updateQuarterLabel.textContent;
    } else {
        updateQuarterLabelText = 'Q0';
    }

    if (selectedCreationQuarter) {
        const creationQuarterLabel = document.querySelector(`label[for="${selectedCreationQuarter.id}"]`);
        creationQuarterLabelText = creationQuarterLabel.textContent;
    } else {
        creationQuarterLabelText = 'Q0';
    }

    if (selectedExpectedQuarter) {
        const expectedQuarterLabel = document.querySelector(`label[for="${selectedExpectedQuarter.id}"]`);
        expectedQuarterLabelText = expectedQuarterLabel.textContent;
    } else {
        expectedQuarterLabelText = 'Q0';
    }

    console.log('Selected Update Quarter:', updateQuarterLabelText);
    console.log('Selected Creation Quarter:', creationQuarterLabelText);
    console.log('Selected Expected Quarter:', expectedQuarterLabelText);
    let isCreationFullFilled = true;
    let isUpdateFullFilled = true;
    let isExpectedFullFilled = true;
    if(creationQuarterLabelText === 'Q0' && createYear === ''){
        isCreationFullFilled = false;
    }
    if(updateQuarterLabelText === 'Q0' && updatedYear === ''){
        isUpdateFullFilled = false;
    }
    if(expectedQuarterLabelText === 'Q0' && expectedYear === ''){
        isExpectedFullFilled = false;
    }
    
    if (expectedYear === '') {
        expectedYear = new Date().getFullYear().toString().slice(-2);
    }

    if (updatedYear === '') {
        updatedYear = new Date().getFullYear().toString().slice(-2);
    }

    if (createYear === '') {
        createYear = new Date().getFullYear().toString().slice(-2);
    }

    console.log('Expected Year:', expectedYear);
    console.log('Updated Year:', updatedYear);
    console.log('Create Year:', createYear);

    
    var CreationQuarter = creationslider.noUiSlider.get();
    var CreationStart = parseInt(CreationQuarter[0]);
    var CreationEnd = parseInt(CreationQuarter[1]);
    var CreationStartQnYear = QFormater(CreationStart);
    var CreationEndQnYear = QFormater(CreationEnd);
    var CreationStartRange = getQuarterDateRange( parseInt(CreationStartQnYear.split(' ')[0].slice(-1)),parseInt(CreationStartQnYear.split(' ')[1].slice(-2)));
    var CreationEndRange = getQuarterDateRange( parseInt(CreationEndQnYear.split(' ')[0].slice(-1)),parseInt(CreationEndQnYear.split(' ')[1].slice(-2)));

    var UpdateQuarter = updateslider.noUiSlider.get();
    var UpdateStart = parseInt(UpdateQuarter[0]);
    var UpdateEnd = parseInt(UpdateQuarter[1]);
    var UpdateStartQnYear = QFormater(UpdateStart);
    var UpdateEndQnYear = QFormater(UpdateEnd);
    var UpdateStartRange = getQuarterDateRange( parseInt(UpdateStartQnYear.split(' ')[0].slice(-1)),parseInt(UpdateStartQnYear.split(' ')[1].slice(-2)));
    var UpdateEndRange = getQuarterDateRange( parseInt(UpdateEndQnYear.split(' ')[0].slice(-1)),parseInt(UpdateEndQnYear.split(' ')[1].slice(-2)));

    var ExpectedQuarter = expectedslider.noUiSlider.get();
    var ExpectedStart = parseInt(ExpectedQuarter[0]);
    var ExpectedEnd = parseInt(ExpectedQuarter[1]);
    var ExpectedStartQnYear = QFormater(ExpectedStart);
    var ExpectedEndQnYear = QFormater(ExpectedEnd);
    var ExpectedStartRange = getQuarterDateRange( parseInt(ExpectedStartQnYear.split(' ')[0].slice(-1)),parseInt(ExpectedStartQnYear.split(' ')[1].slice(-2)));
    var ExpectedEndRange = getQuarterDateRange( parseInt(ExpectedEndQnYear.split(' ')[0].slice(-1)),parseInt(ExpectedEndQnYear.split(' ')[1].slice(-2)));

    //var CreationRange = isCreationFullFilled? getQuarterDateRange(parseInt(creationQuarterLabelText.slice(-1)), parseInt(createYear)):null;
    //var UpdateRange = isUpdateFullFilled? getQuarterDateRange(parseInt(updateQuarterLabelText.slice(-1)), parseInt(updatedYear)):null;
    //var ExpectedRange = isExpectedFullFilled? getQuarterDateRange(parseInt(expectedQuarterLabelText.slice(-1)), parseInt(expectedYear)):null;
    var ContactIDs = getIDFromSelection(contactsQuerySelecter);
    var UserIDs = getIDFromSelection(usersQuerySelecter);
    var productID = getIDFromSelection(productsQuerySelecter);//document.getElementById('productQuerySelecter').value;
    var saleAreaID = getIDFromSelection(AreaQuerySelecter);//document.getElementById('AreaQuerySelecter').value;

    var queryText= document.getElementById('crmQuery').value;
    if (ContactIDs.length === 0) {
        ContactIDs = null;
    }

    if (UserIDs.length === 0) {
        UserIDs = null;
    }
    if (queryText === "") {
        queryText = null;
    }
    var query = {
        StartDate:timeFormater(CreationStartRange.startDate),
        EndDate:timeFormater(CreationEndRange.endDate),
        UpdateStart: timeFormater(UpdateStartRange.startDate),
        UpdateEnd: timeFormater(UpdateEndRange.endDate),
        ExpectedStart: timeFormater(ExpectedStartRange.startDate),
        ExpectedEnd: timeFormater(ExpectedEndRange.endDate),
        SaleAreaIDs: saleAreaID,
        ProductIDs: productID,
        ContactIDs: ContactIDs,
        UserIDs: UserIDs,
        Title: queryText,
        DeepSearch: true
    };
    if(productID.length === 0){
        query.ProductIDs = null;
    }
    if(saleAreaID.length === 0){
        query.SaleAreaIDs = null;
    }

    if (expectedYearRadios.length === 0 && !selectedExpectedQuarter) {
        query.ExpectedStart = null;
        query.ExpectedEnd = null;
    }
    
    if (updatedYearRadios.length === 0 && !selectedUpdateQuarter) {
        query.UpdateStart = null;
        query.UpdateEnd = null;
    }

    console.log("Query:",query);
    displayLeads(query);
    targetDisplay(query.SaleAreaIDs,query.ProductIDs,query.ExpectedStart,query.ExpectedEnd);

    // Rest of the code...
    
}