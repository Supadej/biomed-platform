window.onload = async function() {

  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get('id');
  
  await usersQueryInitializer();
  await productQueryInitializer();
  await contactQueryInitializer();
  await queryEvents();
  bindNavEvents();
  bindTabEvents();

  if (id) {
    console.log('ID found in URL:', id);
    currentID = id;
    await CalendarModal.open(id);
  }
  
}
let currentID = null;
let currentEventsData = []; // Store current events data for table view

function usersQueryInitializer() {
  return new Promise(async (resolve, reject) => {
    try {
      const myUser = await promiseMyUser();
      const users = await promiseUsers();
      const usersList = await users;
      for (const user of usersList) {
        user.color = await promiseColorById(user.Id);
      }
      usersList.sort((a, b) => a.FirstName.localeCompare(b.FirstName)); // Sort usersList by FirstName
      
      const dropDownData = usersList
        .filter(user => user.Enabled !== false) // Skip users where Enabled is false
        .map(user => ({
          value: user.Id,
          html: Label(user.color.color.code, user.FirstName + " " + user.LastName + " (" + user.Position + ")"),
          selected:  false//user.Id === myUser.Id // Check if the user is in the subUsers array
        }));

      let userDropdownMultiSelect = new MultiSelect(document.getElementById('usersQueryDropdown'), {
        data: dropDownData,
        placeholder: 'Select users',
        max: null,  // Maximum number of items that can be selected
        search: true,  // Enable the search box
        selectAll: true,  // Add a select all option
        dropdownHeight: "540px",  // Height of the dropdown
        onChange: function(value, text, element) {
          console.log('Change:', value, text, element);
        },
        onSelect: function(value, text, element) {
          console.log('Selected:', value, text, element);
        },
        onUnselect: function(value, text, element) {
          console.log('Unselected:', value, text, element);
        }
      });
      window.usersQuery = userDropdownMultiSelect; // Store the instance globally

      resolve();
    } catch (error) {
      reject(error);
    }
  });
}

function getFilter() {
  return new Promise((resolve) => {
    const filter = {};
    const title = document.getElementById('queryTitle').value;

    filter.Title = title === "" ? null : title;
    const responsibles = window.usersQuery.selectedValues;
    filter.UserIDs = responsibles.length === 0 ? null : responsibles;
    const contacts = window.contactsQuery.selectedValues;
    filter.ContactIDs = contacts.length === 0 ? null : contacts;
    const products = window.productsQuery.selectedValues;
    filter.ProductIDs = products.length === 0 ? null : products;
    
    // Add the "Only Main Responsible" filter
    const onlyMainResponsible = document.getElementById('onlyMainResponsible').checked;
    filter.OnlyMainResponsible = onlyMainResponsible;

    resolve(filter);
  });
}

async function querySearch(){
  await queryEvents();
  // Update the events table if it's currently visible
  if (document.getElementById('table-tab') && document.getElementById('table-tab').classList.contains('active')) {
    populateEventsTable();
  }

}

function productQueryInitializer() {
  return new Promise(async (resolve, reject) => {
    try {
      
      const productList = await promiseProducts();
      //const selectedProduct = eventData.EventProducts.map(product => product.ProductId);  
      productList.sort((a, b) => a.Name.localeCompare(b.Name)); // Sort productList by Name
      const productDropDownData = await Promise.all(productList.map(async product => ({
        value: product.Id,
        html: Label((await promiseColorById(product.Id)).color.code, product.Name),
        //selected: selectedProduct.includes(product.Id) // Check if the product is in the selectedProduct array
      })));


      let productDropdownMultiSelect = new MultiSelect(document.getElementById('productsQueryDropdown'), {
        data: productDropDownData,
        placeholder: 'Select users',
        max: null,  // Maximum number of items that can be selected
        search: true,  // Enable the search box
        selectAll: true,  // Add a select all option
        dropdownHeight: "540px",  // Height of the dropdown
        onChange: function(value, text, element) {
          console.log('Change:', value, text, element);
        },
        onSelect: function(value, text, element) {
          console.log('Selected:', value, text, element);
        },
        onUnselect: function(value, text, element) {
          console.log('Unselected:', value, text, element);
        }
      });
      window.productsQuery = productDropdownMultiSelect; // Store the instance globally

      resolve();
    } catch (error) {
      reject(error);
    }
  });
}


function contactQueryInitializer() {
  return new Promise(async (resolve, reject) => {
    try {
      
      const contactList = await promiseContacts();
      //const selectedContact = eventData.EventContacts.map(contact => contact.ContactId);  
      contactList.sort((a, b) => a.Name.localeCompare(b.Name)); // Sort contactList by Name    const contactDropDownData = await Promise.all(contactList.map(async contact => ({
      const contactDropDownData = await Promise.all(contactList.map(async contact => ({
        value: contact.Id,
        html: Label((await promiseColorById(contact.Id)).color.code, contact.Name),
        //selected: selectedContact.includes(contact.Id) // Check if the contact is in the selectedContact array
      })));
      let contactDropdownMultiSelect = new MultiSelect(document.getElementById('contactsQueryDropdown'), {
        data: contactDropDownData,
        placeholder: 'Select contacts',
        max: null,  // Maximum number of items that can be selected
        search: true,  // Enable the search box
        selectAll: true,  // Add a select all option
        dropdownHeight: "540px",  // Height of the dropdown
        onChange: function(value, text, element) {
          console.log('Change:', value, text, element);
        },
        onSelect: function(value, text, element) {
          console.log('Selected:', value, text, element);
        },
        onUnselect: function(value, text, element) {
          console.log('Unselected:', value, text, element);
        }
      });

      // Set the selected values
      // Attach the MultiSelect instance to the modal for cleanup
      window.contactsQuery = contactDropdownMultiSelect;
      resolve();
    } catch (error) {
      reject(error);
    }
  });
}



function bindNavEvents() {
  const prevBtn = document.querySelector('.ec-prev');
  const nextBtn = document.querySelector('.ec-next');

  if (prevBtn && nextBtn) {
      prevBtn.onclick = () => NavBarQueryEvents('prev');
      nextBtn.onclick = () => NavBarQueryEvents('next');
  }
}

function bindTabEvents() {
  const tableTab = document.getElementById('table-tab');
  if (tableTab) {
    tableTab.addEventListener('shown.bs.tab', function (event) {
      console.log('Table tab activated');
      populateEventsTable();
    });
  }
}

async function NavBarQueryEvents(direction) {
  console.log("NavBarQueryEvents",direction);
  await queryEvents();
  // Update the events table if it's currently visible
  if (document.getElementById('tableTab') && document.getElementById('tableTab').classList.contains('active')) {
    populateEventsTable();
  }
}



function emptyPromiseFunction() {
  return new Promise((resolve, reject) => {
    // Add logic here if needed
    resolve();
  });
}


async function queryEvents(clear = true,DeepDetails = false){
  showLoader();
  return new Promise( async (resolve, reject) => {
  const filter = await getFilter();
  filter.StartDate= timeFormater(ec.getView().activeStart);
  filter.EndDate= timeFormater(ec.getView().activeEnd);
  filter.DeepSearch = true;
  filter.DeepDetails = DeepDetails;
  if(clear){
    await removeAllEvents();
  }
  const events = await v2_promiseEvents(filter);
 
  const usersCache = await promiseUsers();//unused but cache it for promiseUserById
  console.log(events);
  
  // Filter events based on "Only Main Responsible" checkbox
  let filteredEvents = events;
  if (filter.OnlyMainResponsible && filter.UserIDs && filter.UserIDs.length > 0) {
    filteredEvents = events.filter(event => 
      filter.UserIDs.includes(event.MainUserID)
    );
  }
  
  // Store filtered events for table view
  currentEventsData = filteredEvents;
  
  const mappedEvents = filteredEvents.map(async event => {

    
    const startDate = event.StartDate.split('T')[0];
    const start = event.IsAllDay ? startDate : event.StartDate;
    const endDate = event.EndDate.split('T')[0];
    const end = event.IsAllDay ? endDate : event.EndDate;
    const color = await promiseColorById(event.MainUserID);
    const attendee = await promiseUserById(event.MainUserID); //don't use promiseUserById without cache it with promiseUsers() first, otherwise it will call the API every time.
    const attendeeName = attendee ? attendee.FirstName + " " + attendee.LastName + " ("+attendee.Position+")" : 'Unknown';
    const subAttendeeName = [];
    const subAttendeeColor = [];
    await Promise.all(event.Users.map(async user => {
      const subAttendee = await promiseUserById(user);
      if (subAttendee) {
        subAttendeeName.push(subAttendee.FirstName + " " + subAttendee.LastName + " (" + subAttendee.Position + ")");
        const color = await promiseColorById(user);
        subAttendeeColor.push(color.color.code);
      }
    }));
    return {
        id: event.Id,
        resourceIds: [event.MainUserID],
        allDay: event.IsAllDay,
        start: new Date(start),
        end: new Date(end),
        title: event.IsAllDay || startDate !== endDate ?  `<p class="m-1 p-1 rounded-5 c-shadow text-truncate ps-2" style="background-color:${color.color.code}; color:${color.textColor};"><span class="small">${startDate !== endDate? `<i class="fa-solid fa-calendar-week"></i> `+ (getRemainingDays(endDate,startDate,false)+1)+" Days ":`<i class="fa-solid fa-sun"></i> `}</span>${event.Title}</p>` :  `<p class="m-1 p-1 rounded-5 c-shadow text-truncate" style="background-color:white"><span class="c-text-shadow" style="color:${color.color.code}">⬤ </span><span class="small">${formatTimeOnly(start)}</span> ${event.Title}</p>`,
        display: 'auto',
        backgroundColor: 'transparent',
        textColor: 'black',
        classNames: ["text-truncate", "overflow-hidden"],
        extendedProps: {
          plan: event.Plan,
          attendees: [attendeeName],
          subAttendees: subAttendeeName,
          subAttendeeColor: subAttendeeColor,
          event: event,
          color: color,
        }
      };

  });
  const resolvedEvents = await Promise.all(mappedEvents);
  
  await ecAddEvents(resolvedEvents);
  hideLoader();
  resolve();
  });
}


async function removeAllEvents() {
  return new Promise((resolve) => {
    const events = ec.getEvents();
    events.forEach(event => {
      ec.removeEventById(event.id);
    });
    resolve();
  });
}

async function ecAddEvents(events){
  const eventAdding =  events.forEach(async event => {
    ec.addEvent(event);
  });
  //await Promise.all(eventAdding);
}

async function populateEventsTable() {
  const tableBody = document.getElementById('eventsTableBody');
  if (!tableBody) return;
  
  // Clear existing table content
  tableBody.innerHTML = '';
  
  // Fetch events with deep details
  showLoader();
  await queryEvents(true, true);
  hideLoader();
  
  if (currentEventsData.length === 0) {
    tableBody.innerHTML = '<tr><td colspan="12" class="text-center">No events found</td></tr>';
    return;
  }
  
  try {
    // Process each event for table display
    for (const event of currentEventsData) {
      const row = document.createElement('tr');
      
      // Get main responsible user info
      const mainUser = await promiseUserById(event.MainUserID);
      const mainUserName = mainUser ? `${mainUser.FirstName} ${mainUser.LastName}` : 'Unknown';
      const position = mainUser ? mainUser.Position : 'Unknown Position';
      // Get attendees info
      const attendeesNames = [];
      for (const userId of event.Users || []) {
        const user = await promiseUserById(userId);
        if (user) {
          attendeesNames.push(`${user.FirstName} ${user.LastName}`);
        }
      }
      
      // Get products info
      const productNames = [];
      for (const productId of event.EventProducts || []) {
        const product = await promiseProductById(productId);
        if (product) {
          productNames.push(product.Name);
        }
      }
      
      // Get contacts info
      const contactNames = [];
      for (const contactId of event.EventContacts || []) {
        const contact = await promiseContactById(contactId);
        if (contact) {
          contactNames.push(contact.Name);
        }
      }
      
      // Format dates
      const startDate = new Date(event.StartDate).toLocaleDateString();
      const endDate = new Date(event.EndDate).toLocaleDateString();
      const startTime = event.IsAllDay ? 'All Day' : new Date(event.StartDate).toLocaleTimeString();
      const endTime = event.IsAllDay ? 'All Day' : new Date(event.EndDate).toLocaleTimeString();
      
      // Determine status
      const now = new Date();
      const eventStart = new Date(event.StartDate);
      const eventEnd = new Date(event.EndDate);
      let status = '';
      let statusClass = '';
      
      if (now < eventStart) {
        status = 'Upcoming';
        statusClass = 'badge bg-primary';
      } else if (now >= eventStart && now <= eventEnd) {
        status = 'Ongoing';
        statusClass = 'badge bg-success';
      } else {
        status = 'Past';
        statusClass = 'badge bg-secondary';
      }
      
      // Truncate long text content for table display
      const truncateText = (text, maxLength = 100) => {
        if (!text) return 'None';
        if (text.length <= maxLength) return text;
        return text.substring(0, maxLength) + '...';
      };
      
      row.innerHTML = `
        <td class="fw-bold">${event.Title || 'Untitled'}</td>
        <td>
          <div>${startDate}</div>
          <small class="text-muted">${startTime}</small>
        </td>
        <td>
          <div>${endDate}</div>
          <small class="text-muted">${endTime}</small>
        </td>
        <td>
          <div>${mainUserName}</div>
          <small class="text-muted">${position}</small>
        </td>
        <td>
          ${attendeesNames.length > 0 ? 
            attendeesNames.slice(0, 2).join(', ') + 
            (attendeesNames.length > 2 ? ` +${attendeesNames.length - 2} more` : '') 
            : 'None'}
        </td>
        <td>
          ${productNames.length > 0 ? 
            productNames.slice(0, 2).join(', ') + 
            (productNames.length > 2 ? ` +${productNames.length - 2} more` : '') 
            : 'None'}
        </td>
        <td>
          ${contactNames.length > 0 ? 
            contactNames.slice(0, 2).join(', ') + 
            (contactNames.length > 2 ? ` +${contactNames.length - 2} more` : '') 
            : 'None'}
        </td>
        <td title="${event.Plan || ''}">
          <small>${event.Plan}</small>
        </td>
        <td title="${event.Report || ''}">
          <small>${event.Report}</small>
        </td>
        <td title="${event.Comment || ''}">
          <small>${event.Comment}</small>
        </td>
        <td><span class="${statusClass}">${status}</span></td>
        <td>
          <button class="btn btn-sm c-primary me-1" onclick="openModal(${event.Id})" title="Edit Event">
            <i class="fas fa-edit"></i>
          </button>
        </td>
      `;
      
      tableBody.appendChild(row);
    }
  } catch (error) {
    console.error('Error populating events table:', error);
    tableBody.innerHTML = '<tr><td colspan="12" class="text-center text-danger">Error loading events</td></tr>';
  }
}

const ec = new EventCalendar(document.getElementById("ec"), {
  view: "dayGridMonth",
  headerToolbar:{start: 'title', center: 'dayGridMonth,listMonth,listWeek,listDay,timeGridDay', end: 'prev,next'},
  buttonText:{dayGridMonth:'Month View',listMonth:'Month View(List)',listWeek:'Week View',listDay:'Day View',timeGridDay:'Time Grid Day'},
  selectable: true,
  selectLongPressDelay: 1000,
  select: function (info) {
    console.log("Info",info);
    openModal(null, info);
  },
  dateClick: function (info) {
    openModal(null, info);
    console.log("Info",info);
  },

  events: [
    // your list of events
  ],

  eventClick: function (info) {
    openModal(
      info.event.id,
      info
    );

    console.log("Info",info);
  },
  eventDrop: function (info) {
    openModal(
      info.event.id,
      info
    );
    console.log("Info",info);
  },
  eventResize: function (info) {
    openModal(
      info.event.id,
      info
    );
    //xalert('Drag and Drop is not implemented yet! the change will not save!', 2, 5000);
    console.log("Info",info);
  },
  eventMouseEnter: function (info) {
    console.log(info);
    // Remove any existing tooltip
    document.querySelectorAll('.ec-popup').forEach(el => el.remove());

    // Create tooltip element
    let tooltip = document.createElement('div');
    tooltip.classList.add('ec-popup');
    tooltip.innerHTML =`<div class="m-0 p-3 rounded-5 c-shadow c-con-tertiary" style="max-width:540px;">
    <h6 class="m-0 text-truncate fw-bold"><i class="fa-solid fa-pencil"></i> ${info.event.extendedProps.event.Title}</h6>
    <div class="d-flex justify-content-between m-0 p-0">
    ${info.event.extendedProps.event.IsAllDay?
      `<span class="m-0 p-0" style="font-size:smaller;"><i class="fa-solid fa-sun"></i> All Day</span>`:
      getRemainingDays(info.event.startDate,info.event.endDate,false)+1 > 1?
      `${getRemainingDays(info.event.startDate,info.event.endDate,false)+1} Days <i class="fa-solid fa-calendar-week"></i>`:
      `<span class="m-0 p-0 me-2" style="font-size:smaller;">${formatDateTime(info.event.start)}</span>
      <span class="m-0 p-0 ms-2" style="font-size:smaller;">${formatDateTime(info.event.end)}</span>`
    }  
    </div>
    <p class="m-0 text-truncate overflow-y-hidden" style="white-space: pre-line;max-height:540px;">${info.event.extendedProps.event.Plan}</p>
    <p class="m-1 p-1 rounded-5 c-shadow text-truncate" style="background-color:white"><span class="m-0 p-0 c-text-shadow" style="color:${info.event.extendedProps.color.color.code}">⬤ </span><span class="m-0 p-0" style="font-size:smaller;">${info.event.extendedProps.attendees[0]}</span> 
    </p>
    <div class="d-flex justify-content-start m-0 p-0 flex-wrap">
    ${
      info.event.extendedProps.subAttendees.length >  0? info.event.extendedProps.subAttendees.map((attendee, index) => {
        
          return `<p class="m-1 p-1 rounded-5 c-shadow text-truncate" style="background-color:white"><span class="m-0 p-0 c-text-shadow" style="color:${info.event.extendedProps.subAttendeeColor[index]}">⬤ </span><span class="m-0 p-0" style="font-size:smaller;">${attendee}</span> 
          </p>`;
        
      }).join('') : ''
    }

    
    </div>
    </div>`; // Customize content here

    // Style it (or use CSS)
    Object.assign(tooltip.style, {
        position: 'absolute',
        zIndex: 1000,
        whiteSpace: 'nowrap',
        pointerEvents: 'none',
        transition: 'none',
        width:'auto',
    });

    // Append tooltip to the document
    document.body.appendChild(tooltip);

    // Position it slightly above the event element
    let rect = info.el.getBoundingClientRect();
    let tooltipWidth = tooltip.offsetWidth;
    let left = rect.left + window.scrollX + (rect.width / 2) - (tooltipWidth / 2);
    let top = rect.top + window.scrollY - tooltip.offsetHeight - 5; // 5px spacing

    // Adjust to keep within the screen
    if (left < 0) left = 5; // Prevent left overflow
    if (left + tooltipWidth > window.innerWidth) left = window.innerWidth - tooltipWidth - 5; // Prevent right overflow
    if (top < 0) top = rect.bottom + window.scrollY + 5; // Move below if not enough space above

    tooltip.style.left = left + 'px';
    tooltip.style.top = top + 'px';
},

  eventMouseLeave: function () {
      document.querySelectorAll('.ec-popup').forEach(el => el.remove());
  },
});
document.querySelectorAll('.ec-center button').forEach(button => {
  button.addEventListener('click', (event) => {
    console.log(`Change View: ${event.target.textContent}`);
    querySearch();
    //alert(`Button clicked: ${event.target.textContent}`);
  });
});

function openModal(eventId = null,info = null){
  CalendarModal.info = info;
  currentID = eventId;
  if(eventId == null){
    //to be implement
    //create event
    CalendarModal.open(null,info);
    ec.unselect();
  }else{
    //edit event
    CalendarModal.open(eventId,info);

  }
}
(function () {
  async function open(eventId, info) {
      document.addEventListener("keydown", function (event) {
          if (event.key === "Escape") {
              close();
          }
      });
      if (document.getElementById("CalendarModal")) return; // Prevent duplicates
      const users = promiseUsers();
      const myUserRequest = promiseMyUser();
      const event = eventId? promiseEventById(eventId):{};
      const groupsRequest = promiseGroups();
      
      // Create modal container
      const modal = document.createElement("div");
      modal.id = "CalendarModal";
      Object.assign(modal.style, {
        position: "fixed",
        top: "0",
        left: "0",
        width: "100vw",
        height: "100vh",
        backgroundColor: "rgba(0, 0, 0, 0.8)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: "1000",
        opacity: "0",
        transition: "opacity 0.2s"
      });

      // Add a slight delay to make the transition visible
      setTimeout(() => {
        modal.style.opacity = "1";
      }, 0);

      // Create modal content
      const modalContent = document.createElement("div");
      Object.assign(modalContent.style, {
          padding: "0px",
          width: "95%",
          height: "95%",
          position: "relative"
      });
      modalContent.classList.add("c-surface","rounded-5");

      // Create close button
      const closeButton = document.createElement("button");
      closeButton.innerHTML = '<i class="fas fa-times"></i>';
      Object.assign(closeButton.style, {
          position: "absolute",
          top: "10px",
          right: "10px",
          border: "none",
          width: "30px",
          height: "30px",
          borderRadius: "50%",
          fontSize: "18px",
          cursor: "pointer"
      });
      closeButton.classList.add("c-error");
      closeButton.onclick = ()=>{
        if ((CalendarModal.info!== undefined && CalendarModal.info !== null) && typeof CalendarModal.info.revert === 'function' ) {
          CalendarModal.info.revert();
        }
        close();
      };
      const eventData = await event;
      console.log("Event Data",eventData);
      // Add modal content

      CalendarModal.saveEvent = async function saveEvent() {
        showLoader();
        if (eventId !== null && eventId !== undefined) {
          let changedComponent = await compareChange();
          let readableChanges = changedComponent.map(change => {
            let oldValue = Array.isArray(change.oldValue) ? change.oldValue.join(", ") : (typeof(change.oldValue)==='boolean'? change.oldValue:change.oldValue || "N/A");
            let newValue = Array.isArray(change.newValue) ? change.newValue.join(", ") : (typeof(change.newValue)==='boolean'? change.newValue:change.newValue || "N/A");
            return `${change.field}: ${oldValue} -> ${newValue}`;
          }).join("\n");
          await promiseCreateLog(readableChanges, JSON.stringify(changedComponent),null,parseInt(eventId), null,null,  null, 4);
        }

        eventData.StartDate = document.getElementById("startDate").value;
        eventData.EndDate = document.getElementById("endDate").value;
        eventData.IsAllDay = document.getElementById("allDay").checked;
        eventData.Title = document.getElementById("title").value;
        eventData.Plan = document.getElementById("plan").value;
        eventData.Report = document.getElementById("report").value;
        eventData.Comment = document.getElementById("comment").value;
        eventData.Users = CalendarModal.usersSelect.selectedValues;
        eventData.Products = CalendarModal.productsSelect.selectedValues;
        eventData.Contacts = CalendarModal.contactsSelect.selectedValues;
        eventData.MainUserID = eventId? eventData.MainUserID:myUser.Id;
          
        const startDate = eventData.StartDate.split('T')[0];
        const start = eventData.IsAllDay ? startDate : eventData.StartDate;
        const endDate = eventData.EndDate.split('T')[0];
        const end = eventData.IsAllDay ? endDate : eventData.EndDate;
        const color = await promiseColorById( eventData.MainUserID);
        const attendee = await promiseUserById(eventData.MainUserID); //don't use promiseUserById without cache it with promiseUsers() first, otherwise it will call the API every time.
        const attendeeName = attendee ? attendee.FirstName + " " + attendee.LastName + " ("+attendee.Position+")" : 'Unknown';
        const subAttendeeName = [];
        const subAttendeeColor = [];
        await Promise.all(eventData.Users.map(async user => {
          const subAttendee = await promiseUserById(user);
          if (subAttendee) {
            subAttendeeName.push(subAttendee.FirstName + " " + subAttendee.LastName + " (" + subAttendee.Position + ")");
            const color = await promiseColorById(user);
            subAttendeeColor.push(color.color.code);
          }
        }));

        const eventToUpdate =
        {
            id: eventId?eventData.Id:null,
            resourceIds: [eventData.MainUserID],
            allDay: eventData.IsAllDay,
            start: new Date(start),
            end: new Date(end),
            title: eventData.IsAllDay || startDate !== endDate ?  `<p class="m-1 p-1 rounded-5 c-shadow text-truncate ps-2" style="background-color:${color.color.code}; color:${color.textColor};"><span class="small">${startDate !== endDate? `<i class="fa-solid fa-calendar-week"></i> `+ (getRemainingDays(endDate,startDate,false)+1)+" Days ":`<i class="fa-solid fa-sun"></i> `}</span>${eventData.Title}</p>` :  `<p class="m-1 p-1 rounded-5 c-shadow text-truncate" style="background-color:white"><span class="c-text-shadow" style="color:${color.color.code}">⬤ </span><span class="small">${formatTimeOnly(start)}</span> ${eventData.Title}</p>`,
            display: 'auto',
            backgroundColor: 'transparent',
            textColor: 'black',
            classNames: ["text-truncate", "overflow-hidden"],
            extendedProps: {
              plan: eventData.Plan,
              attendees: [attendeeName],
              subAttendees: subAttendeeName,
              subAttendeeColor: subAttendeeColor,
              event: eventData,
              color: color,
            }
          };



        console.log(eventToUpdate);
        

        try {
          const result = await PromiseUpdateEvent(eventData.Id, eventData);
          console.log("Event updated successfully:", result);
          if(eventId !== null||eventId !== undefined){
            eventToUpdate.id = result;
          }
          eventId?ec.updateEvent(eventToUpdate):ec.addEvent(eventToUpdate);
          
          // Update the events table if it's currently visible
          await queryEvents();
          if (document.getElementById('tableTab') && document.getElementById('tableTab').classList.contains('active')) {
            populateEventsTable();
          }

          
          hideLoader();
          CalendarModal.close();
        } catch (error) {
          console.error("Failed to update event:", error);
          alert("Failed to update event: " + error.message);
        }
        
      }


      CalendarModal.deleteEvent = function deleteEvent() {
        document.getElementById("eventActionButtons").classList.add("d-none");
        document.getElementById("deleteActionButtons").classList.remove("d-none");
      }
      CalendarModal.deleteYes = async function yes() {
        showLoader();
        await promiseDeleteEventById(eventId);
        ec.removeEventById(eventId);
        
        // Update the events table if it's currently visible
        await queryEvents();
        if (document.getElementById('tableTab') && document.getElementById('tableTab').classList.contains('active')) {
          populateEventsTable();
        }
        
        hideLoader();
        CalendarModal.close();
      }
      CalendarModal.deleteNo =  function no() {
        document.getElementById("deleteActionButtons").classList.add("d-none");
        document.getElementById("eventActionButtons").classList.remove("d-none");
      }

      const content = document.createElement("div");
      content.innerHTML = `
          
          <div class="m-2 p-0 c-con-surface rounded-5 flex-fill col-12 col-lg-8 auto-width" >
            <div class="d-flex m-0 p-0">
              <h5 class="mt-4 mt-lg-2 ms-3 m-1 p-0 me-auto">
                <i class="fas fa-calendar"></i> Edit Event
              </h5>
              <div class="m-0 p-0 me-xl-0 me-3" id="eventActionButtons">
                <button class="c-ok c-shadow rounded-5 small py-2 m-2" style="min-width:72px;" id="saveBtn" onclick="CalendarModal.saveEvent()">Save</button>
                <button class="c-error c-shadow rounded-5 small py-2 m-2" style="min-width:72px;" id="deleteBtn" onclick="CalendarModal.deleteEvent()">Delete</button>
              </div>
              <div class="m-0 p-0 me-xl-0 me-3 d-none" id="deleteActionButtons">
                <button class="c-error c-shadow rounded-5 small py-2 m-2" style="min-width:72px;" id="yesBtn" onclick="CalendarModal.deleteYes()">Yes</button>
                <button class="c-ok c-shadow rounded-5 small py-2 m-2" style="min-width:72px;" id="noBtn" onclick="CalendarModal.deleteNo()">No</button>
              </div>
            </div>
            
            
            <div class="rounded-5 c-surface m-2 p-2 c-shadow d-flex auto-width position-relative mt-4 mt-lg-2">
              <span class="my-auto rounded-5 m-0 p-2 fw-bold c-con-primary flex-grow-0 d-none d-lg-block me-2">Title</span>
              <span class="rounded-5 m-0 p-1 c-shadow me-2 fw-bold c-con-primary flex-grow-0 d-lg-none d-block position-absolute top-0 start-0 translate-middle-y">Title</span>

              <input id="title" type="text" class="c-con-surface rounded-5 c-outline flex-fill" style="height:38px;">
            </div>

            <div class="rounded-5 c-surface m-2 p-2 c-shadow d-flex auto-width position-relative mt-4 mt-lg-2">
              <span class="my-auto rounded-5 m-0 p-2 fw-bold c-con-primary flex-grow-0 d-none d-lg-block me-2">Responsibles</span>
              <span class="rounded-5 m-0 p-1 c-shadow me-2 fw-bold c-con-primary flex-grow-0 d-lg-none d-block position-absolute top-0 start-0 translate-middle-y">Responsibles</span>

              <div id="usersContainer" class="c-con-surface rounded-5 d-flex flex-column c-outline flex-fill auto-width pe-3">
                <select id="usersDropdown" data-placeholder="Select options" class="rounded-5"  multiple="multiple" data-multi-select>

                </select>
              </div>
            </div>

            <div class="rounded-5 c-surface m-2 p-2 c-shadow d-flex auto-width position-relative mt-4 mt-lg-2">
              <span class="my-auto rounded-5 m-0 p-2 fw-bold c-con-primary flex-grow-0 d-none d-lg-block me-2">Quick Tag</span>
              <span class="rounded-5 m-0 p-1 c-shadow me-2 fw-bold c-con-primary flex-grow-0 d-lg-none d-block position-absolute top-0 start-0 translate-middle-y">Quick Tag</span>
              <select style="height:38px;" class="c-con-surface rounded-5 c-outline flex-fill auto-width" id="group"> 
                <option value="" disabled selected>Select a group</option>
              </select>
            </div>

            <div class="rounded-5 c-surface m-2 p-2 c-shadow d-flex auto-width position-relative mt-4 mt-lg-2">
              <span class="my-auto rounded-5 m-0 p-2 fw-bold c-con-primary flex-grow-0 d-none d-lg-block me-2">Contacts</span>
              <span class="rounded-5 m-0 p-1 c-shadow me-2 fw-bold c-con-primary flex-grow-0 d-lg-none d-block position-absolute top-0 start-0 translate-middle-y">Contacts</span>

              <div id="contactsContainer" class="auto-width c-con-surface rounded-5 d-flex flex-column c-outline flex-fill pe-3">
                  <select id="contactsDropdown" data-placeholder="Select options" class="rounded-5" multiple="multiple" data-multi-select>

                  </select>
              </div>
            </div>
            
            <div class="p-0 m-0 mx-0 d-flex flex-row flex-wrap justify-content-between"> 
              <div class="m-0 p-0 px-2 flex-grow-1">
                <div class="rounded-5 c-surface m-2 mx-0 p-2 c-shadow d-flex flex-grow-1 auto-width position-relative mt-4 mt-lg-2">
                  <span class="my-auto rounded-5 m-0 p-2 fw-bold c-con-primary flex-grow-0 d-none d-lg-block me-2">Start Date</span>
                  <span class="rounded-5 m-0 p-1 c-shadow me-2 fw-bold c-con-primary flex-grow-0 d-lg-none d-block position-absolute top-0 start-0 translate-middle-y">Start Date</span>

                  <input id="startDate" type="datetime-local" class="auto-width px-2 c-con-surface rounded-5 c-outline flex-fill" style="height:38px;">
                </div>
              </div>
              <div class="m-0 p-0 px-2 flex-grow-1"> 
                <div class="rounded-5 c-surface m-2 mx-0 p-2 c-shadow d-flex flex-grow-1 auto-width position-relative mt-4 mt-lg-2">
                  <span class="my-auto rounded-5 m-0 p-2 fw-bold c-con-primary flex-grow-0 d-none d-lg-block me-2">End Date</span>
                  <span class="rounded-5 m-0 p-1 c-shadow me-2 fw-bold c-con-primary flex-grow-0 d-lg-none d-block position-absolute top-0 start-0 translate-middle-y">End Date</span>

                  <input id="endDate" type="datetime-local" class="auto-width px-2 c-con-surface rounded-5 c-outline flex-fill" style="height:38px;">
                </div>
              </div>
              <div class="m-0 p-0 px-2 flex-grow-0 ms-auto">
                <div class="rounded-5 c-surface m-2 mx-0 p-2 c-shadow d-flex flex-shrink-0 mt-4 mt-lg-2">
                  <span class="my-auto rounded-5 m-0 p-2 fw-bold c-con-primary flex-grow-0 text-nowrap">All Day</span>
                  <input id="allDay" type="checkbox" class="mx-2 c-con-surface rounded-5 ">
                </div>
              </div>
              
            </div>
            
            <div class="rounded-5 c-surface m-2 p-2 c-shadow d-flex auto-width position-relative mt-4 mt-lg-2">
              <span class="my-auto rounded-5 m-0 p-2 fw-bold c-con-primary flex-grow-0 d-none d-lg-block me-2">Products</span>
              <span class="rounded-5 m-0 p-1 c-shadow me-2 fw-bold c-con-primary flex-grow-0 d-lg-none d-block position-absolute top-0 start-0 translate-middle-y">Products</span>

              <div id="productsContainer" class="auto-width c-con-surface rounded-5 d-flex flex-column c-outline flex-fill pe-3">
                  <select id="productsDropdown" data-placeholder="Select options" class="rounded-5" multiple="multiple" data-multi-select>

                  </select>
              </div>
            </div>
            <div class="rounded-5 c-surface m-2 p-2 c-shadow d-flex auto-width position-relative mt-4 mt-lg-2">
              <span class="my-auto rounded-5 m-0 p-2 fw-bold c-con-primary flex-grow-0 d-none d-lg-block me-2">Plan</span>
              <span class="rounded-5 m-0 p-1 c-shadow me-2 fw-bold c-con-primary flex-grow-0 d-lg-none d-block position-absolute top-0 start-0 translate-middle-y">Plan</span>

              <textarea id="plan" row="10" style="height: 200px;" class="auto-width p-3 c-con-surface rounded-5 c-outline flex-fill"></textarea>
            </div>
            <div class="rounded-5 c-surface m-2 p-2 c-shadow d-flex auto-width position-relative mt-4 mt-lg-2">
              <span class="my-auto rounded-5 m-0 p-2 fw-bold c-con-primary flex-grow-0 d-none d-lg-block me-2">Report</span>
              <span class="rounded-5 m-0 p-1 c-shadow me-2 fw-bold c-con-primary flex-grow-0 d-lg-none d-block position-absolute top-0 start-0 translate-middle-y">Report</span>

              <textarea id="report" row="10" style="height: 200px;" class="auto-width p-3 c-con-surface rounded-5 c-outline flex-fill"></textarea>
            </div>
            <div class="rounded-5 c-surface m-2 p-2 c-shadow d-flex auto-width position-relative mt-4 mt-lg-2">
              <span class="my-auto rounded-5 m-0 p-2 fw-bold c-con-primary flex-grow-0 d-none d-lg-block me-2">Comment</span>
              <span class="rounded-5 m-0 p-1 c-shadow me-2 fw-bold c-con-primary flex-grow-0 d-lg-none d-block position-absolute top-0 start-0 translate-middle-y">Comment</span>

              <textarea id="comment" row="10" style="height: 200px;" class="auto-width p-3 c-con-surface rounded-5 c-outline flex-fill"></textarea>
            </div>
          </div>
          <div class="c-primary c-shadow rounded-5 flex-fill p-3 m-0 col-12 col-lg-3 d-flex flex-column" id="logContainer">Logging
            <div class="d-flex m-0 p-2 my-2 justify-content-evenly c-con-surface rounded-5">
                    <button class="c-surface c-shadow col-3 rounded-5 small py-2" onclick="addFile()">Add File</button>
                    <button class="c-surface c-shadow col-3 rounded-5 small py-2" id="bindingBtn" onclick="addBinder()">Pickup Binder</button>
                    <button class="c-ok c-shadow col-2 d-none rounded-5 small py-2" id="dropBtn" onclick="dropBinder()">Drop</button>
                    <button class="c-error c-shadow col-2 d-none rounded-5 small py-2" id="cancelBtn" onclick="cancelBinder()">Cancel</button>
                    <button class="c-surface c-shadow col-3 rounded-5 small py-2" onclick="addText()" id="addLogBtn">Add Log</button>
                    <button class="c-ok c-shadow col-3 d-none rounded-5 small py-2" onclick="sendText()" id="saveLogBtn">Save Log</button>
            </div>
            <div class="rounded-5 c-surface m-0 p-2 c-outline d-none" id="logTextarea">
                    <textarea class="m-0 p-3 c-con-surface rounded-5 c-outline w-100" aria-label="Log Entry" id="logTextareaValue"></textarea>
            </div>
            <div class="rounded-5 c-con-surface m-0 p-2 c-shadow d-flex flex-column flex-fill" id="logList">
            </div>
          </div>
          `;
      content.classList.add("d-flex","flex-row","flex-wrap","h-100","overflow-y-auto","rounded-5");
      // Assemble elements
      modalContent.appendChild(closeButton);
      modalContent.appendChild(content);
      modal.appendChild(modalContent);
      document.body.appendChild(modal);

      const groups = await groupsRequest;
      groups.sort((a, b) => a.GroupName.localeCompare(b.GroupName)); // Sort groups by Name
      const groupSelect = document.getElementById("group");
      groups.forEach(async group => {
        const color =  await promiseColorById(group.Id);
        const option = document.createElement("option");
        const labelDiv = Label(color.color.code, group.GroupName, true);
        option.value = group.Id;
        option.innerHTML = labelDiv.innerHTML;
        option.style.cssText = labelDiv.style.cssText;
        Array.from(labelDiv.classList).forEach(cls => option.classList.add(cls));
        
        //option.textContent = group.GroupName;
        
        groupSelect.appendChild(option);
        
      });
      groupSelect.addEventListener('change', async (event) => {
        const selectedGroupId = event.target.value;
        const groupsMembers = (await promiseGroupMembers(selectedGroupId)).GroupUsers.map(user => user.UserId);
        CalendarModal.usersSelect.selectValues(groupsMembers);
        console.log('Selected Group ID:', groupsMembers);
        // Add logic to handle the group selection change
      });

      const usersList = await users;
      for (const user of usersList) {
        user.color = await promiseColorById(user.Id);
      }

      const myUser =  await myUserRequest;
      myUser.color = await promiseColorById(myUser.Id);

      const MainUser = eventId? usersList.find(user => user.Id === eventData.MainUserID):myUser;
      const MainUserColor = MainUser ? MainUser.color.color.code : '#000000'; // Default color if not found
      const object = Label(MainUserColor,MainUser.FirstName + " " + MainUser.LastName + " (" + MainUser.Position + ")",true);
      object.classList.remove("m-1");
      object.classList.add("m-3","mb-0");
      console.log("Main User",object);
      const usersContainer = document.getElementById("usersContainer");
      if (usersContainer) {
        usersContainer.insertBefore(object, usersContainer.firstChild);    } else {
        console.error("Element with ID 'usersContainer' not found.");
      }
      
      const subUsers =eventId? eventData.EventUsers.map(user => user.UserId):[]; 
      usersList.sort((a, b) => a.FirstName.localeCompare(b.FirstName)); // Sort usersList by FirstName

      const dropDownData = usersList
        .filter(user => user.Enabled !== false && user.Id !== MainUser.Id) // Skip users where Enabled is false
        .map(user => ({
          value: user.Id,
          html: Label(user.color.color.code, user.FirstName + " " + user.LastName + " (" + user.Position + ")"),
          selected: subUsers.includes(user.Id) // Check if the user is in the subUsers array
        }));

      console.log("List of Users",usersList);
       
    
      let userDropdownMultiSelect = new MultiSelect(document.getElementById('usersDropdown'), {
        data: dropDownData,
        placeholder: 'Select users',
        max: null,  // Maximum number of items that can be selected
        search: true,  // Enable the search box
        selectAll: false,  // Add a select all option
        dropdownHeight: "540px",  // Height of the dropdown
        onChange: function(value, text, element) {
          console.log('Change:', value, text, element);
        },
        onSelect: function(value, text, element) {
          console.log('Selected:', value, text, element);
        },
        onUnselect: function(value, text, element) {
          console.log('Unselected:', value, text, element);
        }
      });

      // Set the selected values
      // Attach the MultiSelect instance to the modal for cleanup
      CalendarModal.usersSelect = userDropdownMultiSelect;



      const contactList = await promiseContacts();
      const selectedContact =eventId? eventData.EventContacts.map(contact => contact.ContactId):[];  
      contactList.sort((a, b) => a.Name.localeCompare(b.Name)); // Sort contactList by Name    const contactDropDownData = await Promise.all(contactList.map(async contact => ({
      const contactDropDownData = await Promise.all(contactList.map(async contact => ({
        value: contact.Id,
        html: Label((await promiseColorById(contact.Id)).color.code, contact.Name),
        selected: selectedContact.includes(contact.Id) // Check if the contact is in the selectedContact array
      })));

    

      let contactDropdownMultiSelect = new MultiSelect(document.getElementById('contactsDropdown'), {
        data: contactDropDownData,
        placeholder: 'Select contacts',
        max: null,  // Maximum number of items that can be selected
        search: true,  // Enable the search box
        selectAll: false,  // Add a select all option
        dropdownHeight: "540px",  // Height of the dropdown
        onChange: function(value, text, element) {
          console.log('Change:', value, text, element);
        },
        onSelect: function(value, text, element) {
          console.log('Selected:', value, text, element);
        },
        onUnselect: function(value, text, element) {
          console.log('Unselected:', value, text, element);
        }
      });

      // Set the selected values
      // Attach the MultiSelect instance to the modal for cleanup
      CalendarModal.contactsSelect = contactDropdownMultiSelect;






      const productList = await promiseProducts();
      const selectedProduct =eventId? eventData.EventProducts.map(product => product.ProductId):[];  
      productList.sort((a, b) => a.Name.localeCompare(b.Name)); // Sort productList by Name
      const productDropDownData = await Promise.all(productList.map(async product => ({
        value: product.Id,
        html: Label((await promiseColorById(product.Id)).color.code, product.Name),
        selected: selectedProduct.includes(product.Id) // Check if the product is in the selectedProduct array
      })));


      let productDropdownMultiSelect = new MultiSelect(document.getElementById('productsDropdown'), {
        data: productDropDownData,
        placeholder: 'Select users',
        max: null,  // Maximum number of items that can be selected
        search: true,  // Enable the search box
        selectAll: false,  // Add a select all option
        dropdownHeight: "540px",  // Height of the dropdown
        onChange: function(value, text, element) {
          console.log('Change:', value, text, element);
        },
        onSelect: function(value, text, element) {
          console.log('Selected:', value, text, element);
        },
        onUnselect: function(value, text, element) {
          console.log('Unselected:', value, text, element);
        }
      });

      // Set the selected values
      // Attach the MultiSelect instance to the modal for cleanup
      CalendarModal.productsSelect = productDropdownMultiSelect;
      //document.getElementById('usersDropdown').classList.add('rounded-5');
      if(eventId === null || eventId === undefined){
        console.log("Create Event Mode");
        eventData.Title = "";
        eventData.StartDate =info.dateStr? timeFuck(info.dateStr.split('T')[0] + 'T09:00:00'):info.startStr?timeFuck(info.startStr.split('T')[0] + 'T09:00:00'):new Date().setHours(9, 0, 0); // Set time to 9:00 AM
        eventData.EndDate = info.dateStr 
          ? timeFuck(new Date(info.dateStr.split('T')[0] + 'T10:00:00').setDate(new Date(info.dateStr.split('T')[0]).getDate())) 
          : info.startStr 
          ? timeFuck(new Date(info.endStr.split('T')[0] + 'T10:00:00').setDate(new Date(info.endStr.split('T')[0]).getDate() - 1)) 
          : new Date().setHours(10, 0, 0);
        eventData.IsAllDay = info.dateStr? false:true;
        eventData.Plan = "";
        eventData.Report = "";
        eventData.Comment = "";
      }
      //1 day = 86400000
      document.getElementById('title').value = eventData.Title;
      document.getElementById('startDate').value = (info && info.oldEvent && info.event) 
        ? timeFuck(new Date(info.event.start.getTime()+ 0).toISOString().split('T')[0] + 'T' + eventData.StartDate.split('T')[1]) 
        : timeFuck(eventData.StartDate);
      document.getElementById('endDate').value = (info && info.oldEvent && info.event) 
        ? timeFuck(new Date(info.event.end.getTime()).toISOString().split('T')[0] + 'T' + eventData.EndDate.split('T')[1]) 
        : timeFuck(eventData.EndDate);
      document.getElementById('allDay').checked = eventData.IsAllDay;
      document.getElementById('plan').value = eventData.Plan;
      document.getElementById('report').value = eventData.Report;
      document.getElementById('comment').value = eventData.Comment;
      autoload();
      loadBinder();
      if (eventId !== null && eventId !== undefined) {
        cachingObject();
      }




  }

  function close() {
    currentID = null;
    const modal = document.getElementById("CalendarModal");
    if (window.userDropdownMultiSelect) {
      window.userDropdownMultiSelect.destroy();
      window.userDropdownMultiSelect = null;
    }
    if (modal) modal.remove();
    if(CalendarModal) CalendarModal = {open,close};
  }
  let usersSelect = {};
 

  // Expose functions globally
  window.CalendarModal = { open, close};
})();


async function PromiseUpdateEvent(id, eventData) {
  return new Promise((resolve, reject) => {
    // Add logic here if needed
    var token = readToken();
    var xhr = new XMLHttpRequest();
    var urlEvent = id ? "/biomedapi/v2/event/update" : "/biomedapi/v2/event/create";
    var data = {
      Id: id,
      Title: eventData.Title,
      Description: "",
      StartDate: timeFormater(eventData.StartDate),
      EndDate: timeFormater(eventData.EndDate),
      IsAllDay: eventData.IsAllDay,
      Plan: eventData.Plan,
      Report: eventData.Report,
      Comment: eventData.Comment,
      Location: null,
      ProductIDs: eventData.Products,
      Conferenceurl: "",
      Mainuserid: eventData.MainUserID,
      MaincontactID: null,
      SubUserIDs: eventData.Users,
      SubContactIDs: eventData.Contacts,
    };

    xhr.open("POST", url + urlEvent, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + token);
    xhr.onreadystatechange = function () {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          //callback(null, xhr.responseText); // No error
          resolve(xhr.responseText);
        } else {
          reject(
            new Error(
              "Request failed with status " + xhr.status + " " + xhr.responseText
            )
          );
        }
      }
    };
    xhr.send(JSON.stringify(data));
    
  });
}

async function promiseDeleteEventById(id) {
  return new Promise((resolve, reject) => {
    // Add logic here if needed
    var token = readToken();
    var xhr = new XMLHttpRequest();
    var urlEvent = "/biomedapi/v2/event/delete" ;
    var data = {
      Id: id,
    };

    xhr.open("POST", url + urlEvent, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + token);
    xhr.onreadystatechange = function () {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          //callback(null, xhr.responseText); // No error
          resolve(xhr.responseText);
        } else {
          reject(
            new Error(
              "Request failed with status " + xhr.status + " " + xhr.responseText
            )
          );
        }
      }
    };
    xhr.send(JSON.stringify(data));
    
  });
}