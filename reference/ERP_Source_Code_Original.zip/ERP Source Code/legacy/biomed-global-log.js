var logLeadId = (typeof leadid !== 'undefined' && !isNaN(leadid)) ? parseInt(leadid) : null;
var logHelpdeskTicketId = (typeof hdid !== 'undefined' && !isNaN(hdid)) ? parseInt(hdid) : null;
var logActivityId = (typeof activityid !== 'undefined' && !isNaN(activityid)) ? parseInt(activityid) : null;
//ahhhhhhhhhhhhhhhhhhhhhhhhhhhh
//ah
//ah logEventId is too dynamic so it is not defined here
var logEventId = function (){
   
    return (typeof currentID !== 'undefined' && currentID !== null && !isNaN(currentID)) ? parseInt(currentID) : null;
};
function toggleVisible(){
    document.getElementById('addLogBtn').classList.toggle('d-none');
    document.getElementById('saveLogBtn').classList.toggle('d-none');
};
function addText(){
    toggleVisible();
    
    document.getElementById('logTextarea').classList.remove('d-none');
    console.log(document.getElementById('logTextarea'));
};
function sendText(){
    toggleVisible();
    document.getElementById('logTextarea').classList.add('d-none');
    const logValue = document.getElementById('logTextareaValue').value;
    if(logValue === null || logValue === ''){
        console.error('Log value is empty');
        return;
    }
    document.getElementById('logTextareaValue').value = '';
    myUserRequest(function(err,user){
        if(err){
            console.error(err);
            return;
        }
        
        createLog(logValue, "", logLeadId,logEventId(), user.Id, logHelpdeskTicketId, logActivityId, 0);
    });
}


function loadLogs(id, leadid, eventid, ticketid, activityid,userid){
    const xhr = new XMLHttpRequest();
    [id, leadid, eventid, ticketid, activityid, userid].forEach((param, index) => {
        if (param === undefined || param === null||param === NaN) {
            switch (index) {
                case 0: id = null; break;
                case 1: leadid = null; break;
                case 2: eventid = null; break;
                case 3: ticketid = null; break;
                case 4: activityid = null; break;
                case 5: userid = null; break;
            }
        }
    });
    xhr.open('POST', url+'/biomedapi/log/get', true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    const logRequest = {
        id: id,
        LeadId: leadid,
        EventId: eventid,
        UserId: userid,
        HelpdeskTicketId: ticketid,
        ActivityId: activityid
    };

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                const logs = JSON.parse(xhr.responseText);
                console.log('Logs loaded successfully:', logs);
                // Process logs as needed
                displayLogs(logs);
            } else {
                console.error('Error loading logs:', xhr.statusText);
            }
        }
    };
    console.log('Sending log request:', logRequest);
    xhr.send(JSON.stringify(logRequest));
    
}
function displayLogs(logs){
    console.log('Displaying logs:', logs);
    if (!document.getElementById('logList')) {
        console.error('logList element does not exist. Skipping log display.');
        return;
    }
    document.getElementById('logList').innerHTML = '';
    logs.forEach(log => {
        getUserById(function(err, user){
            if(err){
                console.error(err);
                return;
            }
            let header = '';
            let icon = '';
            switch (log.Type) { 
                case "Text": header = "Message"; icon = "fi fi-rr-poll-h"; break;
                case "File": header = 'File'; icon = "fi fi-rr-document"; break;
                case "Binder": header = 'Binder'; icon = "fi fi-rr-link-alt"; break;
                case "System": header = 'System'; icon = "fi fi-rr-api";break;
                default: header = 'Message'; icon = "fi fi-rr-poll-h"; break;
            }
            const logElement = document.createElement('div');
            logElement.className = 'm-1 p-1 rounded biomed-bg-light';

            const logHeader = document.createElement('p');
            logHeader.className = 'm-0 p-0';
            logHeader.innerHTML = `<strong class="m-0 p-0 fs-6">${header}</strong> <i class="${icon}"></i> <em><small> Date:${timeFormater(log.DateTime)}</small></em>`;
            logElement.appendChild(logHeader);

            const logText = document.createElement('span');
            logText.innerHTML = log.LogValue.replace(/->/g, '⮞').replace(/^(.*?):/gm, function(match, p1) {
                const formatted = p1.replace(/([a-z])([A-Z])/g, '$1 $2'); // Add space before uppercase letter
                return `<strong>${formatted.charAt(0).toUpperCase() + formatted.slice(1)}:</strong>`; // Capitalize first letter
            });
            logText.className = 'text-break';
            logText.style = 'white-space: pre-line;';
            logElement.appendChild(logText);
            if(log.Type=="File"){
                let fileType = determineFileType(log.SystemLog);
                logText.textContent = 'Filetype:'+fileType+"\n";   
                
                const logFile = document.createElement('a');
                logFile.href = "./storage/" + log.SystemLog;
                logFile.textContent = log.LogValue;
                logFile.className = 'text-break';
                logFile.target = '_blank'; // Open in new tab
                logElement.appendChild(logFile);
                if(fileType == 'Images File'){
                    logFile.textContent = '';
                    const logImg = document.createElement('img');
                    logImg.src = "./storage/" + log.SystemLog;
                    logImg.className = 'img-fluid';
                    logImg.style.maxHeight = '200px';
                    logFile.appendChild(logImg);
                    
                }
            }
            if(log.Type=="Binder"){
                let binderData = JSON.parse(log.SystemLog);
                let report = '';
                if(log.LogValue !== null&&!log.LogValue.includes('<->')){
                    let objectName = JSON.parse(log.LogValue);
                    objectName.forEach(item => {
                        switch (item.Key) {
                            case 'LeadId':
                                report += `<a href="./crm-detail.html?leadid=${binderData.logLeadId}"><strong>${item.Value}</strong></a> <small>Lead</small> ⮜⬥⮞ `;
                                break;
                            case 'EventId':
                                report += `<a href="./event.html?id=${binderData.logEventId}"><strong>${item.Value}</strong></a> <small>Event</small> ⮜⬥⮞ `;
                                break;
                            case 'HelpdeskTicketId':
                                report += `<a href="./helpdesk-detail.html?leadid=${binderData.logHelpdeskTicketId}"><strong>${item.Value}</strong></a> <small>Helpdesk</small> ⮜⬥⮞ `;
                                break;
                            case 'ActivityId':
                                report += `<a href="./project-activity.html?activityid=${binderData.logActivityId}"><strong>${item.Value}</strong></a> <small>Activity</small> ⮜⬥⮞ `;
                                break;
                        }
                    });
                    logText.innerHTML = 'Binding between ' + report.slice(0, -5); // Remove the trailing ' <-> '


                }else{
                    if (binderData.logLeadId !== null) report += `<a href="./crm-detail.html?leadid=${binderData.logLeadId}">Lead (${binderData.logLeadId})</a> <-> `;
                    if (binderData.logEventId !== null) report += `<a href="./event.html?id=${binderData.logEventId}">Event (${binderData.logEventId})</a> <-> `;
                    if (binderData.logHelpdeskTicketId !== null) report += `<a href="./helpdesk-detail.html?leadid=${binderData.logHelpdeskTicketId}">Helpdesk (${binderData.logHelpdeskTicketId})</a> <-> `;
                    if (binderData.logActivityId !== null) report += `<a href="./project-activity.html?activityid=${binderData.logActivityId}">Activity (${binderData.logActivityId})</a> <-> `;
                    logText.innerHTML = 'Binding between ' + report.slice(0, -5); // Remove the trailing ' <-> '
                }
                
            }
            

            
            const logUser = document.createElement('p');
            logUser.className = 'm-0 p-0';
            logUser.innerHTML = `<em><small> -${user.FirstName} ${user.LastName} (${user.Position})</small></em>`;
            logElement.appendChild(logUser);
            document.getElementById('logList').prepend(logElement);
        },log.UserId);
        

    });

}
function createLog(logValue, systemLog, leadId, eventId, userId, helpdeskTicketId, activityId, type, callback) {
    //Type 0 = Text 2 = File 3 = Binder 4 = System
    if (type === null || !Number.isInteger(type)) {
        console.error('Invalid type: must be a non-null integer');
        if (callback) callback(new Error('Invalid type: must be a non-null integer'));
        return;
    }
    const logData = {
        LogValue: logValue,
        SystemLog: systemLog,
        Visible: true,
        LeadId: leadId,
        EventId: eventId,
        UserId: userId,
        HelpdeskTicketId: helpdeskTicketId,
        ActivityId: activityId,
        Type: type
    };

    const xhr = new XMLHttpRequest();
    xhr.open('POST', url+'/biomedapi/log/create', true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                console.log('Log created successfully:', JSON.parse(xhr.responseText));
                if (callback) callback(null, JSON.parse(xhr.responseText));
            } else {
                console.error('Error creating log:', xhr.statusText);
                if (callback) callback(new Error('Error creating log: ' + xhr.statusText));
            }
            autoload();
        }
    };

    xhr.send(JSON.stringify(logData));
}

function promiseCreateLog(logValue, systemLog, leadId, eventId, userId, helpdeskTicketId, activityId, type) {
    return new Promise((resolve, reject) => {
        createLog(logValue, systemLog, leadId, eventId, userId, helpdeskTicketId, activityId, type, (err, result) => {
            if (err) {
                reject(err);
            } else {
                resolve(result);
            }
        });
    });
}

function addFile(){
    uploadFile(function(err, file){
        if(err){
            console.error(err);
            return;
        }
        const fileName = file.split('_').slice(2).join('_');
        createLog(fileName, file, logLeadId,logEventId(), null, logHelpdeskTicketId, logActivityId, 2);
    });


}

function determineFileType(fileName) {
    const extension = fileName.split('.').pop().toLowerCase();

    const fileTypes = {
        images: ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp', 'tiff'],
        pdf: ['pdf'],
        word: ['doc', 'docx'],
        excel: ['xls', 'xlsx', 'csv'],
        powerpoint: ['ppt', 'pptx'],
        text: ['txt', 'rtf', 'log'],
        audio: ['mp3', 'wav', 'aac', 'ogg', 'flac', 'wma'],
        video: ['mp4', 'avi', 'mov', 'wmv', 'flv', 'mkv', 'webm'],
        archive: ['zip', 'rar', '7z', 'tar', 'gz'],
        code: ['html', 'css', 'js', 'json', 'xml', 'py', 'java', 'cpp', 'c', 'cs', 'php', 'rb', 'go', 'swift', 'ts', 'sh', 'sql'],
        executable: ['exe', 'msi', 'bat', 'sh', 'apk', 'dmg'],
        diskImage: ['iso', 'img']
    };

    for (const [type, extensions] of Object.entries(fileTypes)) {
        if (extensions.includes(extension)) {
            return type.charAt(0).toUpperCase() + type.slice(1) + ' File';
        }
    }

    return 'Unknown File Type';
}
function autoload(){
    if ((logLeadId === null || isNaN(logLeadId)) && 
        (logEventId() === null || isNaN(logEventId())) && 
        (logHelpdeskTicketId === null || isNaN(logHelpdeskTicketId)) && 
        (logActivityId === null || isNaN(logActivityId))) {
        console.error('At least one of logLeadId, logEventId, logHelpdeskTicketId, or logActivityId must be non-null and not NaN');
        return;
    }
    console.log('Loading logs...');
    console.log(logLeadId,logEventId(),logHelpdeskTicketId,logActivityId);
    loadLogs(null,logLeadId,logEventId(),logHelpdeskTicketId,logActivityId,null);
}
autoload();

function addBinder(){
    const binderTemporary = {
        logLeadId: (logLeadId !== null && Number.isInteger(logLeadId)) ? logLeadId : null,
        logEventId: (logEventId() !== null && Number.isInteger(logEventId())) ? logEventId() : null,
        logHelpdeskTicketId: (logHelpdeskTicketId !== null && Number.isInteger(logHelpdeskTicketId)) ? logHelpdeskTicketId : null,
        logActivityId: (logActivityId !== null && Number.isInteger(logActivityId)) ? logActivityId : null
    };
    sessionStorage.setItem('binderTemporary', JSON.stringify(binderTemporary));
    console.log('Binder data saved:', binderTemporary);
    loadBinder();
}

function loadBinder(){
    if (!document.getElementById('bindingBtn')) {
        console.error('bindingBtn element does not exist. Skipping Binder Loading.');
        return;
    }
    const binderTemporary = sessionStorage.getItem('binderTemporary');
    if (binderTemporary) {
        const parsedBinder = JSON.parse(binderTemporary);
        console.log('Binder data loaded:', parsedBinder);
        document.getElementById('bindingBtn').classList.add('d-none');
        document.getElementById('dropBtn').classList.remove('d-none');
        document.getElementById('cancelBtn').classList.remove('d-none');
        
        const isBinderValid = () => {
            const { logLeadId: binderLeadId, logEventId: binderEventId, logHelpdeskTicketId: binderHelpdeskId, logActivityId: binderActivityId } = parsedBinder;

            const localLeadId = logLeadId;
            const localEventId = logEventId();
            const localHelpdeskId = logHelpdeskTicketId;
            const localActivityId = logActivityId;

            const binderIds = [binderLeadId, binderEventId, binderHelpdeskId, binderActivityId];
            const localIds = [localLeadId, localEventId, localHelpdeskId, localActivityId];

            for (let i = 0; i < binderIds.length; i++) {
                if (binderIds[i] !== null && localIds[i] !== null) {
                    return false;
                }
            }
            return true;
        };

        if (!isBinderValid()) {
            console.log('Binder validation failed: conflicting IDs');
            document.getElementById('dropBtn').setAttribute('disabled',"");

            return;
        }else{
            console.log('Binder validation passed');
        }
        // Process the binder data as needed
    } else {
        document.getElementById('bindingBtn').classList.remove('d-none');
        document.getElementById('dropBtn').classList.add('d-none');
        document.getElementById('cancelBtn').classList.add('d-none');
        console.log('No binder data found in sessionStorage');
    }
};

function cancelBinder(){
    sessionStorage.removeItem('binderTemporary');
    console.log('Binder data removed from sessionStorage');
    loadBinder();
};

function dropBinder(){
    const binderTemporary = JSON.parse(sessionStorage.getItem('binderTemporary'));
    if (!binderTemporary) {
        console.error('No binder data found in sessionStorage');
        return;
    }

    const { logLeadId: binderLeadId, logEventId: binderEventId, logHelpdeskTicketId: binderHelpdeskId, logActivityId: binderActivityId } = binderTemporary;

    const localLeadId = logLeadId;
    const localEventId = logEventId();
    const localHelpdeskId = logHelpdeskTicketId;
    const localActivityId = logActivityId;

    const binderIds = [binderLeadId, binderEventId, binderHelpdeskId, binderActivityId];
    const localIds = [localLeadId, localEventId, localHelpdeskId, localActivityId];

    for (let i = 0; i < binderIds.length; i++) {
        if (binderIds[i] !== null && localIds[i] !== null) {
            console.error('Binder validation failed: conflicting IDs');
            return;
        }
    }

    const newBinder = {
        logLeadId: binderLeadId !== null ? binderLeadId : localLeadId,
        logEventId: binderEventId !== null ? binderEventId : localEventId,
        logHelpdeskTicketId: binderHelpdeskId !== null ? binderHelpdeskId : localHelpdeskId,
        logActivityId: binderActivityId !== null ? binderActivityId : localActivityId
    };

    let report = '';
    if (newBinder.logLeadId !== null) report += `Lead (${newBinder.logLeadId}) <-> `;
    if (newBinder.logEventId !== null) report += `Event (${newBinder.logEventId}) <-> `;
    if (newBinder.logHelpdeskTicketId !== null) report += `Helpdesk (${newBinder.logHelpdeskTicketId}) <-> `;
    if (newBinder.logActivityId !== null) report += `Activity (${newBinder.logActivityId}) <-> `;

    // Remove the trailing ' <-> ' if it exists
    if (report.endsWith(' <-> ')) {
        report = report.slice(0, -5);
    }

    console.log(report);

    console.log('New binder data saved:', newBinder);
    createLog("Binding between "+report, JSON.stringify(newBinder), newBinder.logLeadId, newBinder.logEventId, null, newBinder.logHelpdeskTicketId, newBinder.logActivityId, 3);
    sessionStorage.removeItem('binderTemporary');
    loadBinder();
};



loadBinder();