const urlParams = new URLSearchParams(window.location.search);
const leadid = urlParams.get("activityid");

const modalUsersList = document.getElementById("modalUsersList");
const select = document.getElementById("usersSelecter");
const groupSelect = document.getElementById("groupSelecter");
const contactSelect = document.getElementById("contactsSelecter");
const mainContactSelect = document.getElementById("mainContactsSelecter");

const modalContact = document.getElementById("modalContact");
const mainContactsList = document.getElementById("mainContactsList");

const modalContactsList = document.getElementById("modalContactsList");

// Sync modalIndividualPermissionsList with individualPermissionsUsersList
function syncContactsList() {
    const mainContactsList = document.getElementById('mainContactsList');
    mainContactsList.innerHTML = modalContactsList.innerHTML;
}

// Call the syncPermissionsList function whenever there is a change in modalIndividualPermissionsList
const observer = new MutationObserver(syncContactsList);
observer.observe(modalContactsList, { childList: true });

// Add an event listener to mainContactsList to update modalContact when its value changes

var mainuserid;
var projectId;





window.onload = function () {
  // Get the leadid from the URL parameter

  if (leadid === null) {
    xalert("Error: No activity id parameter found in the URL", 1, null);
    return;
  }

  // Get the token from the readToken() function
  const token = readToken();

  // Create a new XHR object
  const xhr = new XMLHttpRequest();

  // Open the XHR request
  xhr.open("GET", url + `/biomedapi/projects/activities/${leadid}`, true);

  // Set the request headers
  xhr.setRequestHeader("Authorization", `Bearer ${token}`);

  // Set the onload function to handle the response
  xhr.onload = function () {
    if (xhr.status === 200) {
      
      // Parse the response JSON
      const response = JSON.parse(xhr.responseText);
      console.log(response);
      mainuserid = response.MainUserId;

        if (response.Name !== undefined && response.Name !== null) {
            document.getElementById("leadName").value = response.Name;
        }
        if (response.Creation !== undefined && response.Creation !== null) {
            document.getElementById("creation").value = timeFuck(response.Creation);
        }
        if (response.Update !== undefined && response.Update !== null) {
            document.getElementById("update").value = timeFuck(response.Update);
        }
        if (response.Objective !== undefined && response.Objective !== null) {
            document.getElementById("objective").value = response.Objective;
        }
        if (response.Description !== undefined && response.Description !== null) {
            document.getElementById("description").value = response.Description;
        }
        if (response.Budget !== undefined && response.Budget !== null) {
            document.getElementById("budget").value = response.Budget;
        }
        if (response.Outcome !== undefined && response.Outcome !== null) {
            document.getElementById("outcome").value = response.Outcome;
        }
        if (response.ActivityReturn !== undefined && response.ActivityReturn !== null) {
            document.getElementById("activityReturn").value = response.ActivityReturn;
        }
        if (response.InvolvedProducts !== undefined && response.InvolvedProducts !== null) {
            document.getElementById("involvedProducts").value = response.InvolvedProducts;
        }
        if (response.Insight !== undefined && response.Insight !== null) {
            document.getElementById("insight").value = response.Insight;
        }
        if (response.NextStep !== undefined && response.NextStep !== null) {
            document.getElementById("nextStep").value = response.NextStep;
        }
        if (response.Done !== undefined && response.Done !== null) {
            document.getElementById("done").value = response.Done;
        }
        if (response.KeyPoints !== undefined && response.KeyPoints !== null) {
            document.getElementById("keyPoints").value = response.KeyPoints;
        }
        if (response.Notes !== undefined && response.Notes !== null) {
            document.getElementById("notes").value = response.Notes;
        }
        if (response.Brochures !== undefined && response.Brochures !== null) {
            document.getElementById("brochures").value = response.Brochures;
        }
        if (response.Publications !== undefined && response.Publications !== null) {
            document.getElementById("publications").value = response.Publications;
        }
        if (response.Gimmicks !== undefined && response.Gimmicks !== null) {
            document.getElementById("gimmicks").value = response.Gimmicks;
        }
        if (response.Products !== undefined && response.Products !== null) {
            document.getElementById("products").value = response.Products;
        }
        if (response.Materials !== undefined && response.Materials !== null) {
            document.getElementById("materials").value = response.Materials;
        }
        if (response.MaterialBudget !== undefined && response.MaterialBudget !== null) {
            document.getElementById("materialBudget").value = response.MaterialBudget;
        }
        if (response.Responsibles !== undefined && response.Responsibles !== null) {
            document.getElementById("responsibles").value = response.Responsibles;
        }
        if (response.Responsibilities !== undefined && response.Responsibilities !== null) {
            document.getElementById("responsibilities").value = response.Responsibilities;
        }
        if (response.Expense !== undefined && response.Expense !== null) {
            document.getElementById("expense").value = response.Expense;
        }
      // Use the extracted data as needed
      // ...
      projectId = response.ProjectID;
      getProjectById(response.ProjectID,(err, pipelines) => {
        if (err) {
          console.error("Failed to fetch pipelines:", err);
          return;
        }
        console.log(pipelines);
        document.getElementById("activityLocation").innerHTML = pipelines.Name;

        sortedPipelines = pipelines.Pipelines.sort((a, b) => a.Order - b.Order);

        const pipelineSelection = document.getElementById("pipelineSelection");

        sortedPipelines.forEach((pipeline) => {
          const radioInput = document.createElement("input");
          radioInput.type = "radio";
          radioInput.className = "btn-check";
          radioInput.name = "btnradio";
          radioInput.id = `pipeline${pipeline.Id}`;
          radioInput.autocomplete = "off";

          const label = document.createElement("label");
          label.className = "btn btn-outline-secondary small";
          label.htmlFor = `pipeline${pipeline.Id}`;
          label.textContent = pipeline.Name;

          pipelineSelection.appendChild(radioInput);
          pipelineSelection.appendChild(label);
        });
      }, false);

      const pipelineId = response.ProjectPipelineId;
      const pipelineRadio = document.getElementById(`pipeline${pipelineId}`);
      if (pipelineRadio) {
        pipelineRadio.checked = true;
      }

      getUsers((error, users) => {
        if (error) {
          console.error("Failed to fetch users:", error);
          return;
        }

        //And main responsible user
        const primaryBadge = document.createElement("span");
        primaryBadge.classList.add(
          "badge",
          "bg-info",
          "text-dark",
          "py-1",
          "m-1",
          "align-middle",
          "text-wrap"
        );
        const Muser = users.find((Muser) => Muser.Id === response.MainUserId);
        if (Muser) {
          primaryBadge.innerHTML = `<strong><i class="fi fi-rr-chess-king align-middle mx-1"></i></strong>${Muser.FirstName} ${Muser.LastName} (${Muser.Position})`;
        }
        
        document.getElementById("responsible").appendChild(primaryBadge);
        });
     
    }
 }


  // Send the XHR request
  xhr.send();
};

function contactsModal() {
    var contactsModal = new bootstrap.Modal("#multiContactModal", {
        focus: true
    });
    contactsModal.show();
    
}

function usersModal() {
  var multiSelectModal = new bootstrap.Modal("#multiSelectModal", {
    focus: true
  });
  multiSelectModal.show();
}

function updateLead() {
  // Create a new XMLHttpRequest object
  


  var xhr = new XMLHttpRequest();
  if (document.querySelector('input[name="btnradio"]:checked') === null) {
    // The element is null, meaning no input with name "btnradio" is checked
    xalert("Error: No pipeline selected", 2, 5000);
    return;
  } 
  // Configure the POST request
  xhr.open("POST", url + "/biomedapi/projects/activities/update", true);

  // Set the request headers
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());

// Prepare the data from the HTML form
var data = {
    Id: leadid,
    Name: document.getElementById("leadName").value,
    MainUserId: parseInt(mainuserid),
    Update: timeFormater(Date.now()),
    ActivityReturn: document.getElementById("activityReturn").value,
    Objective: document.getElementById("objective").value,
    Description: document.getElementById("description").value,
    Budget: parseFloat(document.getElementById("budget").value) || 0,
    Outcome: parseFloat(document.getElementById("outcome").value) || 0,
    InvolvedProducts: document.getElementById("involvedProducts").value,
    Insight: document.getElementById("insight").value,
    NextStep: document.getElementById("nextStep").value,
    Done: document.getElementById("done").value,
    KeyPoints: document.getElementById("keyPoints").value,
    Notes: document.getElementById("notes").value,
    Brochures: document.getElementById("brochures").value,
    Publications: document.getElementById("publications").value,
    Gimmicks: document.getElementById("gimmicks").value,
    Products: document.getElementById("products").value,
    Materials: document.getElementById("materials").value,
    MaterialBudget: parseFloat(document.getElementById("materialBudget").value) || 0,
    Responsibles: document.getElementById("responsibles").value,
    Responsibilities: document.getElementById("responsibilities").value,
    Expense: parseFloat(document.getElementById("expense").value) || 0,
    PipelineId: document
        .querySelector('input[name="btnradio"]:checked')
        .id.replace("pipeline", ""),
};

  // Set the onload function to handle the response
  xhr.onload = function () {
    if (xhr.status === 200) {
      // Handle the success case
      xalert("Activity updated successfully", 0, null);
      console.log("Activity updated successfully");
      setTimeout(() => {
        window.location.href = "./project-overview.html?projectId=" + projectId;
      }, 1000);
    } else {
      // Handle the error case
      xalert("Error:" + xhr.status + " " + xhr.responseText, 1, null);
      console.error("Error:", xhr.status);
    }
  };

  // Send the request with the JSON stringified data
  xhr.send(JSON.stringify(data));
}

function modalContactsUpdate() {
    const mainselectedOptions = Array.from(mainContactSelect.selectedOptions);
    modalContactsList.innerHTML = "";
    mainselectedOptions.forEach((option) => {
      const badge = document.createElement("span");
      badge.classList.add(
        "badge",
        "bg-info",
        "text-dark",
        "py-1",
        "m-1",
        "align-middle",
        "text-wrap"
      );
      badge.innerHTML = option.getAttribute("data-subtext")
        ? `${option.textContent} (${option.getAttribute(
            "data-subtext"
          )})`
        : option.textContent;
      modalContactsList.appendChild(badge);
    });
    const selectedOptions = Array.from(contactSelect.selectedOptions);
    
    selectedOptions.forEach((option) => {
      const badge = document.createElement("span");
      badge.classList.add(
        "badge",
        "biomed-bg-accent",
        "text-dark",
        "py-1",
        "m-1",
        "align-middle",
        "text-wrap"
      );
      badge.innerHTML = option.getAttribute("data-subtext")
        ? `${option.textContent} (${option.getAttribute(
            "data-subtext"
          )})`
        : option.textContent;
        if(mainselectedOptions[0].value !== option.value){
            modalContactsList.appendChild(badge);
        }
      
    });
}

function deleteLead(){
  // Create a new XMLHttpRequest object
  var xhr = new XMLHttpRequest();

  // Configure the DELETE request
  xhr.open("POST", url + "/biomedapi/projects/activities/delete", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  // Set the request headers
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());

  // Set the onload function to handle the response
  xhr.onload = function () {
    if (xhr.status === 200) {
      // Handle the success case
      xalert("Lead deleted successfully", 0, null);
      console.log("Lead deleted successfully");
      setTimeout(() => {
        window.location.href = "./project-overview.html?projectId="+projectId;
      }, 1000);
    } else {
      // Handle the error case
      xalert("Error:" + xhr.status + " " + xhr.responseText, 1, null);
      console.error("Error:", xhr.status);
    }
  };

  
  // Send the DELETE request
  xhr.send(JSON.stringify({ Id: parseInt(leadid) }));
}