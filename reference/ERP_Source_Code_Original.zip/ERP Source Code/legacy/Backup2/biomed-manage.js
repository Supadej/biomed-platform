var userModal = new bootstrap.Modal(document.getElementById('userModal'));
var groupModal = new bootstrap.Modal(document.getElementById('groupModal'));

window.onload = function() {
        getUsers(function() {
        var usersList = document.getElementById('usersList');
        
        getUsers(function(err, users) {

            if (err) {
               xalert(err,1    , null);
            return;
            }
            console.log(users);
            users.forEach(function(user) {
            var card = document.createElement('div');
            card.className = 'card m-2';
            card.style = 'width: 15rem;';
            
            var image = document.createElement('img');
            if(user.ProfilePic == "00000000-0000-0000-0000-000000000000"){
                image.src = 'assets/profile-user.png';
            }else{
                image.src = 'assets/profile/'+user.ProfilePic+'.jpg';
            }
            image.className = 'card-img-top m-3 mx-auto rounded-circle';
            image.alt = '...';
            image.style.maxWidth = '6rem';
            image.style.maxHeight = '6rem';
            
            var cardBody = document.createElement('div');
            cardBody.className = 'card-body';
            
            var title = document.createElement('h5');
            title.className = 'card-title';
            title.textContent = user.FirstName + ' ' + user.LastName;
            
            var text = document.createElement('p');
            text.className = 'card-text';
            text.textContent = 'Username: ' + user.username + ', ID: ' + user.Id;
            
            var link = document.createElement('a');
            link.href = '/management-detail.html?id=' + user.Id;
            link.className = 'btn btn-primary';
            link.textContent = 'Edit';
            
            cardBody.appendChild(title);
            cardBody.appendChild(text);
            cardBody.appendChild(link);
            
            card.appendChild(image);
            card.appendChild(cardBody);
            
            usersList.appendChild(card);
            });
        });
    });

    getGroups(function(error, groups) {
        if (error) {
          console.error(error);
          return;
        }
      
        var groupList = document.getElementById('groupList');
        console.log(groups);
        groups.forEach(function(group) {
          var card = document.createElement('div');
          card.className = 'card m-2';
          card.style.width = '15rem';
      
          var cardBody = document.createElement('div');
          cardBody.className = 'card-body';
      
          var cardTitle = document.createElement('h5');
          cardTitle.className = 'card-title';
          cardTitle.textContent = group.GroupName;
      
          var cardLink = document.createElement('a');
          cardLink.href = '/management-group.html?id=' + group.Id;
          cardLink.className = 'btn btn-primary';
          cardLink.textContent = 'Edit';
      
          cardBody.appendChild(cardTitle);
          cardBody.appendChild(cardLink);
          card.appendChild(cardBody);
      
          groupList.appendChild(card);
        });
      }, true);



};
function refreshUser()
{
    getUsers(function(err, users) {
        if (err) {
            xalert(err,1,-1);
        }else{
            location.reload()
        }
    },true);
}

function refreshGroup()
{
    getGroups(function(err, users) {
        if (err) {
            xalert(err,1,-1);
        }else{
            location.reload()
        }
    },true);
}

function addUser(){
    userModal.show();
}
function addGroup(){
    groupModal.show();
}

function createGroupRequest() {
    let groupNameElement = document.querySelector('#groupModal #groupName');
    let groupName = groupNameElement ? groupNameElement.value : '';

    let createGroupRequest = {
        GroupName: groupName,
        UserIds: []
    };
    createGroup(createGroupRequest, function(err) {
        if (err) {
            xalert(err, 1, null);
            groupModal.hide();
            return;
        } else {
            xalert('Group created successfully', 0, null);
            groupModal.hide();
        }
        // Success callback code here
    });
}

function addUserRequest() {
    // Get input values
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const firstName = document.getElementById('firstName').value;
    const lastName = document.getElementById('lastName').value;
    const middleName = document.getElementById('middleName').value;
    const position = document.getElementById('position').value;
    const email = document.getElementById('email').value;
    const saleCode = document.getElementById('saleCode').value;
    const phoneNumber = document.getElementById('phoneNumber').value;
    const areaCode = document.getElementById('areaCode').value;
  
    // Validate username and password
    if (!username || !password) {
    
      xalert('Username and password must not be empty', 2, 5000);
      userModal.hide();
      return;
    }
  
    // Create user object
    const user = {
      Username: username,
      Password: password,
      ProfilePic: '00000000-0000-0000-0000-000000000000', // Default GUID
      FirstName: firstName,
      LastName: lastName,
      MiddleName: middleName,
      Position: position,
      Email: email,
      SaleCode: saleCode,
      PhoneNumber: phoneNumber,
      SubEmail: '', // Default empty string
      SubPhoneNumber: '', // Default empty string
      Address: '', // Default empty string
      LineID: '', // Default empty string
      AreaCode: areaCode,
      ReportToID: null, // Default null
      CoachID: null, // Default null
      Products: '', // Default empty string
      EmployedDate: new Date(), // Current date
      Permissions: [] // Default empty array
    };
  
    // TODO: Send user object to server
    createUser(user, function(err) {
        if (err) {
            xalert(err, 1, null);
            userModal.hide();
            return;
        }else{
            xalert('User created successfully', 0, null);
            userModal.hide();
        }
        // Success callback code here
    });


    console.log(user);
  }

function createUser(user, callback) {
    var xhr = new XMLHttpRequest();
    var urlx = '/biomedapi/users/create';
    var token = readToken();

    xhr.open('POST', url+urlx, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', 'Bearer ' + token);

    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                callback(null);
            } else {
                callback('Error creating user');
            }
        }
    };

    xhr.send(JSON.stringify(user));
}


function createGroup(group, callback) {
    var xhr = new XMLHttpRequest();
    var urlx = '/biomedapi/groups/create';
    var token = readToken();

    xhr.open('POST', url+urlx, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', 'Bearer ' + token);

    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                callback(null);
            } else {
                callback('Error creating group');
            }
        }
    };

    xhr.send(JSON.stringify(group));
}

