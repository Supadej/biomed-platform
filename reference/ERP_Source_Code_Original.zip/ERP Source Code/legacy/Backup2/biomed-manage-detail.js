const urlParams = new URLSearchParams(window.location.search);
const id = urlParams.get('id');
const modalPermissionsList = document.getElementById('modalPermissionsList');
const modalIndividualPermissionsList = document.getElementById('modalIndividualPermissionsList');
const select = document.getElementById('permissionsSelector');
const permissionUserSelectBox = document.getElementById('permissionUserSelectBox');
const individualSelectBox = document.getElementById('individualSelectBox');
function permissionsModal() {

    var multiSelectModal = new bootstrap.Modal("#multiSelectModal", {focus: true});
    multiSelectModal.show();
}
function individualPermissionsModal() {

    var individualPerms = new bootstrap.Modal("#individualPermissionsModal", {focus: true});
    individualPerms.show();
}


window.onload = function() {


    // Get the id from the URL

    if (!id) {
       xalert("No id please check your url",1,null);
        return;
    }
    // Make a GET request to fetch user details
    const xhr = new XMLHttpRequest();
    xhr.open('GET', url+`/biomedapi/users/${id}`);
    xhr.setRequestHeader('Authorization', `Bearer ${readToken()}`);
    xhr.onload = function() {
        if (xhr.status === 200) {
            const user = JSON.parse(xhr.responseText);

            // Update the form fields with user details
            document.getElementById('username').value = user.username;
            //document.getElementById('profile-pic').value = user.ProfilePic;
            document.getElementById('first-name').value = user.FirstName;
            document.getElementById('last-name').value = user.LastName;
            document.getElementById('middle-name').value = user.MiddleName;
            document.getElementById('position').value = user.Position;
            document.getElementById('email').value = user.Email;
            document.getElementById('sale-code').value = user.SaleCode;
            document.getElementById('phone-number').value = user.PhoneNumber;
            document.getElementById('sub-email').value = user.SubEmail;
            document.getElementById('sub-phone-number').value = user.SubPhoneNumber;
            document.getElementById('address').value = user.Address;
            document.getElementById('line-id').value = user.LineID;
            document.getElementById('area-code').value = user.AreaCode;
            document.getElementById('products').value = user.Products;
            const employedDate = user.EmployedDate
            const formattedEmployedDate = employedDate.split('T')[0];
            document.getElementById('employed-date').value = formattedEmployedDate;

            permissionsType.forEach(permission => {
                const option = document.createElement('option');
                option.value = permission.value;
                option.textContent = permission.name;
                option.setAttribute('data-subtext', permission.description);
                select.appendChild(option);
            });

            // Update the permissions select
            $(select).on('changed.bs.select', function (e, clickedIndex, isSelected, previousValue) {
            
                const selectedOptions = Array.from(e.target.selectedOptions);
                modalPermissionsList.innerHTML = '';
                selectedOptions.forEach(option => {
                    const badge = document.createElement('span');
                    badge.classList.add('badge', 'biomed-bg-accent', 'text-dark', 'py-1', 'm-1', 'align-middle', 'text-wrap');
                    badge.innerHTML = option.getAttribute('data-subtext') ? `${option.textContent} (${option.getAttribute('data-subtext')})` : option.textContent;
                    modalPermissionsList.appendChild(badge);
                    document.getElementById("permissionsUsersList").innerHTML = modalPermissionsList.innerHTML;
                });
            });

            

            $(select).selectpicker('refresh');
            document.getElementById("permissionsUsersList").innerHTML = modalPermissionsList.innerHTML;
            // Call the getUsers function to fetch the list of users
            getUsers(function(err, response) {
                if (err) {
                    console.error(err);
                   xalert("Error while fetching users", 1, null);
                    return;
                }
                
                // Get the select element for report-to
                const reportToSelect = document.getElementById('report-to');
                
                // Get the select element for coach
                const coachSelect = document.getElementById('coach');
                
                // Loop through the response and create options for report-to and coach
                response.forEach(user => {
                    // Create an option element for report-to
                    const reportToOption = document.createElement('option');
                    reportToOption.value = user.Id;
                    reportToOption.text = `${user.Id}:${user.FirstName} ${user.LastName}`;
                    reportToSelect.appendChild(reportToOption);
                    
                    // Create an option element for coach
                    const coachOption = document.createElement('option');
                    coachOption.value = user.Id;
                    coachOption.text = `${user.Id}:${user.FirstName} ${user.LastName}`;
                    coachSelect.appendChild(coachOption);

                    const individualPermissionOption = document.createElement('option');
                    individualPermissionOption.value = user.Id;
                    individualPermissionOption.text = `${user.Id}:${user.FirstName} ${user.LastName}`;
                    permissionUserSelectBox.appendChild(individualPermissionOption);
                });

                permissionsTypeIndividual.forEach(permission => {

                    const option = document.createElement('option');
                    option.value = permission.value;
                    option.textContent = permission.name;
                    option.setAttribute('data-subtext', permission.description);
                    individualSelectBox.appendChild(option);
                });

                if (user.ReportToID) {
                    reportToSelect.value = user.ReportToID;
                }

                if (user.CoachID) {
                    coachSelect.value = user.CoachID;
                }
            });
            console.log(user);

            
            var permsList = [];
            
           
            user.Permissions.forEach(permission => {
                if (permissionsType.some(p => p.name === permission.Type)) {
                    const p = permissionsType.find(p => p.name === permission.Type);
                    if(permission.Value === 'Allow'||permission.Value === 3){
                        permsList.push(p.value);
                    }
                    console.log(permission.Type);
                }
                else {
                    console.log(permission.Type+"-"+permission.PermissionKey);
                    const p = permissionsTypeIndividual.find(p => p.name === permission.Type);
                    if(permission.Value === 'Allow'||permission.Value === 3){
                        addIndividualPermission(permission.PermissionKey, p.value.toString());
                    }
                }

            });
            const selectValues = permsList.map(String);
            $(select).selectpicker('val', selectValues);
            $(select).selectpicker('refresh');

        }
    };
    xhr.send();
};


function addIndividualPermission(userId = null, permissionType = null) {

    
    if(userId && permissionType){
        var userSelectElement = document.getElementById('permissionUserSelectBox');
        var selectedUserOption = Array.from(userSelectElement.options).find(option => option.value === userId);
        var selectedUser = selectedUserOption ? selectedUserOption.value : null;
        var selectedUserText = selectedUserOption ? selectedUserOption.text : null;

        var permissionSelectElement = document.getElementById('individualSelectBox');
        var selectedPermissionOption = Array.from(permissionSelectElement.options).find(option => option.value === permissionType);
        var selectedPermission = selectedPermissionOption ? selectedPermissionOption.value : null;
        var selectedPermissionText = selectedPermissionOption ? selectedPermissionOption.text : null;
    }else{

        var userSelectElement = document.getElementById('permissionUserSelectBox');
        var selectedUserOption = userSelectElement.options[userSelectElement.selectedIndex];
        var selectedUser = selectedUserOption.value;
        var selectedUserText = selectedUserOption.text;
    
        var permissionSelectElement = document.getElementById('individualSelectBox');
        var selectedPermissionOption = permissionSelectElement.options[permissionSelectElement.selectedIndex];
        var selectedPermission = selectedPermissionOption.value;
        var selectedPermissionText = selectedPermissionOption.text;
    }

    const existingPermissions = Array.from(modalIndividualPermissionsList.children);
    const isExisting = existingPermissions.some(permission => {
        const userId = permission.getAttribute('userid');
        const permissionType = permission.getAttribute('permissiontype');
        return userId === selectedUser && permissionType === selectedPermission;
    });

    if (isExisting) {
        return;
    }

    const badge = document.createElement('span');
    badge.classList.add('badge', 'biomed-bg-accent', 'text-dark', 'py-1', 'm-1', 'align-middle', 'text-wrap');
    badge.textContent = selectedUserText+"⚡"+selectedPermissionText;

    const deleteButton = document.createElement('i');
    deleteButton.classList.add('fi', 'fi-rr-cross', 'delete-button','mx-1');
    deleteButton.setAttribute('userid', selectedUser);
    deleteButton.setAttribute('permissiontype', selectedPermission);
    deleteButton.addEventListener('click', deleteIndividualPermission);
    deleteButton.style.color = 'red';

    const permissionElement = document.createElement('div');
    permissionElement.classList.add('permission-element');
    permissionElement.setAttribute('userid', selectedUser);
    permissionElement.setAttribute('permissiontype', selectedPermission);
    permissionElement.appendChild(badge);
    badge.appendChild(deleteButton);

    modalIndividualPermissionsList.appendChild(permissionElement);
}

function deleteIndividualPermission(event) {
    const permissionElement = event.target.closest('.permission-element');
    if (permissionElement) {
        permissionElement.remove();
    }
}

// Sync modalIndividualPermissionsList with individualPermissionsUsersList
function syncPermissionsList() {
    const individualPermissionsUsersList = document.getElementById('individualPermissionsUsersList');
    individualPermissionsUsersList.innerHTML = modalIndividualPermissionsList.innerHTML;
}

// Call the syncPermissionsList function whenever there is a change in modalIndividualPermissionsList
const observer = new MutationObserver(syncPermissionsList);
observer.observe(modalIndividualPermissionsList, { childList: true });



function sendUserData() {
    // Create a new XMLHttpRequest object
    
    if (!id) {
       xalert("No id please check your url",1,null);
        return;
    }
    let xhr = new XMLHttpRequest();


    // Get form fields
    let username = document.getElementById('username').value;
    let password = document.getElementById('password').value;
    let ProfilePic = document.getElementById('profile-pic').value;
    if (!isValidGuid(ProfilePic)) {
        ProfilePic = '00000000-0000-0000-0000-000000000000'; // Set default GUID value
    }
    let FirstName = document.getElementById('first-name').value;
    let LastName = document.getElementById('last-name').value;
    let MiddleName = document.getElementById('middle-name').value;
    let Position = document.getElementById('position').value;
    let Email = document.getElementById('email').value;
    let SaleCode = document.getElementById('sale-code').value;
    let PhoneNumber = document.getElementById('phone-number').value;
    let SubEmail = document.getElementById('sub-email').value;
    let SubPhoneNumber = document.getElementById('sub-phone-number').value;
    let Address = document.getElementById('address').value;
    let LineID = document.getElementById('line-id').value;
    let AreaCode = document.getElementById('area-code').value;
    let reportToID = document.getElementById('report-to').value ? document.getElementById('report-to').value : null;
    let coachID = document.getElementById('coach').value ? document.getElementById('coach').value : null;
    let Products = document.getElementById('products').value;
    let EmployedDate = timeFormater(document.getElementById('employed-date').value);
    
    let data = {
        Id: id,
        Username: username,
        Password: password,
        ProfilePic: ProfilePic,
        FirstName: FirstName,
        LastName: LastName,
        MiddleName: MiddleName,
        Position: Position,
        Email: Email,
        SaleCode: SaleCode,
        PhoneNumber: PhoneNumber,
        SubEmail: SubEmail,
        SubPhoneNumber: SubPhoneNumber,
        Address: Address,
        LineID: LineID,
        AreaCode: AreaCode,
        ReportToID: reportToID,
        CoachID: coachID,
        Products: Products,
        EmployedDate: EmployedDate
        // ... repeat for all other fields
    };
    

    // Add the permissions to the data object
    // Create a list of permission objects
    const permissions = [];

    // Get the selected options from the 'select' element
    const selectedOptions = Array.from(select.selectedOptions).map(option => parseInt(option.value));

    // Add the selected options to the permissions list
    selectedOptions.forEach(option => {
        permissions.push({
            Type: option,
            Value: 3
        });
    });

    // Get the permission elements from the 'modalIndividualPermissionsList' element
    const permissionElements = Array.from(modalIndividualPermissionsList.getElementsByClassName('permission-element'));

    // Add the permission elements to the permissions list
    permissionElements.forEach(element => {
        const permissionType = parseInt(element.getAttribute('permissiontype'));
        const permissionKey = element.getAttribute('userid');
        
        permissions.push({
            Type: permissionType,
            Value: 3,
            PermissionKey: permissionKey
        });
    });

    // Add the permissions to the data object
    data.Permissions = permissions;
    console.log(data);

    // Convert data to JSON
    let jsonData = JSON.stringify(data);

    // Specify the type of request and the URL
    xhr.open('POST', url+ '/biomedapi/users/update'); // replace 'api_endpoint' with the actual API endpoint

    // Set request headers
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', 'Bearer ' + readToken());

    // Send the request
    xhr.send(jsonData);

    // Function to run when the state changes
    xhr.onreadystatechange = function () {

        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log(username + ' updated successfully');
           xalert("User updated successfully", 0, -1);
        }
        else if (xhr.readyState === 4 && xhr.status !== 200){
            console.error('Error while updating user '+xhr.status+'-'+ xhr.responseText);
           xalert("Error while updating user "+xhr.status+"-"+ xhr.responseText, 1, null);
        }
    };
}