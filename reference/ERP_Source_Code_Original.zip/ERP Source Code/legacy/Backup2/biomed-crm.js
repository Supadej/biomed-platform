var pipelineCache = [];
var pipelineIdCache = null;

function editpipeline(pipelineId) {
    createModalPopup(pipelineId);
}

function deletepipeline(pipelineId) {

    createModalPopup(pipelineId,true);

}

function getUniqueLeads(leads) {
    const uniqueLeads = leads.reduce((acc, lead) => {
        if (!acc.some(existingLead => existingLead.Id === lead.Id)) {
            acc.push(lead);
        }
        return acc;
    }, []);
    return uniqueLeads;
}



function createModalPopup(pipelineId = null, deletePipeline = false) {
    // Create the modal element
    pipelineIdCache = pipelineId;
    const modal = document.createElement('div');
    modal.id = 'pipelineModal';
    
    modal.classList.add('modal', 'fade');
    modal.setAttribute('tabindex', '-1');
    modal.setAttribute('role', 'dialog');

    // Create the modal dialog element
    const modalDialog = document.createElement('div');
    modalDialog.classList.add('modal-dialog');
    modal.appendChild(modalDialog);

    // Create the modal content element
    const modalContent = document.createElement('div');
    modalContent.classList.add('modal-content');
    modalDialog.appendChild(modalContent);

    // Create the modal header element
    const modalHeader = document.createElement('div');
    modalHeader.classList.add('modal-header');
    modalContent.appendChild(modalHeader);

    // Create the modal title element
    const modalTitle = document.createElement('h5');
    modalTitle.classList.add('modal-title');
    modalTitle.textContent = 'Add Pipeline';
    if (pipelineId) {
        modalTitle.textContent = 'Edit Pipeline';
    }
    if (deletePipeline) {
        modalTitle.textContent = 'Are you sure you want to delete this pipeline?';
    }
    modalHeader.appendChild(modalTitle);

    // Create the close button element
    const closeButton = document.createElement('button');
    closeButton.setAttribute('type', 'button');
    closeButton.classList.add('btn-close');
    closeButton.setAttribute('data-bs-dismiss', 'modal');
    closeButton.setAttribute('aria-label', 'Close');
    closeButton.addEventListener('click', removeModalPopup );
    modalHeader.appendChild(closeButton);

    // Create the modal body element
    const modalBody = document.createElement('div');
    modalBody.classList.add('modal-body');
    modalContent.appendChild(modalBody);

    // Create the text input element
    const inputGroup = document.createElement('div');
    inputGroup.classList.add('input-group', 'input-group-sm', 'mb-3');
    modalBody.appendChild(inputGroup);

    const inputGroupText = document.createElement('span');
    inputGroupText.classList.add('input-group-text');
    inputGroupText.style.width = '60px';
    inputGroupText.textContent = 'Title';
    inputGroup.appendChild(inputGroupText);

    const input = document.createElement('input');
    input.setAttribute('type', 'text');
    input.classList.add('form-control');
    input.setAttribute('aria-label', 'Sizing example input');
    input.setAttribute('aria-describedby', 'inputGroup-sizing-sm');
    input.id = 'pipelineTitle';
    if (pipelineId) {
        const pipeline = pipelineCache.find(pipeline => pipeline.Id === pipelineId);
        input.value = pipeline.PipelineName;
        //input2.value = pipeline.Order;
    }
    if (deletePipeline) {
        input.readOnly = true;
    }
    inputGroup.appendChild(input);

    // Create the input group element
    const inputGroup2 = document.createElement('div');
    inputGroup2.classList.add('input-group', 'input-group-sm', 'mb-3');
    modalBody.appendChild(inputGroup2);

    // Create the input group text element
    const inputGroupText2 = document.createElement('span');
    inputGroupText2.classList.add('input-group-text');
    inputGroupText2.style.width = '60px';
    inputGroupText2.textContent = 'Order';
    inputGroup2.appendChild(inputGroupText2);

    // Create the input element
    const input2 = document.createElement('input');
    input2.setAttribute('type', 'number');
    input2.classList.add('form-control');
    input2.setAttribute('aria-label', 'Sizing example input');
    input2.setAttribute('aria-describedby', 'inputGroup-sizing-sm');
    input2.value = 0;
    if (pipelineId) {
        const pipeline = pipelineCache.find(pipeline => pipeline.Id === pipelineId);
        //input.value = pipeline.PipelineName;
        input2.value = pipeline.Order;
    }
    if (deletePipeline) {
        input2.readOnly = true;
    }
    input2.id = 'pipelineOrder';
    inputGroup2.appendChild(input2);

    // Create the button element
    const addButton = document.createElement('button');
    addButton.textContent = 'Add';
    if (pipelineId) {
        addButton.textContent = 'Update';
    }
    if (deletePipeline) {
        addButton.textContent = 'Delete';
        addButton.setAttribute('data-bs-dismiss', 'modal');
        addButton.setAttribute('aria-label', 'Close');
        addButton.classList.add('btn', 'btn-danger');
        addButton.addEventListener('click', function() {
            deletePipelineRequest(pipelineId);
            removeModalPopup();
        });
    }else{
        addButton.classList.add('btn', 'btn-primary');
        addButton.setAttribute('data-bs-dismiss', 'modal');
        addButton.setAttribute('aria-label', 'Close');
        addButton.addEventListener('click', createCRMPipeline);
    }
    modalBody.appendChild(addButton);

    // Append the modal to the document body

    document.body.appendChild(modal);
    var crmModal = new bootstrap.Modal("#pipelineModal", {focus: true});

    /*var wtfisthis = bootstrap.Modal.getInstance(document.getElementById('pipelineModal'));
    wtfisthis.addEventListener('hidden.bs.modal', function (event) {

        wtfisthis.dispose();
    });*/

    

    crmModal.show();
}

function createCRMPipeline(){
    createPipelineRequest(pipelineIdCache);
    removeModalPopup();
}

function deletePipelineRequest(pipelineId) {
    const token = readToken();
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url + '/biomedapi/crm/pipelines/delete', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Request successful
                xalert('Pipeline deleted successfully', 0, -1);
                setTimeout(function() {
                    location.reload();
                }, 2000);
            } else {
                // Request failed
                xalert('Error ' + xhr.status + " " + xhr.responseText, 1, -1);
            }
        }
    };
    const data = JSON.stringify({Id: pipelineId});
    xhr.send(data);

}

function createPipelineRequest(pipelineId = null) {
    const token = readToken();
    const name = document.getElementById('pipelineTitle').value;
    const order = parseInt(document.getElementById('pipelineOrder').value);


    const xhr = new XMLHttpRequest();
    if (pipelineId) {
        xhr.open('POST', url+ '/biomedapi/crm/pipelines/update', true);
    } else {
        xhr.open('POST', url+ '/biomedapi/crm/pipelines/create', true);
    }
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Request successful
                xalert('Pipeline created/updated successfully',0,-1);
                setTimeout(function() {
                    location.reload();
                }, 2000);
                
            } else {
                // Request failed
                xalert('Error '+xhr.status+" "+xhr.responseText,1,-1);
                
            }
        }
    };
    let rawdata = {
        PipelineName: name,
        Order: order
    };
    if (pipelineId) {
        rawdata.Id = pipelineId;
    }   
    
    const data = JSON.stringify(rawdata);
    xhr.send(data);
}


function removeModalPopup() {
    document.getElementById('pipelineModal').remove();
    pipelineIdCache = null;
}




window.onload = function() {
    getPipelines(function(error, pipelines) {
        if (error) {
            xalert('Error ' + error, 1, -1);
            // Handle the error here
        } else {
            const pipelineContainer = document.getElementById('pipelineContainer');


            pipelineCache = pipelines;
            //Create Null Pipeline
            const nullpipelineElement = document.createElement('div');
                nullpipelineElement.classList.add('col', 'm-0', 'p-0', 'px-1', 'py-2', 'd-none');
                nullpipelineElement.style.minWidth = '256px';
                nullpipelineElement.id = 'nullPipelineParent';
                nullpipelineElement.innerHTML = `
                <div class="m-0 p-0 row" id="nullPipeline">
                
                    <h6 class="col-11 p-0 m-0 mb-1 py-auto fw-bold auto-fit py-1">Unassigned</h6>
                    
                </div>

                    
                `;
                pipelineContainer.appendChild(nullpipelineElement);


            pipelines.forEach(pipeline => {
                const pipelineElement = document.createElement('div');
                pipelineElement.classList.add('col', 'm-0', 'p-0', 'px-1', 'py-2');
                pipelineElement.style.minWidth = '280px';
                pipelineElement.innerHTML = `
                <div class="m-0 p-0 row" id="${pipeline.Id}">
                
                    <h6 class="p-0 m-0 py-auto fw-bold auto-fit py-1">${pipeline.PipelineName}</h6>
                    
                    <div class="btn-group m-0 p-0 d-grid justify-content-sm-end ms-auto col-3 dropstart mb-1">
                            <button class="btn btn-secondary btn-sm rounded m-0 p-0 ms-auto auto-fit" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fi fi-rr-menu-dots-vertical"></i>
                            </button>
                            <ul class="dropdown-menu">
                                <li><h6 class="dropdown-header">Quick Action</h6></li>
                                <li><a class="dropdown-item" onclick="editpipeline(${pipeline.Id})">Edit Pipeline</a></li>
                                <li><a class="dropdown-item text-danger" onclick="deletepipeline(${pipeline.Id})">Delete Pipeline</a></li>
                            </ul>
                    </div>
                    <div class="m-0 p-1 d-flex flex-nowrap justify-content-evenly"> 
                        <span class="badge rounded-pill bg-danger mt-1"><i class="fi fi-rr-ban"></i> Dropped:<p class="m-0 p-0 d-inline" id="abandon${pipeline.Id}">0</p></span>
                        <span class="badge rounded-pill bg-warning mt-1"><i class="fi fi-rr-triangle-warning"></i> Inactive:<p class="m-0 p-0 d-inline" id="warn${pipeline.Id}">0</p></span>
                        <span class="badge rounded-pill bg-success mt-1"><i class="fi fi-rr-signal-bars-good"></i> Active:<p class="m-0 p-0 d-inline" id="ok${pipeline.Id}">0</p></span>
                    </div>
                </div>

                    
                `;
                pipelineContainer.appendChild(pipelineElement);
            });
        }
        getLeads(function(error, leads) {
            if (error) {
                xalert('Error ' + error , 1, -1);
                // Handle the error here
            } else {

                
                getUniqueLeads(leads).forEach(lead => {
                    
                    let leadsContainer = document.getElementById(lead.CRMPipelineId);
                    const leadElement = document.createElement('div');
                    leadElement.classList.add('p-0');
                    console.log(lead);
                    var MainContact = null;
                    if (lead.MainCustomerId != null && lead.MainCustomerId != undefined) {
                        getContactById(lead.MainCustomerId,function(error, contact) {
                            if (error) {
                                xalert('Error ' + error, 1, -1);
                                // Handle the error here
                            } else {
                                MainContact = contact;
                                if (MainContact.Name == null || MainContact.Name == undefined) {
                                    MainContact = {Name: "", Position: "-"};
                                }
                                if (MainContact.Position == null || MainContact.Position == undefined) {
                                    MainContact = { Name:MainContact.Name, Position: "-"};
                                }
                                getUserById(async function(error, user){
                                    if (error) {
                                        xalert('Error ' + error , 1, -1);
                                        // Handle the error here
                                    }
                                    if (user == null || user == undefined) {
                                        xalert('Error ' + error , 1, -1);
                                        // Handle the error here
                                    }
                                    var mainuser = user;
                                    var color = await getColor(user.Id);
                                    console.log(color);
                                    var leadLink = 'crm-detail.html?leadid='+lead.Id;
                                console.log(mainuser);
                                const thirtyDaysAgo = new Date();
                                thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

                                const threeMonths = new Date();
                                thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 90);
                                var badge = "";
                                if(!(lead.CRMPipelineId == null || lead.CRMPipelineId == undefined)){
                                    
                                    if (lead.LastUpdated < thirtyDaysAgo) {
                                        document.getElementById('warn'+lead.CRMPipelineId).textContent = parseInt(document.getElementById('warn'+lead.CRMPipelineId).textContent) + 1;
                                        badge =  `<span class="badge rounded-pill bg-warning d-inline p-1 px-2 me-1"><i class="fi fi-rr-triangle-warning"></i></span>`;
                                    }else
                                    if (lead.LastUpdated < threeMonths) {
                                        document.getElementById('abandon'+lead.CRMPipelineId).textContent = parseInt(document.getElementById('abandon '+lead.CRMPipelineId).textContent) + 1;
                                        
                                        badge =  `<span class="badge rounded-pill bg-danger d-inline p-1 px-2 me-1"><i class="fi fi-rr-ban"></i></span>`;
                                    }
                                    else{
                                        document.getElementById('ok'+lead.CRMPipelineId).textContent = parseInt(document.getElementById('ok'+lead.CRMPipelineId).textContent) + 1;
                                        badge =  `<span class="badge rounded-pill bg-success d-inline p-1 px-2 me-1"><i class="fi fi-rr-signal-bars-good"></i></span>`;
                                    }
                                }
                                document.getElementById('tAchieved').textContent = parseInt(document.getElementById('tAchieved').textContent) + parseInt(lead.AchivedRevenue);

                                document.getElementById('tExpected').textContent = parseInt(document.getElementById('tExpected').textContent) + parseInt(lead.ExpectedRevenue);
                                document.getElementById('AERatio').style.width = (parseInt(document.getElementById('tAchieved').textContent) / parseInt(document.getElementById('tExpected').textContent) * 100) + "%";

                                leadElement.innerHTML = `
                                    <div class="m-0 p-2 my-0 border bg-white"><!-- Single Lead-->
                                        <div class="m-0 p-0 row"> 
                                            <p class="m-0 p-0 py-0 fw-bold auto-fit col-9">${badge}${ lead.LeadName}</p>
                                            
                                            <div class="btn-group m-0 p-0 d-grid justify-content-sm-end ms-auto col-3 dropstart">
                                                <button class="btn btn-secondary btn-sm rounded m-0 p-0 ms-auto auto-fit" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="fi fi-rr-menu-dots-vertical"></i>
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><h6 class="dropdown-header">Quick Action</h6></li>
                                                    <li><a class="dropdown-item d-none" href="#" onclick="openModal()">Create event from this lead</a></li>
                                                    <li><a class="dropdown-item" href="${leadLink}">Edit this lead</a></li>
                                                    <li><hr class="dropdown-divider d-none"></li>
                                                    <li><h6 class="dropdown-header d-none ">Change Status to...</h6></li>
                                                    <li><a class="dropdown-item d-none" href="#">Sales Plan</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Initiate</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Following Up</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Qualified</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Confirmed Order</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">Proposition</a></li>
                                                    <li><a class="dropdown-item d-none" href="#">PO Issued</a></li>
                                                    <li><hr class="dropdown-divider d-none"></li>
                                                    <li><a class="dropdown-item text-danger d-none" href="#" >Delete this lead</a></li>
                                                </ul>
                                            </div>
            
                                        </div>
                                        <p class="m-0 py-1 fw-normal">Expect: ${lead.ExpectedRevenue} THB</p>
                                        <p class="m-0 py-1 fw-normal">Achived: ${lead.AchivedRevenue} THB</p>
                                        <p class="m-0 py-1 fw-normal">${"Main Customer:" +" "+MainContact.Name+"("+MainContact.Position+")"}</p>
                                        <p class="m-0 py-1 fw-normal">Due Date: ${timeFriendly(lead.Expected)}</p>
                                        <p class="m-0 py-1 fw-normal"><span class="badge py-1 m-1 align-middle text-wrap" style="background-color: ${color.color.code}; color: ${color.textColor};">${mainuser.FirstName+" "+mainuser.LastName+"("+mainuser.Position+")"}</span></p>
                                        <p class="m-0 py-0 d-none"><i class="fi fi-rr-circle-star text-warning"></i><i class="fi fi-rr-circle-star text-warning"></i><i class="fi fi-rr-circle-star text-secondary"></i></p>
                                    </div>
                                `;
                                
                                

                                if(leadsContainer == null || leadsContainer == undefined){
                                    leadsContainer = document.getElementById('nullPipeline');
                                    document.getElementById('nullPipelineParent').classList.remove('d-none');
                                }
                                leadsContainer.appendChild(leadElement);
            
            
                                   
                                },lead.MainUserId);

                            }
                        });
                    }else{
                        MainContact = {Name: " ", Position: "-"};
                        xalert('Error Missing MainContact for Lead:'+lead.Id, 1, -1);
                    }
                    

                    
                    
                    
                    
    
                });
            }
            
        });
    
    
    
    },true);



    


};



function createLeadPopup() {
    // Create the modal element
    const modal = document.createElement('div');
    modal.id = 'leadModal';
    
    modal.classList.add('modal', 'fade');
    modal.setAttribute('tabindex', '-1');
    modal.setAttribute('role', 'dialog');

    // Create the modal dialog element
    const modalDialog = document.createElement('div');
    modalDialog.classList.add('modal-dialog');
    modal.appendChild(modalDialog);

    // Create the modal content element
    const modalContent = document.createElement('div');
    modalContent.classList.add('modal-content');
    modalDialog.appendChild(modalContent);

    // Create the modal header element
    const modalHeader = document.createElement('div');
    modalHeader.classList.add('modal-header');
    modalContent.appendChild(modalHeader);

    // Create the modal title element
    const modalTitle = document.createElement('h5');
    modalTitle.classList.add('modal-title');
    modalTitle.textContent = 'Create Lead';
    modalHeader.appendChild(modalTitle);

    // Create the close button element
    const closeButton = document.createElement('button');
    closeButton.setAttribute('type', 'button');
    closeButton.classList.add('btn-close');
    closeButton.setAttribute('data-bs-dismiss', 'modal');
    closeButton.setAttribute('aria-label', 'Close');
    closeButton.addEventListener('click', removeLeadPopup );
    modalHeader.appendChild(closeButton);

    // Create the modal body element
    const modalBody = document.createElement('div');
    modalBody.classList.add('modal-body');
    modalContent.appendChild(modalBody);

    // Create the text input element for LeadName
    const leadNameInputGroup = document.createElement('div');
    leadNameInputGroup.classList.add('input-group', 'input-group-sm', 'mb-3');
    modalBody.appendChild(leadNameInputGroup);

    const leadNameInputGroupText = document.createElement('span');
    leadNameInputGroupText.classList.add('input-group-text');
    leadNameInputGroupText.style.width = '100px';
    leadNameInputGroupText.textContent = 'Lead Name';
    leadNameInputGroup.appendChild(leadNameInputGroupText);

    const leadNameInput = document.createElement('input');
    leadNameInput.setAttribute('type', 'text');
    leadNameInput.classList.add('form-control');
    leadNameInput.setAttribute('aria-label', 'Sizing example input');
    leadNameInput.setAttribute('aria-describedby', 'inputGroup-sizing-sm');
    leadNameInput.id = 'leadName';
    leadNameInputGroup.appendChild(leadNameInput);

    // Create the dropdown selection element
    const pipelineDropdown = document.createElement('select');
    pipelineDropdown.classList.add('form-select', 'mb-3');
    pipelineDropdown.setAttribute('aria-label', 'Select Pipeline');
    pipelineDropdown.id = 'pipelineDropdown';
    modalBody.appendChild(pipelineDropdown);

    // Add options to the dropdown from pipelineCache
    pipelineCache.forEach(pipeline => {
        const option = document.createElement('option');
        option.value = pipeline.Id;
        option.textContent = pipeline.PipelineName;
        pipelineDropdown.appendChild(option);
    });

    // Create the button element
    const createLeadButton = document.createElement('button');
    createLeadButton.textContent = 'Create Lead';
    createLeadButton.classList.add('btn', 'btn-primary');
    createLeadButton.setAttribute('data-bs-dismiss', 'modal');
    createLeadButton.setAttribute('aria-label', 'Close');
    createLeadButton.addEventListener('click', createLead);
    modalBody.appendChild(createLeadButton);

    // Append the modal to the document body
    document.body.appendChild(modal);
    var leadModal = new bootstrap.Modal("#leadModal", {focus: true});
    leadModal.show();
}

function createLead(){
    createLeadRequest();
    removeLeadPopup();
}

function createLeadRequest() {
    const token = readToken();
    const leadName = document.getElementById('leadName').value;
    const pipelineId = document.getElementById('pipelineDropdown').value;

    const xhr = new XMLHttpRequest();
    xhr.open('POST', url + '/biomedapi/leads/create', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Request successful
                xalert('Lead created successfully', 0, -1);
                setTimeout(() => {
                    const leadId = xhr.responseText;
                    window.location.href = `crm-detail.html?leadid=${leadId}`;
                }, 2000);
            } else {
                // Request failed
                xalert('Error ' + xhr.status + " " + xhr.responseText, 1, -1);
            }
        }
    };
    let rawdata = {
        LeadName: leadName,
        PipelineId: pipelineId
    };
    
    const data = JSON.stringify(rawdata);
    xhr.send(data);
}

function removeLeadPopup() {
    document.getElementById('leadModal').remove();
}

