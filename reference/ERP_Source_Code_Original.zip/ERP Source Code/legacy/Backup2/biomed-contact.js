var contactTable = $("#contactTable");
var contactModal = new bootstrap.Modal(document.getElementById("contactModal"));
var contactModalCache = document.getElementById("contactModal");
var currentContact = null;
var contactName = document.getElementById("contactName");
var contactEmail = document.getElementById("contactEmail");
var contactAddress = document.getElementById("contactAddress");
var contactPhone = document.getElementById("contactPhone");
var contactPosition = document.getElementById("contactPosition");
var contactDepartment = document.getElementById("contactDepartment");
var masterContacts = [];


contactModalCache.addEventListener('hidden.bs.modal', function () {

    clearModal();
    console.log('Modal closed');
});
function clearModal()
{
    contactName.value = '';
    contactEmail.value = '';
    contactAddress.value = '';
    contactPhone.value = "";
    contactPosition.value = "";
    contactDepartment.value = '';
    currentContact = null;
    console.log('Modal cleared');
}

window.onload = function() {
    contactTable.bootstrapTable('hideColumn', 'id');
    getContacts((err,contacts)=>{
        if(err){
            console.error(err);
            xalert("Error loading contacts",1,-1);
            return;
        }
        console.log(contacts);
        masterContacts = contacts;

        var transformedContacts = contacts.map(function(contact) {
            return {
                id: contact.Id || null,
                Name: contact.Name || null,
                Email: contact.Email || null,
                Address: contact.Address || null,
                Phone: contact.Phone || null,
                Position: contact.Position || null,
                Department: contact.DepartmentID || null
            };
        });
        contactTable.bootstrapTable('load', transformedContacts);
        console.log(transformedContacts);

    },true);

}
function operateFormatter(value, row, index) {
    return [
      '<a class="edit text-primary link link-underline link-underline-opacity-0" href="javascript:void(0)" title="Edit">',
      '<i class="fi fi-rr-edit"></i>',
      '</a>  '
    ].join('')
  }

  window.operateEvents = {
    'click .edit': function (e, value, row, index) {
      console.log('You click edit icon, row: ', row);
    
        var foundContact = masterContacts.find(function(contact) {
            return contact.Id === row.id;
        });

        if (foundContact) {
            contactName.value = foundContact.Name || '';
            contactEmail.value = foundContact.Email || '';
            contactAddress.value = foundContact.Address || '';
            contactPhone.value = foundContact.Phone || '';
            contactPosition.value = foundContact.Position || '';
            contactDepartment.value = foundContact.Department || '';
            currentContact = foundContact;
            currentContact.index = index;
            contactModal.show();
        } else {
            console.log('Contact not found');
        }
        
    }

}

function tableButtons () {
    return {
      btnUsersAdd: {
        text: 'Add new contact',
        icon: 'fi-rr-add',
        event: function () {
          contactModal.show();
        },
        attributes: {
          title: 'Add new contact'
        }
      }
    }
}

function addContact() {
    var contact = {
        Name: contactName.value || null,
        Email: contactEmail.value || null,
        Address: contactAddress.value || null,
        Phone: contactPhone.value || null,
        Position: contactPosition.value || null,
        Department: null
    };

    if (currentContact !== null) {
        contact.Id = currentContact.Id;
        contact.id= currentContact.Id;
        contact.index = currentContact.index;
    }

    addContactRequest(contact);
    contactModal.hide();
}


function addContactRequest(contact) {
    var xhr = new XMLHttpRequest();
    var urlx = contact.Id ? '/biomedapi/contacts/update' : '/biomedapi/contacts/create';
    var method = 'POST';

    xhr.open(method, url+urlx, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', 'Bearer ' + readToken());

    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                console.log('Contact added/updated successfully');
                xalert('Contact added/updated successfully', 0, 5000);
                if (contact.Id) {
                    contactTable.bootstrapTable('updateRow', {index:contact.index,row:contact});
                } else {
                    contact.id = parseInt(xhr.responseText);
                    contact.Id = parseInt(xhr.responseText);
                    contactTable.bootstrapTable('append', contact);
                    masterContacts.push(contact);
                }
            } else {
                console.error('Error adding/updating contact:', xhr.responseText);
                xalert('Error adding/updating contact', 1, -1);
            }
        }
    };

    xhr.send(JSON.stringify(contact));
}