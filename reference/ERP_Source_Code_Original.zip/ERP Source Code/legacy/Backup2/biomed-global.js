var url = "";//"https://localhost:5001"; // empty string for production

const permissionsType = [
  { value: 0, name: 'noType', description: 'Placeholder it do nothing' },
  { value: 1, name: 'user_manage', description: 'Manage users (Can view/edit any users)' },
  { value: 2, name: 'user_permission_manage', description: 'Manage user permissions(Can view/edit any permission of users)' },
  { value: 3, name: 'lead_creation', description: 'Create leads' },
  { value: 4, name: 'lead_manage', description: 'Manage leads (Can view/edit any leads)' },
  { value: 5, name: 'contact_manage', description: 'Manage contacts (Can view/edit any contacts)' },
  { value: 6, name: 'event_manage', description: 'Manage events (Can view/edit any events)' },
  { value: 7, name: 'project_manage', description: 'Manage projects (Can view/edit any projects)' },
  { value: 8, name: 'log_manage', description: 'Manage logs (Can view/edit any logs)' },
  { value: 9, name: 'helpdesk_manage', description: 'Manage helpdesk (Can view/edit any helpdesk ticket)' },
  { value: 10, name: 'crm_access', description: 'No use right now' },
  { value: 11, name: 'project_access', description: 'Create projects' },
  { value: 12, name: 'event_access', description: 'Create events' },
  { value: 13, name: 'contact_access', description: 'Create contacts' }

];

const permissionsTypeIndividual = [
  { value: 14, name: 'lead_manage_individual', description: 'Manage individual leads (View/edit leads of specific users)' },
  { value: 15, name: 'helpdesk_manage_individual', description: 'Manage individual helpdesk tickets (View/edit helpdesk tickets of specific users)' },
  { value: 16, name: 'event_manage_individual', description: 'Manage individual events (View/edit events of specific users)' },
  { value: 17, name: 'project_manage_individual', description: 'Manage individual projects (View/edit projects of specific users)' }
];


function isDefined(input) {
  if (input !== undefined && input !== null) return true;
  return false;
}

function sendLoginRequest(username, password, callback) {
  var xhr = new XMLHttpRequest();
  xhr.open("POST", url + "/biomedapi/login", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        /*var response = JSON.parse(xhr.responseText);
                var token = response.token;*/
        // Save token to cookie
        document.cookie = "jwtToken=" + xhr.responseText;
        myUserRequest(function (error, response) {
          if (error) {
            console.error(error);
            // Handle error
          } else {
            xalert(
              "Welcome " + response.FirstName + " " + response.LastName,
              0,
              -1
            );
            console.log(response);
            // Handle response
          }
        }, true);

        callback(null, xhr.responseText);
      } else if (xhr.status === 400) {
        callback(new Error("Incorrect Username/Password"), null);
      } else {
        callback(new Error(xhr.responseText), xhr.status);
      }
    }
  };
  var data = JSON.stringify({ username: username, password: password });
  xhr.send(data);
}

function myUserRequest(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("myUser");
  }
  var myUser = sessionStorage.getItem("myUser");
  if (myUser !== null) {
    if (callback === null) {
      return;
    }
    callback(null, JSON.parse(myUser));
    return;
  }

  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/myuser", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  var token = readToken();
  if (token === null) {
    callback("Token not found", null);
    return;
  }
  xhr.setRequestHeader("Authorization", "Bearer " + token);
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        var response = JSON.parse(xhr.responseText);
        // Save user object in session storage
        sessionStorage.setItem("myUser", JSON.stringify(response));
        if (callback === null) {
          return;
        }
        callback(null, response);
      } else {
        if (callback === null) {
          return;
        }
        callback(new Error(xhr.responseText), xhr.status);
      }
    }
  };
  xhr.send();
}

function readToken() {
  var token = null;
  var cookies = document.cookie.split(";");
  for (var i = 0; i < cookies.length; i++) {
    var cookie = cookies[i].trim();
    if (cookie.startsWith("jwtToken=")) {
      token = cookie.substring("jwtToken=".length, cookie.length);
      break;
    }
  }
  if (token === null) {
    window.location.href = "login.html";
  }
  return token;
}

function removeToken() {
    console.log("Removing token");
    document.cookie = "jwtToken=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=*;";
    sessionStorage.removeItem("myUser");
    sessionStorage.removeItem("users");
    sessionStorage.removeItem("pipelines");
    sessionStorage.removeItem("groups");
    console.log(readToken());
}

function getEvents(callback) {
    var token = readToken();
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url+'/biomedapi/events', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', 'Bearer ' + token);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                var events = JSON.parse(xhr.responseText);
                console.log(events);
                callback(null, events);
            } else {


                callback('Request failed with status ' + xhr.status, null);
            }
        }
    };
    xhr.send();
}

function xalert(text, style, time) {
  document.body.scrollTop = 0; // For Safari
  document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
  var alertBar = document.getElementById("alert-bar");
  var styleClass = "";
  var styleText = "";

  switch (style) {
    case 0:
      styleClass = "success";
      styleText = "<strong>Successful</strong>";
      break;
    case 1:
      styleClass = "danger";
      styleText = "<strong>Error</strong>";
      break;
    case 2:
      styleClass = "warning";
      styleText = "<strong>Warning</strong>";
      break;
    case 3:
      styleClass = "info";
      styleText = "<strong>Info</strong>";
      break;
    default:
      styleClass = "info";
      styleText = "<strong>Info</strong>";
      break;
  }

  var alertElement = document.createElement("div");
  alertElement.classList.add(
    "alert",
    "alert-" + styleClass,
    "my-3",
    "mx-2",
    "text-wrap",
    "text-break"
  );
  alertElement.setAttribute("role", "alert");
  alertElement.innerHTML = styleText + "-" + text;

  alertBar.appendChild(alertElement);

  if (time !== -1 && time !== null) {
    setTimeout(function () {
      alertElement.remove();
    }, time);
  }
}
getUserById = function (callback,id ) {
  
  getUsers((error, users) => {

    if (error) {
      console.error('Failed to fetch users:', error);
      return;
    }
      const user = users.find(user => user.Id === id);
      callback(null, user);
  },false);



}

function getUsers(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("users");
  }
  var users = sessionStorage.getItem("users");
  if (users !== null) {
    callback(null, JSON.parse(users));
    return;
  }
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/users", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());
  xhr.onload = function () {
    if (xhr.status === 200) {
      var users = JSON.parse(xhr.responseText);
      sessionStorage.setItem("users", JSON.stringify(users));
      callback(null, users);
    } else {
      callback(new Error(xhr.responseText), null);
    }
  };
  xhr.onerror = function () {
    callback(new Error("Request failed"), null);
  };
  xhr.send();
}

function getPipelines(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("pipelines");
  }
  var pipelines = sessionStorage.getItem("pipelines");
  if (pipelines !== null) {
    callback(null, JSON.parse(pipelines));
    return;
  }
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/crm/pipelines", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());
  xhr.onload = function () {
    if (xhr.status === 200) {
      var pipelines = JSON.parse(xhr.responseText);
      pipelines.sort((a, b) => a.Order - b.Order);
      sessionStorage.setItem("pipelines", JSON.stringify(pipelines));
      callback(null, pipelines);
    } else {
      callback(new Error(xhr.responseText), null);
    }
  };
  xhr.onerror = function () {
    callback(new Error("Request failed"), null);
  };
  xhr.send();
}

function isValidGuid(input) {
  var guidRegex =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return guidRegex.test(input);
}

function timeFormater(input) {
  const options = {
    month: "numeric",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "numeric",
    second: "numeric",
    hour12: true,
  };
  //'en-US', options
  // Create DateRange record
  var temp = new Date(input).toLocaleString("en-US", options);
  return temp;
}


function timeFriendly(input) {
  const options = {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  };

  var temp = new Date(input).toLocaleString("en-US", options);
  return temp;
}

function timeFriendlyString(input) {
  const date = new Date(input);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  const seconds = String(date.getSeconds()).padStart(2, "0");
  const ampm = hours >= 12 ? "PM" : "AM";

  const formattedDate = `${month}-${day}-${year}`;
  const formattedTime = `${hours}:${minutes}:${seconds} ${ampm}`;

  return `${formattedDate} ${formattedTime}`;
}

function getLeads(callback) {
  const token = readToken();

  const xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/leads", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", `Bearer ${token}`);
  xhr.onreadystatechange = function () {
    if (xhr.readyState === XMLHttpRequest.DONE) {
      if (xhr.status === 200) {
        // Request successful
        const leads = JSON.parse(xhr.responseText);

        callback(null, leads);
      } else {
        // Request failed
        xalert("Error " + xhr.status + " " + xhr.responseText, 1, -1);
        callback(xhr.status, null);
      }
    }
  };
  xhr.send();
}

function timeFuck(input) {
  date = new Date(input);

  // Extract the components in local time
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");

  // Format the datetime-local value
  const localDateTimeString = `${year}-${month}-${day}T${hours}:${minutes}`;

  return localDateTimeString;
}

async function getColor(inputNumber) {
  if (sessionStorage.getItem("colors")) {
    var colors = JSON.parse(sessionStorage.getItem("colors"));
    // Rest of the code that uses the colors
  } else {
    const response = await fetch("colors.json");
    var colors = await response.json();
    sessionStorage.setItem("colors", JSON.stringify(colors));
    // Rest of the code that uses the colors
  }
  // Define the color categories in the order they should be returned
  const colorCategories = [
    "red",
    "orange",
    "yellow",
    "green",
    "blue",
    "purple",
    "pink",
    "brown",
    "black",
    "gray",
    "white",
  ];

  // Calculate the color category and index within that category

  const colorCategory = inputNumber % colorCategories.length;
  const colorIndex = Math.floor(inputNumber / colorCategories.length);

  // Get the color and its hex code
  const color = colors[colorCategories[colorCategory]][colorIndex];

  const hexCode = color.code;

  // Calculate the brightness of the color to determine the text color
  const r = parseInt(hexCode.slice(1, 3), 16);
  const g = parseInt(hexCode.slice(3, 5), 16);
  const b = parseInt(hexCode.slice(5, 7), 16);
  const brightness = Math.round((r * 299 + g * 587 + b * 114) / 1000);
  const textColor = brightness > 125 ? "black" : "white";
  console.log({ color: color, textColor: textColor });
  // Return the color and the text color
  return { color: color, textColor: textColor };
}

function getGroups(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("groups");
  }
  var groups = sessionStorage.getItem("groups");
  if (groups !== null) {
    callback(null, JSON.parse(groups));
    return;
  }
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/groups", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());
  xhr.onload = function () {
    if (xhr.status === 200) {
      var groups = JSON.parse(xhr.responseText);
      callback(null, groups);
      sessionStorage.setItem("groups", JSON.stringify(groups));
    } else {
      callback(new Error(xhr.responseText), null);
    }
  };
  xhr.onerror = function () {
    callback(new Error("Request failed"), null);
  };
  xhr.send();
}

function getGroupMembers(groupId, callback) {
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "/biomedapi/groups/" + groupId, true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.setRequestHeader("Authorization", "Bearer " + readToken());
  xhr.onload = function () {
    if (xhr.status === 200) {
      var members = JSON.parse(xhr.responseText);
      console.log(members);
      callback(null, members);
    } else {
      callback(new Error(xhr.responseText), null);
    }
  };
  xhr.onerror = function () {
    callback(new Error("Request failed"), null);
  };
  xhr.send();
}

let timeoutId;

function startShaking(button, redirect) {
  button.classList.add("shake");
  timeoutId = setTimeout(() => {
    redirect();
  }, 1000);
}

function stopShaking(button) {
    clearTimeout(timeoutId);
    button.classList.remove('shake');
}


function getContacts(callback, force) {
  if (force === true) {
    sessionStorage.removeItem("contacts");
    Object.keys(sessionStorage).forEach(key => {
      if (key.startsWith("contact:")) {
        sessionStorage.removeItem(key);
      }
    });
  }
  var contacts = sessionStorage.getItem("contacts");

  if (contacts !== null) {
    callback(null, JSON.parse(contacts));

  } else {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url + "/biomedapi/contacts", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + readToken());
    xhr.onreadystatechange = function () {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          var contacts = JSON.parse(xhr.responseText);
          sessionStorage.setItem("contacts", JSON.stringify(contacts));
          callback(null, contacts);
        } else {
          callback(new Error("Failed to get contacts"), null);
        }
      }
    };
    xhr.send();
  }
}

function getContactById(id, callback) {
  var contact = sessionStorage.getItem("contact:"+id);
  if (contact !== null) {
    callback(null, JSON.parse(contact));
  } else {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", url + "/biomedapi/contacts/" + id, true);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.setRequestHeader("Authorization", "Bearer " + readToken());
        xhr.onload = function () {
          if (xhr.readyState === xhr.DONE) {
            if (xhr.status === 200) {
              var contact = JSON.parse(xhr.responseText);
              sessionStorage.setItem("contact:"+id, JSON.stringify(contact));
              callback(null, contact);
            } else {
              callback("Error: " + xhr.status);
            }
          }
        };
        xhr.onerror = function () {
          callback("Request failed");
        };
        xhr.send();
      }
}

