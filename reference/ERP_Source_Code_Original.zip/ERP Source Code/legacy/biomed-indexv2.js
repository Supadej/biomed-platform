async function fetchUserSummary() {
    try {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', `${url}/biomedapi/v2/user/Summary`, true);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.setRequestHeader("Authorization", "Bearer " + readToken());

        const response = await new Promise((resolve, reject) => {
            xhr.onload = function () {
                if (xhr.status === 200) {
                    resolve(JSON.parse(xhr.responseText));
                } else {
                    reject(new Error(`Error: ${xhr.status} ${xhr.statusText}`));
                }
            };

            xhr.onerror = function () {
                reject(new Error('Request failed.'));
            };

            xhr.send();
        });

        return response;
    } catch (error) {
        console.error(error);
        throw error;
    }
}

// Usage example:
(async () => {
    showLoader();
    try {
        const response = await fetchUserSummary();
        console.log('Response:', response);
        var eventDisplayTask = displayEvent(response.myEvent,response.myCoopEvent);
        var targetDisplayTask = displayTarget(response.myTarget);
        var userDisplayTask = displayUser(response.user,response.userProduct,response.userSaleArea);
        
        await Promise.all([eventDisplayTask, targetDisplayTask, userDisplayTask]);
        hideLoader();
    } catch (error) {
        console.error(error);
    }
})();

async function displayUser(user,products,saleAreas) {
    return new Promise(async (resolve, reject) => {
        try {
            const codenameElements = document.querySelectorAll('.codename');
            const positionElements = document.querySelectorAll('.position');
            const profilePicElements = document.querySelectorAll('.ProfilePic');
            const emailElements = document.querySelectorAll('.email');
            const telElements = document.querySelectorAll('.tel');
            const saleAreasElements = document.querySelectorAll('.SaleAreas');
            const productsElements = document.querySelectorAll('.Products');
            const nameElements = document.querySelectorAll('.name');
            var Color = await getColor(user.Id);
            
            nameElements.forEach(el => el.textContent = user.FirstName + " " + user.LastName || 'N/A');
            codenameElements.forEach(el => el.innerHTML = user.FirstName + " " + `<span class="m-0 p-1 text-nowrap small rounded-5" style="background-color:${Color.color.code};color:${Color.textColor};">${Color.color.name}</span>`  || 'N/A');
            positionElements.forEach(el => el.textContent = user.Position || 'N/A');
            profilePicElements.forEach(el => el.src = "assets/profile/" + user.ProfilePic + ".jpg" || 'assets/profile-user.png');
            emailElements.forEach(el => el.textContent = user.Email || 'N/A');
            telElements.forEach(el => el.textContent = user.PhoneNumber || 'N/A');
            saleAreasElements.forEach(el => {
                const existingContent = el.innerHTML;
                el.innerHTML = existingContent + ' ' + saleAreas.map(area => 
                    `<span class="c-con-surface rounded-5 small p-1 text-nowrap">${area}</span>`
                ).join(' ') || 'N/A';
            });
            productsElements.forEach(el => {
                const existingContent = el.innerHTML;
                el.innerHTML = existingContent + ' ' + products.map(product => 
                    `<span class="c-con-surface rounded-5 small p-1 text-nowrap">${product}</span>`
                ).join(' ') || 'N/A';
            });

            console.log("User displayed successfully.");
            resolve("User displayed successfully.");
        } catch (error) {
            console.error("Failed to display user.", error);
            reject(new Error("Failed to display user."));
        }
    });
}
async function displayTarget(target) {
return new Promise(async (resolve, reject) => {
    try {
        target.forEach(t => {
            const now = new Date();
            const endDate = new Date(t.EndDate);
            t.RemainDays = Math.ceil((endDate - now) / (1000 * 60 * 60 * 24));

            t.Acheived = t.Leads.reduce((sum, lead) => sum + lead.AchivedRevenue, 0);

            t.Remaining = t.TargetValue - t.Acheived;

            t.AcheivedPercent = t.TargetValue > 0 ? Math.round((t.Acheived / t.TargetValue)*100) : 0;
        });

        const targetContainer = document.getElementById("targetContainer");

        //targetContainer.innerHTML = ''; // Clear previous targets
        await target.forEach(async t => {
            const product = await promiseProductById(t.ProductID);
            const saleArea = await promiseSaleAreaById(t.SaleAreaID);
            const targetElement = document.createElement('div');
            targetElement.className = "mx-2 my-1 p-3 rounded-5 c-surface position-relative flex-shrink-0 c-shadow";
            targetElement.style.maxWidth = "250px";

            targetElement.innerHTML = `
                <p class="m-0 p-0 mt-3 fs-6"><strong>${t.Name}</strong></p>
                <canvas id="target-${t.Id}" class="mx-3 my-2 position-relative" style="max-height: 180px; display: block; box-sizing: border-box; height: 180px; width: 180px;"></canvas>

                <div class="position-absolute top-0 start-50 translate-middle c-error rounded-5 p-2 text-nowrap">${t.RemainDays} days remaining</div>
                <p class="m-0 p-0 my-2 small mt-3">

                    <p class="m-0 p-0 my-2 small"> 
                        <span class="c-primary small p-1 px-3 m-0 rounded-5 my-1">Product</span> <span class="m-0 p-0 float-end text-truncate" style="max-width:120px"> ${product.Name}</span>
                    </p>
                    <p class="m-0 p-0 my-2 small"> 
                        <span class="c-primary small p-1 px-3 m-0 rounded-5 my-1">Sale Area</span> <span class="m-0 p-0 float-end text-truncate" style="max-width:120px""> ${saleArea.Name}</span>
                    </p>

                    <p class="m-0 p-0 my-2 small"> 
                        <span class="c-primary small p-1 px-3 m-0 rounded-5 my-1">Target</span> <span class="m-0 p-0 float-end text-truncate" style="max-width:120px""> ${AutoComma(t.TargetValue)} THB </span>
                    </p>
                    <p class="m-0 p-0 my-2 small"> 
                    
                    <span class="c-primary small p-1 px-3 m-0 rounded-5">Achieved</span> <span class="m-0 p-0 float-end text-truncate" style="max-width:120px"">${AutoComma(t.Acheived)} THB </span>
                    </p>
                    
                    <p class="m-0 p-0 my-2 small"> 
                    
                    <span class="c-primary small p-1 px-3 m-0 rounded-5">Remaining</span> <span class="m-0 p-0 float-end text-truncate" style="max-width:120px"">${AutoComma(t.Remaining <0?0: t.Remaining)} THB </span>
                    </p>
                </p>
            `;

            targetContainer.appendChild(targetElement);
            const ctx = document.getElementById('target-'+ t.Id).getContext('2d');
                    const centerText = {
                        id: 'centerText',
                        afterDatasetsDraw(chart) {
                            const { ctx, chartArea: { width, height } } = chart;
                            ctx.save();
                            ctx.font = 'bold 24px "Noto Sans Thai", sans-serif';
                            ctx.fillStyle = '#333';
                            ctx.textAlign = 'center';
                            ctx.textBaseline = 'middle';
                            ctx.fillText(t.AcheivedPercent+ " %", width / 2, height / 1.8);
                            ctx.restore();
                        }
                    };

                    new Chart(ctx, {
                        type: 'doughnut',
                        data: {
                            labels: ['Achieved', 'Remaining'],
                            datasets: [{
                                data: [t.Acheived, t.Acheived>t.TargetValue?0: t.TargetValue - t.Acheived],
                                backgroundColor: ['#8f4a4f', '#fceaea'],
                                borderWidth: 0,
                                cutout: '80%',
                                circumference: 270,
                                rotation: 225,
                                borderRadius: 10,
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: true,
                            plugins: {
                                legend: { display: false },
                                tooltip: {
                                    callbacks: {
                                        label: function(tooltipItem) {
                                            return AutoComma(tooltipItem.raw) + ' THB';
                                        }
                                    }
                                }
                            }
                        },
                        plugins: [centerText]
                    });
        });
        console.log('Processed Targets:', target);

        resolve("Target displayed successfully.");
    }
    catch (error) {
        reject(new Error("Failed to display target."));
    }
});
}
async function displayEvent(event,coopEvent) {
return new Promise(async(resolve, reject) => {
    try {
    event.forEach(e => e.selfEvent = true);
    coopEvent.forEach(e => e.selfEvent = false);
    const combinedEvents = [...event, ...coopEvent];
    console.log('Combined Events:', combinedEvents);
    combinedEvents.sort((a, b) => new Date(a.StartDate) - new Date(b.StartDate));
    const today = new Date();
    const filteredEvents = [];
    console.log('Filtered Events:', filteredEvents);
    combinedEvents.forEach(e => {
        const now = new Date();
        const startDate = new Date(e.StartDate);
        const endDate = new Date(e.EndDate);

        if (endDate < now && (e.Report === null || e.Report === '')) {
            e.reminder = "Need Report";
            e.css = "c-error c-shadow";
            e.valid = true;
        } else if (now >= startDate && now <= endDate) {
            e.reminder = "Occuring";
            e.css = "c-blue c-shadow";
            e.valid = true;
        } else if (startDate.toDateString() === now.toDateString()) {
            e.reminder = "Today";
            e.css = "c-blue c-shadow";
            e.valid = true;
        } else {
            const tomorrow = new Date();
            tomorrow.setDate(now.getDate() + 1);
            if (startDate.toDateString() === tomorrow.toDateString()) {
                e.reminder = "Tomorrow";
                e.css = "c-ok c-shadow";
                e.valid = true;
            } else {
                const daysDifference = Math.ceil((startDate - now) / (1000 * 60 * 60 * 24));
                e.reminder = `${daysDifference} days`;
                e.css = "c-ok  c-shadow";
                e.valid = true;
                if (daysDifference < 0) {
                    e.reminder = `Done`;
                    e.css = "c-blue c-shadow";
                    e.valid = false;
                }
            }
        }
        if(e.valid === true) filteredEvents.push(e);
    });
    const eventContainer = document.getElementById("eventContainer");
    eventContainer.innerHTML = ''; // Clear previous events
    filteredEvents.forEach(e => {
        const eventElement = document.createElement('div');
        eventElement.className = "mx-2 my-1 p-3 rounded-5 c-surface position-relative flex-shrink-0 c-shadow";
        eventElement.style.width = "250px";
        eventElement.style.height = "250px";
        eventElement.style.textOverflow = "ellipsis";

        eventElement.innerHTML = `
            <p class="m-0 p-0 mt-3 fs-6" style="white-space: wrap; overflow: hidden; text-overflow: ellipsis;">
            <strong>${e.Title}</strong>
            </p>
            <div class="p-0 m-0 mt-1 position-absolute top-0 end-0 translate-middle">
            <a href="./event.html?id=${e.Id}" class="ms-2 rounded-5 p-2 c-surface c-shadow"><i class="fas fa-link"></i></a>
            </div>
            <div class="p-0 m-0 position-absolute top-0 start-0">
            <div class="ms-2 m-0 p-2">
            ${e.selfEvent ? '<i class="fas fa-user"></i>' : '<i class="fas fa-users"></i>'}
            </div>
            </div>
            <div class="position-absolute top-0 start-50 translate-middle ${e.css} rounded-5 p-2">
            ${e.reminder}
            </div>
            <p class="m-0 p-0 my-2 small" style="white-space: pre-line;max-height: 150px;overflow: hidden;">${e.Plan.trim()}</p>
        `;

        eventContainer.appendChild(eventElement);
    });


    
            
                console.log("Event displayed successfully.");
                resolve("Event displayed successfully.");
        } catch (error) {
            reject(new Error("Failed to display event."));
        }
    });
}