function quickNavOpen(){
    QuickNavModal.open();
}
(function () {
    function open() {
        document.addEventListener("keydown", function (event) {
            if (event.key === "Escape") {
                close();
            }
        });
        if (document.getElementById("QuickNavModal")) return; // Prevent duplicates

        // Create modal container
        const modal = document.createElement("div");
        modal.id = "QuickNavModal";
        Object.assign(modal.style, {
            position: "fixed",
            top: "0",
            left: "0",
            width: "100vw",
            height: "100vh",
            backgroundColor: "rgba(0, 0, 0, 0.8)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: "1000"
        });

        // Create modal content
        const modalContent = document.createElement("div");
        Object.assign(modalContent.style, {
            padding: "0px",
            width: "95%",
            height: "95%",
            position: "relative"
        });
        modalContent.classList.add("c-surface","rounded-5");

        // Create close button
        const closeButton = document.createElement("button");
        closeButton.innerHTML = '<i class="fas fa-times"></i>';
        Object.assign(closeButton.style, {
            position: "absolute",
            top: "10px",
            right: "10px",
            border: "none",
            width: "30px",
            height: "30px",
            borderRadius: "50%",
            fontSize: "18px",
            cursor: "pointer"
        });
        closeButton.classList.add("c-error");
        closeButton.onclick = close;

        // Add modal content
        const content = document.createElement("div");
        content.innerHTML = `
            <h5 class="mt-3 ms-3 m-1 p-0">
            <i class="fas fa-compass"></i> Quick Navigation (Currently in development)
            </h5>
            <div class="m-2 p-2 c-con-surface rounded-5 flex-fill">
            test
            </div>
            `;
        content.classList.add("d-flex","flex-column","h-100");
        // Assemble elements
        modalContent.appendChild(closeButton);
        modalContent.appendChild(content);
        modal.appendChild(modalContent);
        document.body.appendChild(modal);
    }

    function close() {
        const modal = document.getElementById("QuickNavModal");
        if (modal) modal.remove();
    }

    // Expose functions globally
    window.QuickNavModal = { open, close };
})();
