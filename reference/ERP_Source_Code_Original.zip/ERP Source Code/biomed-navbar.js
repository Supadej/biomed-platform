/**
 * biomed-navbar.js
 * Shared Navbar Component - Single source of truth for all pages
 * 
 * Usage: Add <div id="navbar"></div> where you want the navbar, then include this script.
 * The script auto-detects the current page and highlights the active nav item.
 */

(function () {
    // ===== NAV ITEMS CONFIGURATION =====
    const navItems = [
        { href: 'index.html', icon: 'fa-home', label: 'Home' },
        { href: 'crm.html', icon: 'fa-users', label: 'CRM' },
        { href: 'event.html', icon: 'fa-calendar', label: 'Event' },
        { href: 'project.html', icon: 'fa-project-diagram', label: 'Project' },
        { href: 'contact.html', icon: 'fa-address-book', label: 'Contact' },
        { href: 'helpdesk.html', icon: 'fa-headset', label: 'Helpdesk' },
        { href: 'invoice.html', icon: 'fa-file-invoice', label: 'Invoice' },
        { href: 'inventory.html', icon: 'fa-warehouse', label: 'Inventory' },
        { href: 'visualization.html', icon: 'fa-chart-bar', label: 'Data' },
        { href: 'management.html', icon: 'fa-cog', label: 'Manage' }
    ];

    // ===== PAGE-TO-ACTIVE MAPPING =====
    // Maps each page filename to its parent nav item for active highlighting
    const pageMapping = {
        'index.html': 'index.html',
        'crm.html': 'crm.html',
        'crm-detail.html': 'crm.html',
        'event.html': 'event.html',
        'project.html': 'project.html',
        'project-overview.html': 'project.html',
        'project-activity.html': 'project.html',
        'contact.html': 'contact.html',
        'helpdesk.html': 'helpdesk.html',
        'helpdesk-detail.html': 'helpdesk.html',
        'invoice.html': 'invoice.html',
        'inventory.html': 'inventory.html',
        'inventoryDetail.html': 'inventory.html',
        'visualization.html': 'visualization.html',
        'd3.html': 'visualization.html',
        'management.html': 'management.html',
        'management-detail.html': 'management.html',
        'management-group.html': 'management.html',
        'management-product.html': 'management.html',
        'management-salearea.html': 'management.html'
    };

    // ===== THEME OPTIONS =====
    const themes = [
        { name: 'light', emoji: '☀️', label: 'Light' },
        { name: 'dark', emoji: '🌙', label: 'Dark' },
        { name: 'corporate', emoji: '🏢', label: 'Corporate' },
        { name: 'cupcake', emoji: '🧁', label: 'Cupcake' },
        { name: 'nord', emoji: '❄️', label: 'Nord' },
        { name: 'sunset', emoji: '🌅', label: 'Sunset' }
    ];

    // ===== DETECT ACTIVE PAGE =====
    function getActiveHref() {
        var path = window.location.pathname;
        var page = path.substring(path.lastIndexOf('/') + 1) || 'index.html';
        return pageMapping[page] || '';
    }

    // ===== BUILD NAVBAR HTML =====
    function buildNavbar() {
        var activeHref = getActiveHref();

        // Desktop nav items
        var desktopItems = navItems.map(function (item) {
            var isActive = item.href === activeHref;
            var btnClass = isActive ? 'btn btn-primary btn-sm gap-2' : 'btn btn-ghost btn-sm gap-2';
            return '<li><a href="' + item.href + '" class="' + btnClass + '"><i class="fas ' + item.icon + '"></i> ' + item.label + '</a></li>';
        }).join('\n                ');

        // Mobile nav items
        var mobileItems = navItems.map(function (item) {
            var isActive = item.href === activeHref;
            var activeClass = isActive ? ' class="active"' : '';
            return '<li><a href="' + item.href + '"' + activeClass + '><i class="fas ' + item.icon + ' w-5"></i> ' + item.label + '</a></li>';
        }).join('\n                    ');

        // Theme dropdown items
        var themeItems = themes.map(function (t) {
            return '<li><button onclick="setTheme(\'' + t.name + '\')">' + t.emoji + ' ' + t.label + '</button></li>';
        }).join('\n                    ');

        return '<nav class="navbar bg-base-100/80 backdrop-blur-lg shadow-sm sticky top-0 z-40 px-4 lg:px-8">'
            + '\n        <div class="flex-1">'
            + '\n            <a href="index.html" class="text-sm sm:text-base md:text-xl lg:text-2xl font-bold whitespace-nowrap">'
            + '\n                <span class="text-primary">Biomed</span><span class="text-secondary">Diagnostics</span>'
            + '\n            </a>'
            + '\n        </div>'
            + '\n        '
            + '\n        <!-- Desktop Navigation -->'
            + '\n        <div class="hidden lg:flex items-center gap-1">'
            + '\n            <ul class="menu menu-horizontal gap-1">'
            + '\n                ' + desktopItems
            + '\n            </ul>'
            + '\n        </div>'
            + '\n'
            + '\n        <div class="flex items-center gap-2">'
            + '\n            <!-- Theme Dropdown -->'
            + '\n            <div class="dropdown dropdown-end">'
            + '\n                <div tabindex="0" role="button" class="btn btn-ghost btn-circle btn-sm">'
            + '\n                    <i class="fas fa-palette"></i>'
            + '\n                </div>'
            + '\n                <ul tabindex="0" class="dropdown-content menu bg-base-100 rounded-box z-50 w-44 p-2 shadow-xl">'
            + '\n                    <li class="menu-title text-xs">เลือก Theme</li>'
            + '\n                    ' + themeItems
            + '\n                </ul>'
            + '\n            </div>'
            + '\n            '
            + '\n            <button class="btn btn-ghost btn-circle btn-sm" onclick="clearCache()">'
            + '\n                <i class="fas fa-sync-alt"></i>'
            + '\n            </button>'
            + '\n            '
            + '\n            <button class="btn btn-ghost btn-circle btn-sm text-error" onclick="logout()">'
            + '\n                <i class="fas fa-sign-out-alt"></i>'
            + '\n            </button>'
            + '\n'
            + '\n            <!-- Mobile Menu -->'
            + '\n            <div class="dropdown dropdown-end lg:hidden">'
            + '\n                <div tabindex="0" role="button" class="btn btn-ghost btn-circle btn-sm">'
            + '\n                    <i class="fas fa-bars"></i>'
            + '\n                </div>'
            + '\n                <ul tabindex="0" class="dropdown-content menu bg-base-100 rounded-box z-50 w-52 p-2 shadow-xl">'
            + '\n                    ' + mobileItems
            + '\n                </ul>'
            + '\n            </div>'
            + '\n        </div>'
            + '\n    </nav>';
    }

    // ===== INJECT NAVBAR =====
    function injectNavbar() {
        var container = document.getElementById('navbar');
        if (container) {
            container.outerHTML = buildNavbar();
        }
    }

    // Auto-inject when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', injectNavbar);
    } else {
        injectNavbar();
    }

    // ===== GLOBAL NAVBAR FUNCTIONS =====
    // These are called by onclick in the navbar HTML

    // Theme switcher
    window.setTheme = function (theme) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('biomed-theme', theme);
    };

    // Load saved theme on startup
    var savedTheme = localStorage.getItem('biomed-theme');
    if (savedTheme) {
        document.documentElement.setAttribute('data-theme', savedTheme);
    }

    // Logout
    window.logout = function () {
        if (confirm('ต้องการออกจากระบบหรือไม่?')) {
            if (typeof removeToken === 'function') {
                removeToken();
            }
            window.location.href = 'login.html';
        }
    };

    // Clear cache
    if (!window.clearCache) {
        window.clearCache = function () {
            sessionStorage.clear();
            location.reload();
        };
    }
})();
